/**
 * Urban Sentinel weather: Open-Meteo primary, MET Norway Locationforecast backup.
 * Both sources provide modelled 2-metre AIR temperature, not ground-surface heat.
 * No API key. Browser uses its real Origin header for MET Norway identification.
 * Low-volume usage only; for high traffic move this behind a caching proxy.
 * Attribution: Norwegian Meteorological Institute (MET Norway), CC BY 4.0.
 */
const TTL = 15 * 60 * 1000;
const STALE_LIMIT = 24 * 60 * 60 * 1000;
const PREFIX = 'urban-sentinel-weather-v3:';
const cache = new Map(), pending = new Map();
const finite = x => typeof x === 'number' && Number.isFinite(x);
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const keyFor = (point, history) => `${Number(point.lat).toFixed(3)},${Number(point.lon ?? point.lng).toFixed(3)}:${history ? 'history' : 'current'}`;

function getCached(key) {
  if (cache.has(key)) return cache.get(key);
  try {
    const raw = localStorage.getItem(PREFIX + key);
    const item = raw ? JSON.parse(raw) : null;
    if (item && Number.isFinite(item.savedAt) && item.value?.current) {
      cache.set(key, item);
      return item;
    }
  } catch { /* local storage disabled */ }
  return null;
}
function saveCached(key, value) {
  const item = {savedAt: Date.now(), value};
  cache.set(key, item);
  try { localStorage.setItem(PREFIX + key, JSON.stringify(item)); } catch { /* quota/privacy mode */ }
}
async function request(url, {timeout=9000, retries=0}={}) {
  let last;
  for (let attempt=0; attempt<=retries; attempt++) {
    const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),timeout);
    try {
      // Accept is a CORS-safelisted header. No spoofed User-Agent or preflight.
      const response=await fetch(url,{mode:'cors',signal:ctl.signal,headers:{Accept:'application/json'}});
      if(!response.ok){
        const err=new Error(`HTTP ${response.status}`);
        err.retryable=response.status===429||response.status>=500;
        throw err;
      }
      const data=await response.json();
      if(data?.error)throw Error(data.reason||'Provider rejected request');
      return data;
    } catch(err) {
      last=err;
      if(attempt===retries||!(err.retryable||err.name==='AbortError'||err instanceof TypeError))break;
      await pause(450*(attempt+1));
    } finally {clearTimeout(timer)}
  }
  throw last||Error('Weather service unavailable');
}
function localTime(iso) {
  if(!iso)return null;
  const d=new Date(iso);
  if(!Number.isFinite(d.getTime()))return String(iso);
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(d);
  const part=k=>parts.find(x=>x.type===k)?.value;
  return `${part('year')}-${part('month')}-${part('day')}T${part('hour')}:${part('minute')}`;
}
function historyRows(daily) {
  if(!daily?.time||!daily.temperature_2m_mean)return [];
  // Skip today's partial day and keep up to seven complete dates.
  const nowLocal=localTime(new Date().toISOString()).slice(0,10);
  return daily.time.map((date,i)=>({date,value:daily.temperature_2m_mean[i]}))
    .filter(row=>row.date<nowLocal&&finite(row.value)).slice(-7);
}
async function fromOpenMeteo(point, history) {
  const url=new URL('https://api.open-meteo.com/v1/forecast');
  url.searchParams.set('latitude',Number(point.lat).toFixed(5));
  url.searchParams.set('longitude',Number(point.lon??point.lng).toFixed(5));
  url.searchParams.set('timezone','Asia/Kolkata');
  url.searchParams.set('current','temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,precipitation');
  if(history){url.searchParams.set('daily','temperature_2m_mean');url.searchParams.set('past_days','8');url.searchParams.set('forecast_days','1')}
  const data=await request(url.toString(),{timeout:9000,retries:1});
  const current=data?.current;
  if(!finite(current?.temperature_2m))throw Error('Open-Meteo did not supply air temperature');
  return {current,trend:historyRows(data.daily),source:'Open-Meteo',time:current.time||null,stale:false,forecast:false,precipitationPeriod:'current',providerError:null};
}
export function parseMetNorway(data,now=Date.now()) {
  const rows=data?.properties?.timeseries;
  if(!Array.isArray(rows)||!rows.length)throw Error('MET Norway returned no forecast points');
  let best=null,bestDistance=Infinity;
  for(const row of rows){
    const time=Date.parse(row.time),t=row?.data?.instant?.details?.air_temperature;
    if(!Number.isFinite(time)||!finite(t))continue;
    const distance=Math.abs(time-now);
    if(distance<bestDistance){best=row;bestDistance=distance}
  }
  if(!best)throw Error('MET Norway did not supply air temperature');
  const details=best.data.instant.details;
  const next=best.data.next_1_hours?.details;
  const wind=finite(details.wind_speed)?details.wind_speed*3.6:null; // m/s -> km/h
  return {current:{
    time:localTime(best.time),temperature_2m:details.air_temperature,
    apparent_temperature:null, // not provided by MET Norway: never invent it
    relative_humidity_2m:finite(details.relative_humidity)?details.relative_humidity:null,
    wind_speed_10m:wind,
    precipitation:finite(next?.precipitation_amount)?next.precipitation_amount:null
   },trend:[],source:'MET Norway',time:localTime(best.time),stale:false,
   forecast:Date.parse(best.time)>now+30*60*1000,
   precipitationPeriod:'next 1 hour forecast',providerError:null};
}
async function fromMetNorway(point) {
  const url=new URL('https://api.met.no/weatherapi/locationforecast/2.0/compact');
  url.searchParams.set('lat',Number(point.lat).toFixed(4));
  url.searchParams.set('lon',Number(point.lon??point.lng).toFixed(4));
  const data=await request(url.toString(),{timeout:9500,retries:0});
  return parseMetNorway(data);
}
/** MET Norway directly, used when an Open-Meteo *batch* request has already failed. */
export async function loadMetBackup(point,{force=false}={}) {
  const key='met-only:'+keyFor(point,false),old=getCached(key),age=old?Date.now()-old.savedAt:Infinity;
  if(!force&&age<TTL)return {...old.value,cached:true,stale:false};
  if(pending.has(key))return pending.get(key);
  const task=(async()=>{
    try{const value=await fromMetNorway(point);saveCached(key,value);return {...value,cached:false}}
    catch(error){
      if(old&&age<STALE_LIMIT)return {...old.value,cached:true,stale:true,providerError:`MET Norway unavailable (${error.message}); showing saved reading.`};
      throw error;
    }
  })();pending.set(key,task);
  try{return await task}finally{pending.delete(key)}
}
/** Independent per-coordinate fetch. A provider failure never becomes a made-up number. */
export async function loadWeather(point,{force=false,history=false}={}) {
  if(!Number.isFinite(Number(point?.lat))||!Number.isFinite(Number(point?.lon??point?.lng)))throw Error('City coordinates unavailable');
  const key=keyFor(point,history),old=getCached(key),age=old?Date.now()-old.savedAt:Infinity;
  if(!force&&age<TTL)return {...old.value,cached:true,stale:false};
  if(pending.has(key))return pending.get(key);
  const promise=(async()=>{
    let primaryError=null,backupError=null;
    try {
      const data=await fromOpenMeteo(point,history);
      saveCached(key,data);return {...data,cached:false};
    } catch(e){primaryError=e.message}
    try {
      const data=await loadMetBackup(point,{force});
      data.providerError=`Open-Meteo unavailable (${primaryError}); using MET Norway.`;
      // MET Norway does not provide historical observations. Do not fabricate a trend.
      if(history&&old?.value?.trend?.length)data.trend=old.value.trend;
      saveCached(key,data);return {...data,cached:false};
    } catch(e){backupError=e.message}
    if(old&&age<STALE_LIMIT){
      return {...old.value,cached:true,stale:true,providerError:`Weather providers unavailable (Open-Meteo: ${primaryError}; MET Norway: ${backupError}). Showing saved reading.`};
    }
    throw Error(`Open-Meteo: ${primaryError}; MET Norway: ${backupError}`);
  })();
  pending.set(key,promise);
  try{return await promise}finally{pending.delete(key)}
}
