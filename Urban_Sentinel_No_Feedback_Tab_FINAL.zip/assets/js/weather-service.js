// Temperature Map: Open-Meteo batch first; limited MET Norway fallback for failed batches.
// All readings are modelled outdoor AIR temperature at 2 metres, not ground-surface temperature.
import {loadMetBackup} from './weather-fallback.js';
const TTL=15*60*1000,PREFIX='urban-sentinel-wx-v2-';
const cache=new Map();
function getCached(key){const found=cache.get(key);if(found&&Date.now()-found.at<TTL)return found;try{const item=JSON.parse(sessionStorage.getItem(PREFIX+key));if(item&&Date.now()-item.at<TTL){cache.set(key,item);return item}}catch{}return null}
function setCached(key,value){cache.set(key,value);try{sessionStorage.setItem(PREFIX+key,JSON.stringify(value))}catch{}}
async function requestBatch(points){
 const url=new URL('https://api.open-meteo.com/v1/forecast');
 url.searchParams.set('latitude',points.map(p=>p.lat).join(','));
 url.searchParams.set('longitude',points.map(p=>p.lng??p.lon).join(','));
 url.searchParams.set('current','temperature_2m,relative_humidity_2m,apparent_temperature');
 url.searchParams.set('timezone','Asia/Kolkata');
 const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),9000);
 try{
  const response=await fetch(url.toString(),{signal:ctl.signal});
  if(!response.ok)throw Error(`Open-Meteo HTTP ${response.status}`);
  const raw=await response.json(),rows=Array.isArray(raw)?raw:[raw];
  if(rows.length!==points.length)throw Error('Incomplete weather model response');
  return rows;
 }finally{clearTimeout(timer)}
}
function readPrimary(current){
 if(!Number.isFinite(current?.temperature_2m))return null;
 return {temp:current.temperature_2m,feels:Number.isFinite(current.apparent_temperature)?current.apparent_temperature:null,
 humidity:Number.isFinite(current.relative_humidity_2m)?current.relative_humidity_2m:null,
 time:current.time||null,source:'Open-Meteo',stale:false};
}
function readBackup(result){const w=result.current;
 return {temp:w.temperature_2m,feels:w.apparent_temperature,humidity:w.relative_humidity_2m,
 time:w.time,source:'MET Norway',stale:result.stale||false};
}
export async function currentWeather(points,{force=false}={}){
 if(!Array.isArray(points)||!points.length)return {values:{},at:Date.now(),source:'None',failed:0};
 const key=points.map(p=>`${p.id}:${Number(p.lat).toFixed(3)}:${Number(p.lng??p.lon).toFixed(3)}`).join('|');
 if(!force){const saved=getCached(key);if(saved)return {...saved,cached:true}}
 const values={},missing=[],errors=[];let modelTime='',primaryCount=0,backupCount=0;
 for(let i=0;i<points.length;i+=15){
  const batch=points.slice(i,i+15);
  try{
   const rows=await requestBatch(batch);
   rows.forEach((r,j)=>{const value=readPrimary(r?.current);
    if(value){values[batch[j].id]=value;modelTime=value.time||modelTime;primaryCount++}
    else missing.push(batch[j]);
   });
  }catch(e){missing.push(...batch);errors.push(e.message)}
 }
 // Limit direct fallback traffic: MET Norway permits low-volume browser requests.
 // Selected city requests always contain one point and therefore always get a fallback attempt.
 const BACKUP_LIMIT=12,backupTargets=missing.slice(0,BACKUP_LIMIT);let index=0;
 async function worker(){while(index<backupTargets.length){const point=backupTargets[index++];
  try{const w=await loadMetBackup(point,{force});values[point.id]=readBackup(w);modelTime=modelTime||w.time||'';backupCount++}
  catch(e){errors.push(`${point.name||point.id}: ${e.message}`)}
 }}
 await Promise.all(Array.from({length:Math.min(3,backupTargets.length)},worker));
 if(!Object.keys(values).length)throw Error(errors[0]||'No temperature data available from either weather provider');
 const failed=points.length-Object.keys(values).length;
 const source=primaryCount&&backupCount?'Open-Meteo + MET Norway':backupCount?'MET Norway':'Open-Meteo';
 const result={values,at:Date.now(),modelTime,source,failed,backupLimited:missing.length>BACKUP_LIMIT,
  note:missing.length>BACKUP_LIMIT?'Backup limited to 12 city requests to protect the free weather service. Select an individual city to retrieve its temperature.':''};
 setCached(key,result);return result;
}
