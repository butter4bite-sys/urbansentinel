import {loadWeather} from './weather-fallback.js';
/* Urban Sentinel extensions: read-only access to legacy data. No API keys. */
export const CITY_SEEDS = [
  {name:'Pune',lat:18.5204,lon:73.8567}, {name:'Mumbai',lat:19.076,lon:72.8777},
  {name:'Delhi',lat:28.6139,lon:77.209}, {name:'Bengaluru',lat:12.9716,lon:77.5946},
  {name:'Hyderabad',lat:17.385,lon:78.4867}, {name:'Chennai',lat:13.0827,lon:80.2707},
  {name:'Kolkata',lat:22.5726,lon:88.3639}, {name:'Ahmedabad',lat:23.0225,lon:72.5714},
  {name:'Jaipur',lat:26.9124,lon:75.7873}, {name:'Nagpur',lat:21.1458,lon:79.0882}
];
const cache = new Map();
export function safeText(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
export function money(x){return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(x||0)}
export function cityKey(c){return `${Number(c.lat).toFixed(3)},${Number(c.lon).toFixed(3)}`;}
export function num(n,d=0){return n==null||n===''||!Number.isFinite(Number(n))?'—':Number(n).toFixed(d)}
export function storageGet(key, fallback){try{const v=JSON.parse(localStorage.getItem(key));return v===null?fallback:v;}catch{return fallback}}
export function storageSet(key,value){try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false}}
async function getJson(url, lifetime=10*60*1000){const found=cache.get(url);if(found&&Date.now()-found.time<lifetime)return found.data;
 const ctl=new AbortController();const timeout=setTimeout(()=>ctl.abort(),13500);
 try{const r=await fetch(url,{signal:ctl.signal,headers:{Accept:'application/json'}});if(!r.ok)throw Error(`HTTP ${r.status}`);const data=await r.json();cache.set(url,{data,time:Date.now()});return data;}finally{clearTimeout(timeout)}
}
export async function findCity(name){const url=`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=5&language=en&format=json`;const data=await getJson(url,3600000);return (data.results||[]).map(x=>({name:x.name,lat:x.latitude,lon:x.longitude,region:x.admin1,country:x.country}));}
export async function fetchConditions(c,{history=false,force=false}={}){
 const lat=Number(c.lat),lon=Number(c.lon??c.lng);
 if(!Number.isFinite(lat)||!Number.isFinite(lon))throw Error('Invalid coordinates');
 const common=`latitude=${lat}&longitude=${lon}&timezone=Asia%2FKolkata`;
 const air=`https://air-quality-api.open-meteo.com/v1/air-quality?${common}&current=us_aqi,pm2_5,pm10,nitrogen_dioxide,ozone&hourly=us_aqi&past_days=5&forecast_days=1`;
 const daily=`https://api.open-meteo.com/v1/forecast?${common}&daily=temperature_2m_max&past_days=8&forecast_days=1`;
 const [w,a,d]=await Promise.allSettled([
   loadWeather(c,{force}),getJson(air,50*60*1000),
   history?getJson(daily,30*60*1000):Promise.resolve(null)
 ]);
 const wx=w.status==='fulfilled'?w.value:null;
 return {
   weather:wx?{current:wx.current,daily:d.status==='fulfilled'?d.value?.daily:null,source:wx.source,stale:wx.stale,cached:wx.cached,forecast:wx.forecast,precipitationPeriod:wx.precipitationPeriod,time:wx.time,providerError:wx.providerError}:null,
   air:a.status==='fulfilled'?a.value:null,
   weatherError:w.status==='rejected'?w.reason.message:(wx?.providerError||null),
   airError:a.status==='rejected'?a.reason.message:null,
   dailyError:d.status==='rejected'?d.reason.message:null
 };
}
export const aqiCategory = value => {if(value==null)return {label:'Unavailable',color:'#94a3b8',note:'No current AQI reading was returned.'}; const n=Number(value);
 if(n<=50)return {label:'Good',color:'#65ce99',note:'Generally satisfactory air quality.'};
 if(n<=100)return {label:'Moderate',color:'#e6ca65',note:'Some unusually sensitive people may experience effects.'};
 if(n<=150)return {label:'Unhealthy for sensitive groups',color:'#f7a758',note:'Sensitive groups should consider reducing prolonged outdoor exertion.'};
 if(n<=200)return {label:'Unhealthy',color:'#ee786d',note:'Consider limiting prolonged outdoor exertion.'};
 if(n<=300)return {label:'Very unhealthy',color:'#b98fdf',note:'Health alert: avoid prolonged outdoor exertion.'};
 return {label:'Hazardous',color:'#d36d85',note:'Health warning of emergency conditions.'};};
export function heatCategory(t){if(t==null)return 'Unavailable';return Number(t)>=40?'High temperature screening':Number(t)>=35?'Elevated temperature screening':'Review local conditions';}
const SOURCE_KEYS=['urban-sentinel-projects','urbanSentinelProjects','urban_sentinel_projects','savedProjects','us_projects','coolcity_projects','urban-sentinel-saved-projects','urbanSentinelSavedProjects','projects','savedPlans','plans','assessments'];
/* Extract compatible saved project records without altering another page's storage. */
export function getExistingProjects(){
 const result=[],seen=new Set(),MAX=60;
 function parseItem(p,key,path){if(!p||typeof p!=='object'||Array.isArray(p))return;
 const rawName=p.name||p.title||p.projectName||p.projectTitle||p.societyName||p.areaName||p.locality||p.neighborhood;
 const hasContent=['budget','budgetInr','totalBudget','plannedBudget','recommendations','actions','interventions','assessment','siteArea','area'].some(k=>p[k]!=null);
 if(!rawName&&!hasContent)return;
 const name=String(rawName||`Saved project ${result.length+1}`).slice(0,100),id=String(p.id||p.projectId||p.uuid||`${key}-${path}`),stable=`${key}|${id}`;
 if(seen.has(stable))return;seen.add(stable);
 const location=typeof p.location==='object'?p.location:{};const coords=p.coordinates||location.coordinates;
 const lat=Number(p.lat??p.latitude??location.lat??location.latitude??(Array.isArray(coords)?coords[1]:NaN));
 const lon=Number(p.lon??p.lng??p.longitude??location.lon??location.lng??location.longitude??(Array.isArray(coords)?coords[0]:NaN));
 const rawBudget=p.budgetInr??p.budget??p.totalBudget??p.plannedBudget??p.budgetAmount??p.cost??p.amount;
 const budget=typeof rawBudget==='number'?rawBudget:Number(String(rawBudget??'').replace(/[^\d.]/g,''));
 result.push({id:stable,name,city:String(p.city||p.locality||p.areaName||location.city||p.area||'').slice(0,80),budget:Number.isFinite(budget)&&budget>0?budget:null,
 lat:Number.isFinite(lat)&&Math.abs(lat)<=90?lat:null,lon:Number.isFinite(lon)&&Math.abs(lon)<=180?lon:null,original:p});
 }
 function scan(v,key,path='',depth=0){if(depth>3||result.length>=MAX||!v)return;if(Array.isArray(v)){v.slice(0,MAX).forEach((x,i)=>scan(x,key,path+'.'+i,depth+1));return;}if(typeof v!=='object')return;
 if(path)parseItem(v,key,path);
 for(const k of ['projects','savedProjects','savedPlans','plans','assessments','items','data','records'])if(k in v)scan(v[k],key,path+'.'+k,depth+1);
 }
 try{let keys=[...SOURCE_KEYS];for(let i=0;i<localStorage.length&&i<200;i++){const k=localStorage.key(i);if(k&&/project|sentinel|cooling|plan|assessment/i.test(k)&&!k.startsWith('usx.'))keys.push(k)}
 for(const key of [...new Set(keys)]){const raw=localStorage.getItem(key);if(!raw||raw.length>1600000)continue;try{const v=JSON.parse(raw);if(Array.isArray(v))scan(v,key);else if(v&&typeof v==='object'){if(/project/i.test(key)&&!('projects'in v))parseItem(v,key,'root');scan(v,key);}}catch{/* unrelated storage */}}
 }catch{/* localStorage blocked */}
 return result.slice(0,MAX);
}
export function getProjectPins(){const own=storageGet('usx.mapPins',[]);const imported=getExistingProjects().filter(p=>p.lat!=null&&p.lon!=null).map(p=>({id:p.id,name:p.name,lat:p.lat,lon:p.lon,source:'Existing saved project (read-only)'}));return [...(Array.isArray(own)?own:[]),...imported];}
export function dateLabel(ts){if(!ts)return 'Time unavailable';const d=new Date(ts);return isNaN(d)?String(ts):d.toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short'});}
