import {CITY_SEEDS,findCity,fetchConditions,aqiCategory,heatCategory,money,num,safeText,storageGet,storageSet,getExistingProjects,dateLabel} from './usx-data.js';
import {directoryPromise,populateStates,populateCities,resolveCity} from './usx-directory.js';
/* Optional panels. Existing app logic, forms, maps and storage are not replaced. */
const $=(sel,root=document)=>root.querySelector(sel);
function n(tag,cls,html=''){const e=document.createElement(tag);if(cls)e.className=cls;if(html)e.innerHTML=html;return e;}
function createPanel(title,desc){const el=n('section','usx-panel');el.setAttribute('aria-label',title);el.innerHTML=`<div class="usx-heading"><div><h2>${title}</h2><p class="usx-subtitle">${desc}</p></div></div>`;return el;}
function drawBars(el,labels,values,unit){const w=580,h=176,p=30,max=Math.max(1,...values.filter(Number.isFinite));let parts=[`<svg class="usx-chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="${safeText(unit)} chart">`];values.forEach((v,i)=>{const bw=(w-p-18)/Math.max(values.length,1);const height=Number.isFinite(v)?Math.max(2,(v/max)*(h-64)):0;const x=p+i*bw+5,y=h-32-height;
 parts.push(`<rect x="${x}" y="${y}" width="${Math.max(2,bw-10)}" height="${height}" rx="4" fill="#aeea78"/><text x="${x+bw/2-5}" y="${h-12}" fill="#c4ded1" font-size="12" text-anchor="middle">${safeText(labels[i]||'')}</text><text x="${x+bw/2-5}" y="${Math.max(12,y-5)}" fill="#edf6df" font-size="11" text-anchor="middle">${Number.isFinite(v)?v.toFixed(0):'—'}</text>`)});parts.push('</svg>');el.innerHTML=parts.join('')}
function cityOptions(){return CITY_SEEDS.map(x=>`<option value="${safeText(x.name)}">${safeText(x.name)}</option>`).join('')}
function cityFromSelect(sel){return CITY_SEEDS.find(x=>x.name===sel.value)||CITY_SEEDS[0]}
function pageName(){const value=(document.body.dataset.page||'').toLowerCase(),path=location.pathname.split('/').pop().toLowerCase();const x=`${value} ${path}`;
 if(/intelligence-map/.test(x))return 'map';if(/assistant/.test(x))return 'assistant';if(/aqi|air-quality/.test(x))return 'aqi';if(/temperature|temp-map|heat-map/.test(x))return 'temperature';if(/saved|projects/.test(x))return 'projects';if(/cooling|assessment|planner/.test(x))return 'cooling';if(/city-plan|cityplan|planning|neighbourhood|neighborhood/.test(x))return 'city';if(/home|dashboard|index/.test(x))return 'home';return '';
}
function mount(){const page=pageName();if(!page||page==='map'||$('#usx-upgrades'))return;const main=$('main#main')||$('main.content')||$('main');if(!main)return;
 const panel=({home:homePanel,assistant:assistantPanel,temperature:temperaturePanel,aqi:aqiPanel})[page]?.();if(!panel)return;panel.id='usx-upgrades';const hero=$('.hero',main);if(hero)hero.insertAdjacentElement('afterend',panel);else main.prepend(panel);
}
function locationControls(prefix,comparison=false){
 const fields=`<label>State / UT <select id="${prefix}-state" class="usx-select" aria-label="Primary state"></select></label><label>City <select id="${prefix}-city" class="usx-select" aria-label="Primary city"></select></label>`;
 return fields+(comparison?`<label>Compare state / UT <select id="${prefix}-state2" class="usx-select" aria-label="Comparison state"></select></label><label>Compare city <select id="${prefix}-city2" class="usx-select" aria-label="Comparison city"></select></label>`:'');
}
async function setupLocations(prefix,comparison=false){
 const directory=await directoryPromise;
 const wire=(suffix,defaultState,defaultCity)=>{
  const state=$(`#${prefix}-state${suffix}`),city=$(`#${prefix}-city${suffix}`);
  populateStates(state,directory,defaultState);
  const update=()=>populateCities(city,directory,state.value,state.value===defaultState?defaultCity:null);
  state.addEventListener('change',update);update();
 };
 wire('','Maharashtra','Pune');
 if(comparison)wire('2','Maharashtra','Mumbai');
 return async suffix=>resolveCity($(`#${prefix}-state${suffix}`).value,$(`#${prefix}-city${suffix}`).value);
}
function homePanel(){
 const el=createPanel('Environmental snapshot & city comparison','Compare actual modelled conditions for any two listed Indian cities, across states and union territories.');
 el.innerHTML+=`<div class="usx-controls">${locationControls('usx-home',true)}<button id="usx-home-refresh" class="usx-button">Compare cities</button></div><div id="usx-home-results" class="usx-grid" style="margin-top:14px" aria-live="polite"></div><p class="usx-note">Weather: Open-Meteo, with MET Norway as a backup. Both report modelled 2 m air temperature. AQI: Open-Meteo (US scale, not CPCB). Backup and cached readings are identified; not an official alert.</p>`;
 setTimeout(async()=>{
  const box=$('#usx-home-results');
  try{
   const getCity=await setupLocations('usx-home',true);
   let seq=0;
   const refresh=async()=>{
    const token=++seq;box.innerHTML='<p class="usx-status">Loading both cities…</p>';
    const places=await Promise.allSettled([getCity(''),getCity('2')]);
    const responses=await Promise.allSettled(places.map(p=>p.status==='fulfilled'?fetchConditions(p.value):Promise.reject(p.reason)));
    if(token!==seq)return;
    box.innerHTML=responses.map((r,i)=>{
     const place=places[i].status==='fulfilled'?places[i].value:null;
     const name=place?`${place.name}, ${place.state}`:'Selected city';
     if(r.status==='rejected')return `<div class="usx-card"><h3>${safeText(name)}</h3><p class="usx-status">Data unavailable: ${safeText(r.reason?.message||'Location lookup failed')}</p></div>`;
     const w=r.value.weather?.current||{},q=r.value.air?.current||{},cat=aqiCategory(q.us_aqi);
     return `<div class="usx-card"><h3>${safeText(name)}</h3><div class="usx-grid" style="grid-template-columns:1fr 1fr;margin-top:10px"><div class="usx-stat"><span>Air temperature</span><b>${w.temperature_2m==null?'—':`${num(w.temperature_2m,1)}°C`}</b><small>${safeText(r.value.weather?.source||'Weather unavailable')}${r.value.weather?.source==='MET Norway'?' · forecast':''}${r.value.weather?.stale?' · cached reading':''}</small></div><div class="usx-stat"><span>US AQI</span><b>${num(q.us_aqi)}</b><small style="color:${cat.color}">${cat.label}</small></div></div><p class="usx-tiny">Weather: ${safeText(w.time||'unavailable')} IST · AQI: ${safeText(q.time||'unavailable')} IST${r.value.weather?.providerError?` · ${safeText(r.value.weather.providerError)}`:''}</p></div>`;
    }).join('');
   };
   $('#usx-home-refresh').addEventListener('click',refresh);refresh();
  }catch(e){box.textContent=`City directory unavailable: ${e.message}`;}
 },0);
 return el;
}
const budgetRatios={balanced:[.29,.22,.16,.13,.12,.08],economy:[.38,.13,.12,.15,.13,.09],heat:[.23,.35,.20,.10,.07,.05]};
const allocations=['Trees & establishment','Reflective roof / surface works','Shade & pedestrian comfort','Rain gardens / permeable surfaces','Maintenance provision','Contingency'];
function coolingPanel(){const el=createPanel('Scenario budget planner & visual comparison','Explore hypothetical allocations without replacing or changing your existing cooling assessment.');el.innerHTML+=`<div class="usx-controls"><label>Budget (₹) <input id="usx-cool-budget" class="usx-input" inputmode="numeric" type="number" min="10000" max="500000000" step="10000" value="1500000"></label><label>Scenario <select id="usx-cool-mode" class="usx-select"><option value="balanced">Balanced</option><option value="economy">Budget-conscious</option><option value="heat">Heat-first</option></select></label><button id="usx-cool-save" class="usx-button secondary">Save scenario</button></div><div id="usx-cool-result" class="usx-table-wrap"></div><div class="usx-2col" style="margin-top:12px"><div class="usx-card"><h3>Before · No new interventions</h3><p class="usx-subtitle">Existing conditions remain the starting point. Site heat, shade and runoff have not been measured.</p></div><div class="usx-card"><h3>After · Proposed intervention mix</h3><div id="usx-cool-after"></div></div></div><p class="usx-note">This is a scenario illustration, not a site-specific prediction of temperature reduction, contractor pricing or savings. No measured “°C improvement” is claimed. Your existing cooling planner remains unchanged.</p><div id="usx-cool-msg" class="usx-tiny" aria-live="polite"></div>`;
 setTimeout(()=>{const calc=()=>{const val=Math.max(0,Math.min(5e8,Number($('#usx-cool-budget').value)||0)),mode=$('#usx-cool-mode').value,ratios=budgetRatios[mode];$('#usx-cool-result').innerHTML=`<table class="usx-table"><thead><tr><th>Intervention</th><th>Share</th><th>Planning allowance</th></tr></thead><tbody>${allocations.map((a,i)=>`<tr><td>${safeText(a)}</td><td>${Math.round(ratios[i]*100)}%</td><td>${money(Math.round(val*ratios[i]))}</td></tr>`).join('')}</tbody></table>`;$('#usx-cool-after').innerHTML=allocations.slice(0,4).map((name,i)=>`<div class="usx-tiny">${safeText(name)} · ${Math.round(ratios[i]*100)}%</div><div class="usx-bar"><i style="width:${ratios[i]*100*2.4}%"></i></div>`).join('');return {budget:val,scenario:mode,allocations:allocations.map((name,i)=>({name,amount:Math.round(val*ratios[i])}))};};$('#usx-cool-budget').addEventListener('input',calc);$('#usx-cool-mode').addEventListener('change',calc);$('#usx-cool-save').addEventListener('click',()=>{const data=storageGet('usx.scenarios',[]);data.unshift({...calc(),created:new Date().toISOString()});storageSet('usx.scenarios',data.slice(0,20));$('#usx-cool-msg').textContent='Illustrative scenario saved in this browser (separate from original saved projects).';});calc();},0);return el;}
function projectsPanel(){const el=createPanel('Project progress & comparison','Add optional progress metadata to detected local projects. The original project records are never edited.');el.innerHTML+=`<div id="usx-project-list" aria-live="polite"></div><div class="usx-controls" style="margin-top:14px"><label>Compare <select class="usx-select" id="usx-p1"></select></label><label>with <select class="usx-select" id="usx-p2"></select></label><button class="usx-button secondary" id="usx-compare-projects">Compare projects</button></div><div id="usx-project-compare"></div><p class="usx-note">Only projects found in recognized browser storage formats are displayed. Some installations may need a storage adapter; adding status/progress does not modify your original saved project data.</p>`;
 setTimeout(()=>{const projects=getExistingProjects();const box=$('#usx-project-list'),meta=storageGet('usx.projectProgress',{});if(!projects.length){box.innerHTML=`<p class="usx-status">No compatible saved projects detected. Create a project using your existing site; we will not create fake records.</p>`;return;}
 box.innerHTML=projects.map(p=>{const key=encodeURIComponent(p.id),m=meta[p.id]||{};return `<div class="usx-project-row" data-key="${key}"><strong>${safeText(p.name)}</strong><select class="usx-select" data-action="status" aria-label="Status for ${safeText(p.name)}"><option>Planned</option><option>In progress</option><option>On hold</option><option>Completed</option></select><label class="usx-tiny">Progress %<input class="usx-input" data-action="progress" type="number" min="0" max="100" value="${Number(m.progress)||0}" style="width:85px" aria-label="Progress for ${safeText(p.name)}"></label><div class="usx-tiny">${safeText(p.city||'City not supplied')} · ${p.budget!=null?money(p.budget):'Budget unavailable'}</div></div>`}).join('');
 box.querySelectorAll('[data-key]').forEach(row=>{const key=decodeURIComponent(row.dataset.key),old=meta[key]||{};row.querySelector('[data-action="status"]').value=old.status||'Planned';row.querySelectorAll('[data-action]').forEach(x=>x.addEventListener('change',()=>{const cur=storageGet('usx.projectProgress',{});cur[key]={status:row.querySelector('[data-action="status"]').value,progress:Math.min(100,Math.max(0,Number(row.querySelector('[data-action="progress"]').value)||0)),updated:new Date().toISOString()};storageSet('usx.projectProgress',cur)}));});
 const opts=projects.map((p,i)=>`<option value="${i}">${safeText(p.name)}</option>`).join('');$('#usx-p1').innerHTML=opts;$('#usx-p2').innerHTML=opts;$('#usx-p2').value=String(Math.min(1,projects.length-1));$('#usx-compare-projects').addEventListener('click',()=>{const [a,b]=[projects[Number($('#usx-p1').value)],projects[Number($('#usx-p2').value)]];const m=storageGet('usx.projectProgress',{});$('#usx-project-compare').innerHTML=`<div class="usx-table-wrap"><table class="usx-table"><tr><th>Metric</th><th>${safeText(a.name)}</th><th>${safeText(b.name)}</th></tr><tr><td>Budget</td><td>${a.budget==null?'Unavailable':money(a.budget)}</td><td>${b.budget==null?'Unavailable':money(b.budget)}</td></tr><tr><td>City</td><td>${safeText(a.city||'Unavailable')}</td><td>${safeText(b.city||'Unavailable')}</td></tr><tr><td>Status</td><td>${safeText(m[a.id]?.status||'Planned')}</td><td>${safeText(m[b.id]?.status||'Planned')}</td></tr><tr><td>Progress</td><td>${m[a.id]?.progress||0}%</td><td>${m[b.id]?.progress||0}%</td></tr></table></div>`;});},0);return el;}
function assistantPanel(){const el=createPanel('Use real project context','Give the offline assistant a project-specific question. It should only use details available on this device.');el.innerHTML+=`<div class="usx-controls"><button class="usx-button secondary" data-prompt="Summarize the selected project and its budget">Project summary</button><button class="usx-button secondary" data-prompt="What should be the next three steps for this project?">Next actions</button><button class="usx-button secondary" data-prompt="What information is missing from this project?">Missing data</button></div><p class="usx-note">These buttons fill your existing assistant question input. Detailed project answers still depend on the current offline assistant's storage compatibility and knowledge rules.</p>`;setTimeout(()=>el.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>{const input=$('#chatInput')||$('#chatForm input[name="question"]');if(input){input.value=b.dataset.prompt;input.focus();}})),0);return el;}
function temperaturePanel(){const el=createPanel('Recent temperature trends & heat screening','A seven-day daily-maximum temperature history from Open-Meteo model data at the selected city-center coordinate.');el.innerHTML+=`<div class="usx-controls"><label>City <select id="usx-temp-city" class="usx-select">${cityOptions()}</select></label><button id="usx-temp-load" class="usx-button">Load recent trend</button></div><div id="usx-temp-data" aria-live="polite"></div><p class="usx-note">Daily max readings are modelled 2-metre air temperatures, not surface temperature or street-level heat maps. Screening tags are not official heat alerts.</p>`;
 setTimeout(()=>{const load=async()=>{const box=$('#usx-temp-data');box.innerHTML='<p class="usx-status">Loading modelled history…</p>';try{const data=await fetchConditions(cityFromSelect($('#usx-temp-city')),{history:true}),d=data.weather?.daily;if(!d){box.innerHTML=`<p class="usx-status">Temperature trend unavailable: ${safeText(data.weatherError||'source returned no daily data')}</p>`;return;}const labels=d.time.slice(-8,-1).map(x=>x.slice(5)),vals=d.temperature_2m_max.slice(-8,-1);box.innerHTML=`<div class="usx-stat"><span>Latest available daily maximum</span><b>${num(vals.at(-1),1)}°C</b><small>${safeText(heatCategory(vals.at(-1)))}</small></div><div id="usx-temp-chart"></div>`;drawBars($('#usx-temp-chart'),labels,vals,'Daily maximum temperature °C');}catch(e){box.innerHTML=`<p class="usx-status">Temperature history unavailable (${safeText(e.message)}). Existing map is unaffected.</p>`;}};$('#usx-temp-load').addEventListener('click',load);load();},0);return el;}
function aqiPanel(){
 const el=createPanel('AQI guidance & pollutants','Select any state or union territory and city to inspect modelled pollutant readings and outdoor activity guidance.');
 el.innerHTML+=`<div class="usx-controls">${locationControls('usx-aqi')}<button id="usx-aqi-load" class="usx-button">Get guidance</button></div><div id="usx-aqi-data" aria-live="polite"></div><p class="usx-note">This page uses the <b>US AQI</b> metric where available, not the official Indian CPCB AQI. Forecast/model information is not a substitute for local monitoring or medical guidance.</p>`;
 setTimeout(async()=>{
  const box=$('#usx-aqi-data');
  try{
   const getCity=await setupLocations('usx-aqi');let seq=0;
   const load=async()=>{
    const token=++seq;box.innerHTML='<p class="usx-status">Checking pollutants…</p>';
    try{
     const city=await getCity(''),d=await fetchConditions(city),q=d.air?.current;
     if(token!==seq)return;
     if(!q){box.innerHTML=`<p class="usx-status">AQI data unavailable: ${safeText(d.airError||'no readings')}</p>`;return;}
     const cat=aqiCategory(q.us_aqi);
     box.innerHTML=`<div class="usx-card"><h3>${safeText(city.name)}, ${safeText(city.state)}</h3><div class="usx-grid"><div class="usx-stat"><span>US AQI</span><b style="color:${cat.color}">${num(q.us_aqi)}</b><small>${cat.label}</small></div>${[['PM2.5',q.pm2_5],['PM10',q.pm10],['NO₂',q.nitrogen_dioxide],['Ozone',q.ozone]].map(([k,v])=>`<div class="usx-stat"><span>${k}</span><b>${num(v,1)}</b><small>µg/m³ (model estimate)</small></div>`).join('')}</div><div class="usx-status"><b>Activity guidance:</b> ${cat.note}</div><p class="usx-tiny">Source time: ${safeText(q.time||'unavailable')}</p></div>`;
    }catch(e){if(token===seq)box.innerHTML=`<p class="usx-status">AQI unavailable (${safeText(e.message)}).</p>`;}
   };
   $('#usx-aqi-load').addEventListener('click',load);load();
  }catch(e){box.textContent=`City directory unavailable: ${e.message}`;}
 },0);
 return el;
}

if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
