/**
 * Screening model for illustrative incoming roof solar absorption.
 * This intentionally does NOT estimate indoor air temperature, electricity bills,
 * heat flux through building envelopes, or certified cooling performance.
 * Solar irradiance, reflectance, and shaded fractions are user assumptions.
 */
export const finite=(value,min,max,fallback)=>{const x=Number(value);return Number.isFinite(x)?Math.min(max,Math.max(min,x)):fallback};
export const defaultReflectance=roof=>roof==='metal'?.34:roof==='tile'?.35:.24;
export function compareRoofSolar({length,width,roof='concrete',reflective=false,shade=false,trees=false,solarFlux=800}){
 const area=finite(length,3,80,12)*finite(width,3,80,9);
 const beforeR=defaultReflectance(roof),afterR=reflective?.67:beforeR;
 // Shade area is applied once, not added to the percentage reduction after coating.
 const shadeFactor=Math.min(.6,(shade?.20:0)+(trees?.08:0));
 const base=area*finite(solarFlux,0,1400,800)*(1-beforeR)/1000;
 const after=area*finite(solarFlux,0,1400,800)*(1-afterR)*(1-shadeFactor)/1000;
 return {area,base,after,change:base>0?Math.max(0,(1-after/base)*100):0,shadeFactor};
}
export function solarEstimate({capacity,peakHours,performance,annualUse,tariff,priceKw,subsidy}){
 const annualGeneration=finite(capacity,0,1000,0)*finite(peakHours,0,10,0)*365*finite(performance,0,1,.75);
 const billOffsetKwh=Math.min(annualGeneration,finite(annualUse,0,1e7,0));
 const annualSaving=billOffsetKwh*finite(tariff,0,100,0);
 const installedCost=finite(capacity,0,1000,0)*finite(priceKw,0,1e7,0);
 const netCost=Math.max(0,installedCost-finite(subsidy,0,1e8,0));
 return {annualGeneration,billOffsetKwh,annualSaving,installedCost,netCost,payback:annualSaving>0?netCost/annualSaving:null};
}
export function rainwaterEstimate({area,rainfall,efficiency,dailyUse}){
 const liters=finite(area,0,1e6,0)*finite(rainfall,0,1e5,0)*finite(efficiency,0,1,0);
 return {liters,equivalentDays:liters/Math.max(1,finite(dailyUse,1,1e7,1))};
}
