/** Shared editable floor plan for Urban Sentinel 3D Simulation.
 * Every coordinate is relative to the building envelope; physical scale lives in the property profile.
 * Screening visualization, NOT CFD, heat-transfer certification, or an as-built BIM model.
 */
import {getProfile} from './property-profile.js';
import {getEnergy,saveEnergy,getHome,thermalEstimate} from './home-energy-model.js';
export const DESIGN_KEY='us4.simulation.design.v1';
export const KINDS={
 window:{name:'Window',group:'Openings',wall:true,wind:true},door:{name:'Door',group:'Openings',wall:true,wind:true},vent:{name:'Air vent',group:'Openings',wall:true,wind:true},exhaust:{name:'Exhaust fan',group:'Airflow',wall:true,wind:true},
 ac:{name:'Air conditioner',group:'Cooling',energy:'acCount'},fans:{name:'Ceiling fan',group:'Cooling',energy:'fanCount'},cooler:{name:'Air cooler',group:'Cooling'},heater:{name:'Space heater',group:'Heating'},
 lights:{name:'LED lighting',group:'Electrical',energy:'lightsCount'},fridge:{name:'Refrigerator',group:'Electrical',energy:'fridgeCount'},solar:{name:'Solar panel',group:'Envelope'},
 shade:{name:'External awning',group:'Envelope',wall:true},insulation:{name:'Insulation panel',group:'Envelope',wall:true},curtain:{name:'Thermal curtain',group:'Envelope',wall:true},
 tree:{name:'Shade tree',group:'Outside'},bed:{name:'Bed',group:'Furniture'},sofa:{name:'Sofa',group:'Furniture'},desk:{name:'Desk',group:'Furniture'},counter:{name:'Kitchen counter',group:'Furniture'}
};
const applianceTypes=['ac','fans','lights','fridge'];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0));
const id=()=>`o${Date.now().toString(36)}${Math.random().toString(36).slice(2,7)}`;
export function makeObject(kind,floor=0,x=0,y=0,wall='north',extra={}){return {id:id(),kind,floor:Math.round(clamp(floor,0,5)),x:clamp(x,-.90,.90),y:clamp(y,-.90,.90),wall:['north','south','east','west'].includes(wall)?wall:'north',open:true,...extra}}
export function getDesign(){let stored={};try{stored=JSON.parse(localStorage.getItem(DESIGN_KEY)||'{}')||{}}catch{}
 const objects=Array.isArray(stored.objects)?stored.objects.filter(o=>o&&KINDS[o.kind]).slice(0,450):[];
 return {version:1,objects,selectedFloor:Math.round(clamp(stored.selectedFloor??0,0,5)),guided:stored.guided||{},windSpeed:clamp(stored.windSpeed??3.5,0,15),windFrom:stored.windFrom||'west',simulation:Boolean(stored.simulation),mode:stored.mode||'heat',hasGuided:Boolean(stored.hasGuided)};
}
export function saveDesign(value){const state={...getDesign(),...value};try{localStorage.setItem(DESIGN_KEY,JSON.stringify(state));window.dispatchEvent(new CustomEvent('urban-design-change',{detail:state}))}catch{}return state}
export function floorObjects(design,floor){return design.objects.filter(o=>o.floor===floor)}
export function placementArrays(design,floor){const list=floorObjects(design,floor);return Object.fromEntries(applianceTypes.map(t=>[t,list.filter(o=>o.kind===t).map(o=>[o.x*4.5,o.y*3.3])]))}
export function floorEnergy(design,floor,base=getEnergy()){const out={...base};for(const [kind,k] of Object.entries(KINDS))if(k.energy)out[k.energy]=floorObjects(design,floor).filter(o=>o.kind===kind).length;return out}
export function syncEnergyFromDesign(design){const changes={};for(const [kind,k] of Object.entries(KINDS))if(k.energy)changes[k.energy]=design.objects.filter(o=>o.kind===kind).length;return saveEnergy(changes)}
export function importAppliancesFromEnergy(design,energy=getEnergy(),floor=0){const next=[...design.objects];for(const kind of applianceTypes){const key=KINDS[kind].energy,desired=Math.round(clamp(energy[key],0,35)),matches=next.filter(o=>o.kind===kind);for(let i=matches.length;i<desired;i++){const n=i%8;next.push(makeObject(kind,floor,((n%4)-1.5)*.31,(Math.floor(n/4)-.5)*.65));}for(let i=matches.length-1;i>=desired;i--){const ix=next.findIndex(o=>o.id===matches[i].id);if(ix>=0)next.splice(ix,1)}}return {...design,objects:next}}
export function autoLayout(answers,profile=getProfile(),energy=getEnergy()){
 const floors=Math.round(clamp(answers.floors||profile.floors||1,1,6));const windows=Math.round(clamp(answers.windows??2,0,12));const wall=answers.windowWall||profile.windowSide||'east';const windowWalls=wall==='mixed'?['east','west']:wall==='opposite'?['east','west']:[wall];
 const objects=[];
 for(let floor=0;floor<floors;floor++){
  for(let i=0;i<windows;i++){const side=windowWalls[i%windowWalls.length],countOnSide=Math.ceil((windows-(i%windowWalls.length))/windowWalls.length),index=Math.floor(i/windowWalls.length);const along=(index+1)/(countOnSide+1)*1.68-.84;objects.push(makeObject('window',floor,side==='east'?.87:side==='west'?-.87:along,side==='north'?.87:side==='south'?-.87:along,side,{open:answers.openWindows!=='closed'}));}
  if(answers.door!==false)objects.push(makeObject('door',floor,0,-.87,'south',{open:floor===0}));
  if(Number(answers.vents)||answers.ventilation==='good')objects.push(makeObject('vent',floor,.84,.16,'east'));
 }
 const quantities={ac:Math.round(clamp(answers.ac??energy.acCount,0,24)),fans:Math.round(clamp(answers.fans??energy.fanCount,0,36)),lights:Math.round(clamp(answers.lights??energy.lightsCount,0,48)),fridge:Math.round(clamp(answers.fridge??energy.fridgeCount,0,12))};
 for(const [kind,count] of Object.entries(quantities))for(let i=0;i<count;i++){const floor=i%floors,j=Math.floor(i/floors);objects.push(makeObject(kind,floor,((j%4)-1.5)*.37,(Math.floor(j/4)%3-1)*.43));}
 if(answers.exhaust)for(let floor=0;floor<floors;floor++)objects.push(makeObject('exhaust',floor,.86,-.30,'east'));
 if(answers.roofShade)objects.push(makeObject('shade',floors-1,.1,-.86,'south'));
 if(answers.solar)objects.push(makeObject('solar',floors-1,-.24,.1,'north'));
 if(answers.insulation)objects.push(makeObject('insulation',floors-1,.12,.86,'north'));
 if(answers.trees)for(let i=0;i<Math.round(clamp(answers.trees,0,8));i++)objects.push(makeObject('tree',0,i%2?.82:-.82,i%3?.72:-.72));
 return {version:1,objects,selectedFloor:Math.min(floors-1,0),guided:{...answers,floors},windSpeed:clamp(answers.windSpeed??3.5,0,15),windFrom:answers.windFrom||'west',hasGuided:true,simulation:false,mode:'heat'};
}
const normals={north:[0,1],south:[0,-1],east:[1,0],west:[-1,0]};
export function floorSimulation(design,profile=getProfile(),home=getHome(),floor=0){
 const objects=floorObjects(design,floor),openings=objects.filter(o=>['window','door','vent','exhaust'].includes(o.kind)&&o.open!==false);const windDir=normals[design.windFrom]||normals.west;
 // Incoming wind travels opposite the named origin direction. Only facing openings have substantial pressure.
 const incoming=openings.filter(o=>{const n=normals[o.wall]||[0,0];return n[0]*windDir[0]+n[1]*windDir[1]>.55});
 const outgoing=openings.filter(o=>{const n=normals[o.wall]||[0,0];return n[0]*windDir[0]+n[1]*windDir[1]<-.55});
 const windSpeed=clamp(design.windSpeed,0,15),openArea=openings.reduce((s,o)=>s+({window:1.1,door:1.8,vent:.35,exhaust:.28}[o.kind]||0),0);
 const crossFlow=incoming.length>0&&outgoing.length>0;const index=Math.min(100,Math.round(windSpeed*(incoming.length?8:1.8)*(crossFlow?1.45:.55)+openArea*2.5+objects.filter(o=>o.kind==='exhaust').length*6));
 const ac=objects.filter(o=>o.kind==='ac').length,fans=objects.filter(o=>o.kind==='fans').length,heater=objects.filter(o=>o.kind==='heater').length,lights=objects.filter(o=>o.kind==='lights').length,fridge=objects.filter(o=>o.kind==='fridge').length;
 const roofRisk=Number(profile.floors)-1===floor?12:0;const solar=Number.isFinite(Number(home.irradiance))?Math.max(0,Number(home.irradiance)):800;const area=(Number(profile.length)||12)*(Number(profile.width)||9);
 const absorbedKw=thermalEstimate({home:{...home,irradiance:solar},profile,energy:getEnergy()}).roofAbsorbed;
 // Qualitative screening index, not a temperature estimate or a CFD simulation.
 const base=58+roofRisk+(solar>700?7:solar<200?-6:0)-(home.roofInsulation&&roofRisk?12:0)-(home.roofCoating&&roofRisk?10:0);
 const addedInsulation=objects.filter(o=>o.kind==='insulation').length,addedShade=objects.filter(o=>['shade','curtain'].includes(o.kind)).length,trees=objects.filter(o=>o.kind==='tree').length,coolers=objects.filter(o=>o.kind==='cooler').length;
 const heatScore=Math.round(clamp(base-ac*10-fans*2.5-index*.10+heater*12+fridge*2+lights*.25-addedInsulation*6-addedShade*3-trees*1.5-coolers*3,0,100));
 return {openings:openings.length,inlet:incoming.length,outlet:outgoing.length,crossFlow,openArea,windSpeed,windFrom:design.windFrom,airflowIndex:index,heatScore,ac,fans,heater,roofAbsorbedKw:absorbedKw,qualifier:'Scenario sensitivity only · not measured temperature, CFD, or a validated comfort prediction'};
}
