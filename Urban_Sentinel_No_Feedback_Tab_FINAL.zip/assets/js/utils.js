export const money=n=>'₹'+Math.round(n).toLocaleString('en-IN');
export const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export const mean=nums=>nums.length?nums.reduce((a,b)=>a+b,0)/nums.length:NaN;
export function heatColor(v){return v>=8.2?'#e47a6d':v>=7.4?'#e7a45b':v>=6.4?'#d6c56b':'#74b5a1'}
export function tempColor(v){return v>=39?'#e27065':v>=35?'#e29d5c':v>=31?'#c9b35b':v>=27?'#6daea2':'#458cba'}
export function csvDownload(filename,headers,rows){const escape=v=>'"'+String(v??'').replaceAll('"','""')+'"';const data=[headers,...rows].map(row=>row.map(escape).join(',')).join('\r\n');const blob=new Blob(['\ufeff'+data],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000)}
export const amazon=q=>'https://www.amazon.in/s?k='+encodeURIComponent(q);
