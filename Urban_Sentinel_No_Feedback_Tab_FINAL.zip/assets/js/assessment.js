import {buildPlan,options,problems} from './recommendations.js';
import {clamp} from './utils.js';
export const kinds={home:'Home / apartment',school:'School / classroom',shop:'Shop / workplace',neighbourhood:'Housing society / community'};
export const roofLabels={concrete:'Exposed RCC/concrete',tile:'Tiled / sloping',metal:'Metal sheet',unknown:'Not sure / other'};
export const sunLabels={high:'Strong afternoon sun',medium:'Some direct sun',low:'Mostly shaded'};
export const ventilationLabels={poor:'Stuffy / little airflow',average:'Some airflow',good:'Good cross-ventilation'};
export function sanitizeInput(raw={}){
 const kind=kinds[raw.kind]?raw.kind:'home',problem=problems[raw.problem]?raw.problem:'heat';
 return {kind,problem,name:String(raw.name||'My cooling project').trim().slice(0,100),locality:String(raw.locality||raw.city||'').trim().slice(0,100),state:String(raw.state||'').trim().slice(0,80),city:String(raw.city||'').trim().slice(0,100),area:clamp(Number(raw.area)||500,50,100000),people:clamp(Number(raw.people)||4,1,20000),budget:clamp(Number(raw.budget)||50000,10000,1500000),roof:roofLabels[raw.roof]?raw.roof:'unknown',sun:sunLabels[raw.sun]?raw.sun:'medium',ventilation:ventilationLabels[raw.ventilation]?raw.ventilation:'average',floor:String(raw.floor||'middle').slice(0,30),windowSide:String(raw.windowSide||'mixed').slice(0,30),indoorTemp:raw.indoorTemp!==''&&Number.isFinite(Number(raw.indoorTemp))&&Number(raw.indoorTemp)>=10&&Number(raw.indoorTemp)<=55?Number(raw.indoorTemp):null,notes:String(raw.notes||'').trim().slice(0,1000)};
}
export function assess(input){
 const details=sanitizeInput(input),base=buildPlan({...details});
 const {roof,sun,ventilation,kind,problem}=details;
 const flags=[];
 if(roof==='metal'||(roof==='concrete'&&details.floor==='top'))flags.push({level:'high',title:'Roof heat gain',detail:'Investigate roof shade, solar reflectance and appropriate insulation after checking waterproofing and structural conditions.'});
 if(details.windowSide==='west'&&sun!=='low')flags.push({level:'medium',title:'Afternoon-facing glazing',detail:'Check west-facing windows for strong afternoon solar gain; consider compatible exterior shading or film.'});
 if(sun==='high')flags.push({level:'high',title:'Strong solar exposure',detail:'Start with external shading and window solar control where compatible.'});
 if(ventilation==='poor')flags.push({level:'medium',title:'Limited air exchange',detail:'Assess fresh-air routes and ventilation before making the space more airtight.'});
 if(details.people/details.area>0.07)flags.push({level:'medium',title:'High occupancy relative to floor area',detail:'Review ventilation, occupancy and safety with a qualified professional.'});
 if(!flags.length)flags.push({level:'info',title:'No obvious major exposure flag',detail:'Begin with a measured heat walkthrough and compare indoor readings at several times.'});
 let order=[...base.plan];
 const preference=o=>{
  const n=o.id;
  let score=100-(o.priority||8)*5;
  if(sun==='high'&&['thermal-curtain','solar-film','entrance-shade'].includes(n))score+=35;
  if((roof==='metal'||(roof==='concrete'&&details.floor==='top'))&&['roof-paint','thermal-insulation'].includes(n))score+=28;
  if(ventilation==='poor'&&['vent-audit','exhaust-fan'].includes(n))score+=24;
  if(problem==='heat'&&n==='heat-audit')score+=40;
  if(kind==='school'&&n==='inverter-ac')score-=5;
  return score;
 };
 order.sort((a,b)=>preference(b)-preference(a));
 const steps=order.map((item,i)=>({id:item.id,title:item.name,cost:item.spent,quantity:item.qty,coverage:item.coverage?Math.min(details.area,item.coverage*item.qty):null,why:item.why,how:item.steps,category:item.tag,kind:item.kind,query:item.query||null,phase:i<Math.min(2,order.length)?'Start here':'Next step',verified:false}));
 const cautions={
  home:['Focus on the most uncomfortable occupied room first; consider ventilation even if using AC.'],
  school:['Check student occupancy, emergency exits, classroom fresh-air provision and child-safe mounting before installing equipment.','Schedule works to avoid classroom disruption and obtain school management approvals.'],
  shop:['Keep entrances, escape routes and customer queues safe. Check signage permissions, working hours and electricity cost.'],
  neighbourhood:['Obtain society committee approvals and written scopes before shared-area works.','Use documented quotes and compare long-term maintenance obligations.']
 }[kind];
 const notes=[
  ...cautions,
  'Costs are preliminary planning estimates, not supplier quotations or verified live prices.',
  'No reliable temperature reduction is predicted. Modelled outdoor temperatures must not be treated as indoor readings.',
  'Before structural, electrical, glazing, fire-safety or HVAC work, consult a qualified professional.',
  'A professional survey may change which interventions are appropriate. Coverage estimates are nominal, not guaranteed performance.'
 ];
 return {...details,flags,steps,spent:base.spent,remaining:base.remaining,alternatives:base.alternatives.map(o=>({name:o.name,cost:o.cost})),notes};
}
export function reportLines(r){
 const now=new Date().toLocaleString('en-IN');
 return [
 'URBAN SENTINEL - COOLING ASSESSMENT','',`Prepared: ${now}`,`Project: ${r.name}`,`Space: ${kinds[r.kind]}`,`Locality: ${r.locality}`,`Area: ${r.area} sq ft | Occupancy: ${r.people}`,
 `Problem: ${problems[r.problem]}`,`Roof: ${roofLabels[r.roof]} | Solar exposure: ${sunLabels[r.sun]}`,`Ventilation: ${ventilationLabels[r.ventilation]}`,`State: ${r.state||'Not set'} | City: ${r.city||'Not set'}` ,`Floor: ${r.floor} | Windows: ${r.windowSide}`,`Indoor temperature (user entered): ${r.indoorTemp===null?'Not supplied':r.indoorTemp+' C'}`,
 '',`BUDGET: INR ${r.budget.toLocaleString('en-IN')}`,`ESTIMATED PLAN: INR ${r.spent.toLocaleString('en-IN')}`,`UNALLOCATED: INR ${r.remaining.toLocaleString('en-IN')}`,'','SCREENING NOTES:',
 ...r.flags.map(f=>`- ${f.title}: ${f.detail}`),'','RECOMMENDED ACTIONS:',
 ...r.steps.flatMap((s,i)=>[`${i+1}. ${s.title} | INR ${s.cost.toLocaleString('en-IN')} | Qty ${s.quantity}`,`   ${s.phase} | ${s.why}`,`   Action: ${s.how}`]),
 '','ASSUMPTIONS AND LIMITATIONS:',...r.notes.map(n=>'- '+n),'',`Additional notes: ${r.userNotes||''}`, '', 'Urban Sentinel - preliminary decision support, not professional engineering advice.'
 ];
}
