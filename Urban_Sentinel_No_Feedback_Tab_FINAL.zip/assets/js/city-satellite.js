import {createSiteMap,searchCity} from './satellite-map.js';
const status=document.getElementById('ciSatellitePlace');
let mapWidget=null,serial=0;
async function refreshMap(){
 const city=document.getElementById('ciCity')?.value||'Pune',state=document.getElementById('ciState')?.value||'Maharashtra',run=++serial;
 if(status)status.textContent=`Locating ${city}, ${state} on the satellite layer…`;
 try{const found=await searchCity(city);if(run!==serial)return;
  if(!mapWidget)mapWidget=await createSiteMap('ciSatelliteMap',{lat:found.lat,lon:found.lon,zoom:12});
  else mapWidget.update(found.lat,found.lon,12);
  if(status)status.textContent=`${found.label} · ${found.lat.toFixed(3)}°N, ${found.lon.toFixed(3)}°E. Historical Sentinel-2 satellite mosaic; not a live heat or AQI layer.`;
 }catch(e){if(run===serial&&status)status.textContent=`Could not locate ${city}: ${e.message}. City readings remain available above.`;}
}
const selectCity=document.getElementById('ciCity');
if(selectCity){selectCity.addEventListener('change',refreshMap);document.getElementById('ciState')?.addEventListener('change',()=>setTimeout(refreshMap,250));setTimeout(refreshMap,750)}
