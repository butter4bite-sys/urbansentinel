/* Shared screening assumptions for House Climate Studio and Energy & Savings.
 * Illustrative, not a validated thermal/CFD/energy simulation. */
export const ENERGY_KEY='us4.calc.electricity';
export const HOME_KEY='us4.climate.home';
export const ENERGY_DEFAULTS={units:260,tariff:9,acCount:1,acKw:1.2,acHrs:4,acDays:25,fanKw:0.07,fanCount:3,fanHrs:9,lightsCount:6,lightsW:9,lightsHrs:5,fridgeCount:1,fridgeKw:0.045,other:40};
export const HOME_DEFAULTS={ambient:34,irradiance:800,roofCoating:false,roofInsulation:false,shade:15,trees:2,cutaway:true,thermal:true};
const clamp=(v,min,max,d)=>{const x=Number(v);return Number.isFinite(x)?Math.min(max,Math.max(min,x)):d};
export function getEnergy(){let data={};try{data=JSON.parse(localStorage.getItem(ENERGY_KEY)||'{}')||{}}catch{};
 // Existing saved bills predate lights/fridge fields: never silently double-count their old other bucket.
 const legacy=Object.keys(data).length>0&&!('lightsCount' in data);
 const obj={...ENERGY_DEFAULTS,...(legacy?{lightsCount:0,fridgeCount:0}:{}),...data};
 for(const [k,v] of Object.entries(ENERGY_DEFAULTS))obj[k]=clamp(obj[k],0,k==='tariff'?200:100000,v);
 for(const k of ['acCount','fanCount','lightsCount','fridgeCount'])obj[k]=Math.round(clamp(obj[k],0,35,0));
 return obj;
}
export function saveEnergy(data){const value={...getEnergy(),...data};try{localStorage.setItem(ENERGY_KEY,JSON.stringify(value));window.dispatchEvent(new CustomEvent('urban-energy-change',{detail:value}))}catch{}return value}
export function getHome(){let d={};try{d=JSON.parse(localStorage.getItem(HOME_KEY)||'{}')||{}}catch{}return {...HOME_DEFAULTS,...d}}
export function saveHome(data){const v={...getHome(),...data};try{localStorage.setItem(HOME_KEY,JSON.stringify(v))}catch{}return v}
export function energyBreakdown(x=getEnergy()){
 const loads={ac:x.acCount*x.acKw*x.acHrs*x.acDays,fans:x.fanKw*x.fanCount*x.fanHrs*30,lights:x.lightsCount*x.lightsW/1000*x.lightsHrs*30,fridge:x.fridgeCount*x.fridgeKw*24*30,other:x.other};
 const total=Object.values(loads).reduce((a,b)=>a+b,0);
 return {loads,total,difference:x.units-total,costs:Object.fromEntries(Object.entries(loads).map(([k,v])=>[k,v*x.tariff]))};
}
export function thermalEstimate({energy=getEnergy(),home=getHome(),profile={}}={}){
 const length=clamp(profile.length,3,80,12),width=clamp(profile.width,3,80,9),area=length*width;
 const ambient=clamp(home.ambient,15,48,34),irr=clamp(home.irradiance,0,1200,800);
 const reflectance=home.roofCoating?0.67:profile.roof==='metal'?0.38:profile.roof==='tile'?0.3:0.22;
 const shade=clamp(home.shade,0,85,15)/100;
 const roofAbsorbed=area*irr*(1-reflectance)*(1-shade)/1000;
 // Rule-of-thumb design sensitivity (NOT physically calibrated temperature prediction).
 const roofTransfer=(roofAbsorbed/Math.max(6,area*0.65))*(home.roofInsulation?1.1:3.0);
 const otherPower=energy.lightsCount*energy.lightsW/1000+energy.fridgeCount*energy.fridgeKw+0.22;
 const passive=ambient+roofTransfer+Math.min(1.4,otherPower*0.65);
 // AC electricity -> illustrative cooling capacity using fixed COP 2.8, spread over total area.
 const coolingCapacity=energy.acCount*energy.acKw*2.8;
 const coolingEffect=Math.min(8,coolingCapacity*2.35/(area/40+1));
 const indoor=Math.max(18,passive-coolingEffect);
 // Fans move air; they do not lower room dry-bulb temperature.
 const fanRelief=Math.min(1.5,Math.log1p(energy.fanCount)*0.55);
 const comfortEquivalent=indoor-fanRelief;
 const heatIndex=clamp((comfortEquivalent-23)*6.8,0,100,65);
 return {area,ambient,irr,roofAbsorbed,reflectance,shade,passive,coolingCapacity,coolingEffect,indoor,fanRelief,comfortEquivalent,heatIndex};
}
export const thermalColor=(t)=>{
 // Heat risk index: blue -> turquoise -> green -> yellow -> orange -> red.
 const stops=[[0,[34,84,216]],[22,[17,195,217]],[43,[49,198,128]],[63,[220,229,69]],[82,[255,149,51]],[100,[240,65,61]]];
 const x=Math.max(0,Math.min(100,t));for(let i=1;i<stops.length;i++)if(x<=stops[i][0]){const a=stops[i-1],b=stops[i],u=(x-a[0])/(b[0]-a[0]);return `rgb(${a[1].map((v,j)=>Math.round(v+(b[1][j]-v)*u)).join(',')})`}return 'rgb(240,65,61)';
};
