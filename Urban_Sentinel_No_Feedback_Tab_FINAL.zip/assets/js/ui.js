export const esc=value=>String(value??'').replace(/[&<>"']/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
export const inr=n=>'₹'+Math.round(Number(n)||0).toLocaleString('en-IN');
export const dateLabel=s=>{try{return new Date(s).toLocaleString('en-IN')}catch{return String(s)}};
