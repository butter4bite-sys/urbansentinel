import {localities} from './localities.js';
import {options} from './recommendations.js';
const suitable=['heat-audit','thermal-curtain','solar-film','bldc-fan','inverter-ac','roof-paint','thermal-insulation','entrance-shade'];
// Neutral indicative procurement scenario. No synthetic heat/priority score is used.
export function cityPortfolio({budget=500000,strategy='fair',priority='balanced',selectedIds=[]}={}){
 const ids=new Set(selectedIds.map(Number));const areas=(ids.size?localities.filter(a=>ids.has(a.id)):[]);
 const filter={balanced:suitable,roof:['heat-audit','roof-paint','thermal-insulation'],shade:['thermal-curtain','solar-film','entrance-shade'],fan:['heat-audit','bldc-fan']};
 const pool=options.filter(o=>(filter[priority]||suitable).includes(o.id)).sort((a,b)=>a.priority-b.priority||a.cost-b.cost);
 const plan=[],perArea=new Map(),used=new Set();let remaining=budget;
 for(let iteration=0;iteration<70;iteration++){
  const ordered=strategy==='fair'?[...areas].sort((a,b)=>(perArea.get(a.id)||0)-(perArea.get(b.id)||0)):areas;
  let added=false;
  for(const area of ordered){
   const count=perArea.get(area.id)||0;if(count>=(strategy==='fair'?4:9))continue;
   const item=pool.find(o=>o.cost<=remaining&&!used.has(`${area.id}:${o.id}`));if(!item)continue;
   used.add(`${area.id}:${item.id}`);perArea.set(area.id,count+1);remaining-=item.cost;
   plan.push({...item,locality:area.name,areaId:area.id,allocation:'Indicative; verify site needs'});added=true;
   if(strategy==='impact'&&count<3)break;
  }
  if(!added)break;
 }
 return {plan,spent:budget-remaining,remaining,covered:new Set(plan.map(x=>x.areaId)).size,benefit:0};
}
