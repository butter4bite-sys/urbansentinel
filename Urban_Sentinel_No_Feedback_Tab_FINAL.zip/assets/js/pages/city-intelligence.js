import {loadWeather} from '../weather-fallback.js';
/** Urban Sentinel City Intelligence — actual model data; no sample numbers. */
import {directoryPromise,populateStates,populateCities,resolveCity,cityCount} from '../usx-directory.js';
import {aqiCategory} from '../aqi-service.js';
const $=id=>document.getElementById(id);
const cache=new Map(),TTL=10*60*1000;
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const finite=v=>typeof v==='number'&&Number.isFinite(v);
const fmt=(v,d=1)=>finite(v)?v.toFixed(d):'—';
const measure=(v,unit,d=1)=>finite(v)?`${fmt(v,d)}${unit}`:'—';
const modelLocal=ts=>ts?String(ts).replace('T',' ').replace(/Z$/,' UTC')+(String(ts).endsWith('Z')?'':' IST'):'Unavailable';
async function request(u){const controller=new AbortController(),id=setTimeout(()=>controller.abort(),15500);try{const r=await fetch(u,{signal:controller.signal});if(!r.ok)throw Error(`HTTP ${r.status}`);const d=await r.json();if(d?.error)throw Error(d.reason||'Provider error');return d;}finally{clearTimeout(id)}}
function dailyAQI(times,values){const m=new Map();for(let i=0;i<(times||[]).length;i++){const date=times[i]?.slice(0,10),value=values?.[i];if(!date||!finite(value))continue;const row=m.get(date)||{sum:0,n:0};row.sum+=value;row.n++;m.set(date,row);}return [...m].slice(-8,-1).map(([date,row])=>({date,value:row.sum/row.n}));}
async function load(state,name,force=false){const key=state+'|'+name,now=Date.now(),cached=cache.get(key);if(!force&&cached&&now-cached.at<TTL)return cached.value;
 const p=await resolveCity(state,name);
 const aq=new URL('https://air-quality-api.open-meteo.com/v1/air-quality');
 aq.searchParams.set('latitude',p.lat);aq.searchParams.set('longitude',p.lon);
 aq.searchParams.set('timezone','Asia/Kolkata');
 aq.searchParams.set('current','us_aqi,pm2_5,pm10,nitrogen_dioxide,ozone');
 aq.searchParams.set('hourly','us_aqi');aq.searchParams.set('past_days','8');aq.searchParams.set('forecast_days','1');
 const [weather,air]=await Promise.allSettled([loadWeather(p,{history:true,force}),request(aq)]);
 if(weather.status==='rejected'&&air.status==='rejected')throw Error(`Weather: ${weather.reason?.message||'unavailable'} · Air quality: ${air.reason?.message||'unavailable'}`);
 const wx=weather.status==='fulfilled'?weather.value:null, a=air.status==='fulfilled'?air.value:{};
 const result={state,name,point:p,w:wx?.current||{},a:a.current||{},
   wxTime:wx?.time||null,aqTime:a.current?.time||null,
   wxSource:wx?.source||null,wxStale:wx?.stale||false,wxForecast:wx?.forecast||false,
   wxPrecipitationPeriod:wx?.precipitationPeriod||null,
   wxError:weather.status==='rejected'?weather.reason.message:(wx?.providerError||null),
   aqError:air.status==='rejected'?air.reason.message:null,
   tempTrend:wx?.trend||[],aqTrend:dailyAQI(a.hourly?.time,a.hourly?.us_aqi)};
 cache.set(key,{at:now,value:result});return result;
}
function chart(id,a,b,what,unit,colorA,colorB){const root=$(id),arr=[...(a?.length?[{rows:a,color:colorA,name:'City A'}]:[]),...(b?.length?[{rows:b,color:colorB,name:'City B'}]:[])];if(!arr.length){root.innerHTML='<div class="ci-empty">No recent model history is available for these cities.</div>';return;}
 const dates=[...new Set(arr.flatMap(s=>s.rows.map(v=>v.date)))].sort().slice(-7),byDate=arr.map(s=>new Map(s.rows.map(v=>[v.date,v.value]))),vals=arr.flatMap(s=>s.rows.map(x=>x.value)).filter(finite);
 let lo=Math.floor((Math.min(...vals)-Math.max(2,(Math.max(...vals)-Math.min(...vals))*.13))/5)*5,hi=Math.ceil((Math.max(...vals)+Math.max(2,(Math.max(...vals)-Math.min(...vals))*.13))/5)*5;if(hi<=lo)hi=lo+5;
 const x=i=>42+i*530/Math.max(dates.length-1,1),y=v=>186-(v-lo)/(hi-lo)*143;
 const g=[0,.5,1].map(t=>{const yy=y(lo+(hi-lo)*t);return `<line x1="36" x2="592" y1="${yy}" y2="${yy}" stroke="currentColor" opacity=".15" stroke-dasharray="4 6"/><text x="31" y="${yy+4}" text-anchor="end" fill="currentColor" opacity=".75" font-size="11">${fmt(lo+(hi-lo)*t,0)}</text>`}).join('');
 let svg=`<svg viewBox="0 0 615 232" role="img" aria-label="${escape(what)} over the past seven days">${g}`;
 for(let j=0;j<arr.length;j++){const s=arr[j],values=byDate[j];let d='',on=false;dates.forEach((date,i)=>{const v=values.get(date);if(finite(v)){d+=(on?' L ':' M ')+x(i).toFixed(1)+' '+y(v).toFixed(1);on=true;}else on=false;});svg+=`<path d="${d}" fill="none" stroke="${s.color}" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>`;dates.forEach((date,i)=>{const v=values.get(date);if(finite(v))svg+=`<circle cx="${x(i)}" cy="${y(v)}" r="4" fill="${s.color}"><title>${escape(s.name)}: ${fmt(v)}${escape(unit)} on ${escape(date)}</title></circle>`;});}
 svg+=dates.map((date,i)=>`<text x="${x(i)}" y="218" text-anchor="middle" fill="currentColor" opacity=".76" font-size="11">${escape(date.slice(5))}</text>`).join('')+'</svg>';
 root.innerHTML=svg+`<div class="ci-chart-legend"><span><i style="background:${colorA}"></i> ${escape(document.getElementById('ciCity').value)}</span>${b?.length?`<span><i style="background:${colorB}"></i> ${escape(document.getElementById('ciCompare').value)}</span>`:''}</div>`;
}
function comparison(a,b,bname,bstate,compareError){const rows=[['Air temperature (2 m)','temperature_2m','°C','w',1],['Feels like','apparent_temperature','°C','w',1],['Relative humidity','relative_humidity_2m','%','w',0],['Wind speed','wind_speed_10m','km/h','w',1],['Precipitation','precipitation','mm','w',1],['US AQI','us_aqi','','a',0],['PM2.5','pm2_5',' µg/m³','a',1],['PM10','pm10',' µg/m³','a',1],['NO₂','nitrogen_dioxide',' µg/m³','a',1],['O₃','ozone',' µg/m³','a',1]];
 const cols=rows.map(([title,key,unit,group,d])=>{const av=a?.[group]?.[key],bv=b?.[group]?.[key],delta=finite(av)&&finite(bv)?av-bv:null;return `<tr><td>${title}</td><td>${measure(av,unit,d)}</td><td>${measure(bv,unit,d)}</td><td class="ci-difference">${finite(delta)?`${delta>0?'+':''}${fmt(delta,d)}${unit}`:'—'}</td></tr>`}).join('');
 $('ciComparison').innerHTML=`<table class="ci-compare-table"><thead><tr><th>Indicator</th><th><span class="ci-table-dot a"></span>${escape(a?.name||$('ciCity').value)}</th><th><span class="ci-table-dot b"></span>${escape(bname)}</th><th>A − B</th></tr></thead><tbody>${cols}</tbody></table><p class="ci-compare-footnote">${escape(a?.name||$('ciCity').value)} · ${escape(a?.state||$('ciState').value)} | ${escape(bname)} · ${escape(bstate)}. Differences are numerical, not health or safety rankings.${compareError?`<br><span class="ci-inline-error">Comparison city couldn't load: ${escape(compareError)}</span>`:''}</p>`;
}
function render(a,b,bState,bName,errorB){const w=a.w,q=a.a,category=aqiCategory(q.us_aqi);
 $('ciTemp').textContent=measure(w.temperature_2m,'°C');$('ciFeels').textContent=finite(w.apparent_temperature)?'Feels like '+measure(w.apparent_temperature,'°C'):'2 m air temperature · '+(a.wxSource||'weather model');$('ciAqi').textContent=finite(q.us_aqi)?Math.round(q.us_aqi):'—';$('ciAqiLabel').textContent=category.label;$('ciHumidity').textContent=measure(w.relative_humidity_2m,'%',0);$('ciWind').textContent=measure(w.wind_speed_10m,' km/h');$('ciRain').textContent=measure(w.precipitation,' mm');const rainNote=$('ciRainNote');if(rainNote)rainNote.textContent=a.wxSource==='MET Norway'?'Next 1h · forecast':'Current model value';
 $('ciRibbonA').textContent=`${a.name}, ${a.state}`;$('ciRibbonB').textContent=`${bName}, ${bState}`;$('ciCityHeadline').textContent=`${a.name} at a glance`;$('ciCitySubline').textContent=`Compare live modelled environmental conditions with ${bName}, ${bState}.`;
 const alerts=[];if(finite(w.apparent_temperature)){alerts.push(w.apparent_temperature>=40?['warn','High apparent temperature: reduce strenuous outdoor activity and take cooling breaks.']:w.apparent_temperature>=35?['warn','Elevated apparent temperature: seek shade, hydrate and take regular breaks.']:['good','No elevated heat threshold triggered by this modelled apparent temperature.']);}if(finite(q.us_aqi))alerts.push([q.us_aqi>100?'warn':'good',`US AQI ${Math.round(q.us_aqi)} · ${category.label}. ${category.advice}.`]);if(!alerts.length)alerts.push(['warn','Current model readings are unavailable; consult official local information.']);
 $('ciAlerts').innerHTML=alerts.map(([kind,msg])=>`<div class="ci-alert ${kind}">${escape(msg)}</div>`).join('');$('ciAdvice').textContent=finite(q.us_aqi)?category.advice:'For air quality, follow official monitoring and health advisories.';
 comparison(a,b,bName,bState,errorB);chart('ciTempChart',a.tempTrend,b?.tempTrend,'Temperature trend','°C','#ffba73','#8beaab');chart('ciAqiChart',a.aqTrend,b?.aqTrend,'US AQI trend','','#ffc265','#a7b6ff');
 $('ciPollutants').innerHTML=[['PM2.5',q.pm2_5],['PM10',q.pm10],['NO₂',q.nitrogen_dioxide],['O₃',q.ozone]].map(([name,val])=>`<div class="ci-pollutant"><small>${name}</small><b>${fmt(val)}</b><small>µg/m³ · modelled</small></div>`).join('');
 $('ciUpdated').textContent=`City A: ${a.wxSource||'Weather unavailable'} · ${modelLocal(a.wxTime)}${a.wxSource==='MET Norway'?' (forecast)':''}${a.wxStale?' (cached)':''} | City B: ${b?.wxSource||'Weather unavailable'} · ${modelLocal(b?.wxTime)}${b?.wxSource==='MET Norway'?' (forecast)':''}${b?.wxStale?' (cached)':''} | AQI: Open-Meteo CAMS model`; 
 $('ciStatus').textContent=[a.wxError&&`City A weather notice: ${a.wxError}`,a.aqError&&`City A air quality unavailable: ${a.aqError}`,errorB&&`City B unavailable: ${errorB}`,b?.wxError&&`City B weather notice: ${b.wxError}`,b?.aqError&&`City B air quality unavailable: ${b.aqError}`].filter(Boolean).join(' | ')||`Weather: ${a.wxSource||'unavailable'}${b?.wxSource&&b.wxSource!==a.wxSource?' / '+b.wxSource:''}. AQI: Open-Meteo CAMS model. Both cities loaded independently.`;
}
export async function init(){let directory;try{directory=await directoryPromise}catch(e){$('ciStatus').textContent='City directory unavailable: '+e.message;return;}
 const state=$('ciState'),city=$('ciCity'),bState=$('ciCompareState'),bCity=$('ciCompare');populateStates(state,directory,'Maharashtra');populateCities(city,directory,state.value,'Pune');populateStates(bState,directory,'Maharashtra');populateCities(bCity,directory,bState.value,'Mumbai');
 let serial=0;
 const updateB=()=>{populateCities(bCity,directory,bState.value,bCity.value||'Mumbai');if(state.value===bState.value&&city.value===bCity.value){const alt=(directory[bState.value]||[]).find(n=>n!==city.value);if(alt)bCity.value=alt;}};
 async function refresh(force=false){const token=++serial,mainState=state.value,mainCity=city.value,otherState=bState.value,otherCity=bCity.value;
 $('ciRibbonA').textContent=`${mainCity}, ${mainState}`;$('ciRibbonB').textContent=`${otherCity}, ${otherState}`;
 $('ciStatus').textContent=`Fetching model conditions for ${mainCity} and ${otherCity}…`;for(const id of ['ciTemp','ciAqi','ciHumidity','ciWind','ciRain'])$(id).textContent='…';$('ciComparison').innerHTML='<div class="ci-empty">Loading both city readings…</div>';
 const [p,q]=await Promise.allSettled([load(mainState,mainCity,force),load(otherState,otherCity,force)]);if(token!==serial)return;
 if(p.status==='rejected'){
  $('ciStatus').textContent=`Could not load ${mainCity}: ${p.reason.message}. ${q.status==='rejected'?`Comparison error: ${q.reason.message}`:''}`;
  for(const id of ['ciTemp','ciAqi','ciHumidity','ciWind','ciRain'])$(id).textContent='—';$('ciAqiLabel').textContent='Unavailable';$('ciFeels').textContent='Feels like —';$('ciAlerts').textContent='Weather unavailable. Try another city or refresh.';$('ciAdvice').textContent='';$('ciTempChart').textContent='Temperature history unavailable';$('ciAqiChart').textContent='AQI history unavailable';$('ciPollutants').textContent='Pollutant data unavailable';comparison(null,q.status==='fulfilled'?q.value:null,otherCity,otherState,q.status==='rejected'?q.reason.message:null);return;}
 render(p.value,q.status==='fulfilled'?q.value:null,otherState,otherCity,q.status==='rejected'?q.reason.message:null);
 }
 state.addEventListener('change',()=>{populateCities(city,directory,state.value);updateB();refresh();});
 city.addEventListener('change',()=>{updateB();refresh();});
 bState.addEventListener('change',()=>{populateCities(bCity,directory,bState.value,bState.value==='Maharashtra'?'Mumbai':null);updateB();refresh();});
 bCity.addEventListener('change',()=>refresh());$('ciRefresh').addEventListener('click',()=>refresh(true));
 const count=cityCount(directory);document.querySelector('.ci-hero-tags')?.insertAdjacentHTML('beforeend',`<span>${count.toLocaleString('en-IN')} listed Indian cities</span>`);
 refresh();
}
