import {cityPortfolio} from '../city-engine.js';
import {localities} from '../localities.js';
import {money,clamp,csvDownload} from '../utils.js';
import {esc} from '../ui.js';
export function init(){
 const $=id=>document.getElementById(id);let ids=[localities.find(a=>a.name==='Mundhwa')?.id??localities[0].id],last=[];
 $('targetArea').innerHTML=[...localities].sort((a,b)=>a.name.localeCompare(b.name)).map(a=>`<option value="${a.id}">${esc(a.name)}</option>`).join('');
 function render(){const budget=clamp(Number($('budgetNumber').value)||10000,10000,1500000);const r=cityPortfolio({budget,strategy:$('strategy').value,priority:$('priority').value,selectedIds:ids});last=r.plan;
  $('spent').textContent=money(r.spent);$('remaining').textContent=money(r.remaining);$('covered').textContent=r.covered;$('benefit').textContent=last.length;
  $('selectedAreas').innerHTML=ids.map(id=>`<span class="mini-badge">${esc(localities.find(a=>a.id===id)?.name||'Unknown')} <button type="button" data-remove="${id}" aria-label="Remove locality">×</button></span>`).join('')||'<span class="muted">Choose at least one area.</span>';
  $('selectedAreas').querySelectorAll('[data-remove]').forEach(b=>b.addEventListener('click',()=>{ids=ids.filter(i=>i!==Number(b.dataset.remove));render()}));
  $('cityPlanList').innerHTML=last.map(p=>`<article class="solution"><div class="tagline">${esc(p.locality)} · potential work</div><h3>${esc(p.name)}</h3><div class="price">${money(p.cost)}</div><p>${esc(p.why)}</p><p><b>Next steps:</b> ${esc(p.steps)}</p><small>Estimate only; obtain professional quotes.</small></article>`).join('')||'<p class="empty-state">Add a target area or increase the budget to see possible actions.</p>';
 }
 $('addArea').addEventListener('click',()=>{const id=Number($('targetArea').value);if(!ids.includes(id))ids.push(id);render()});$('clearAreas').addEventListener('click',()=>{ids=[];render()});
 $('budget').addEventListener('input',e=>{$('budgetNumber').value=e.target.value;render()});$('budgetNumber').addEventListener('input',e=>{$('budget').value=clamp(Number(e.target.value)||10000,10000,1500000);render()});
 $('strategy').addEventListener('change',render);$('priority').addEventListener('change',render);
 $('exportPlan').addEventListener('click',()=>csvDownload('Urban-Sentinel-city-estimates.csv',['Locality','Possible action','Estimated INR','Implementation guidance'],last.map(p=>[p.locality,p.name,p.cost,p.steps])));render();
}
