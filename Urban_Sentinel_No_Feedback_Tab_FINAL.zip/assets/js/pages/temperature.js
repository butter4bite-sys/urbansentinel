import {basemaps} from '../satellite-map.js';
import {statesPromise,locateCity,loadNeighbourhoods} from '../locations-india.js';
import {currentWeather} from '../weather-service.js';
import {esc} from '../ui.js';
import {cities as majorCities} from '../cities.js';

let mapLib;
// Classic map interface: the original compact circle markers with small,
// always-visible unboxed temperature text (no badge cards or tooltip rectangles).
function tempColor(value){return value>=38?'#b34539':value>=33?'#cb7139':value>=28?'#c2a44c':value>=23?'#338b80':'#3e83aa';}
function classicMarker(L,p,reading,kind='city'){
 const valid=Number.isFinite(reading?.temp);
 const value=valid?reading.temp.toFixed(1)+'°C':'—';
 const color=valid?tempColor(reading.temp):'#69818a';
 const marker=L.circleMarker([p.lat,p.lng],{radius:kind==='city'?8:5,color:'#f5fbf9',weight:2,fillColor:color,fillOpacity:.95});
 marker.bindTooltip(value,{permanent:true,direction:'top',offset:[0,-8],className:'classic-temperature-label',opacity:.97});
 return marker;
}
async function leaflet(){
 if(window.L)return window.L;
 if(mapLib)return mapLib;
 mapLib=new Promise((resolve,reject)=>{
  const c=document.createElement('link');c.rel='stylesheet';c.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';document.head.append(c);
  const s=document.createElement('script');s.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';s.onload=()=>resolve(window.L);s.onerror=()=>reject(Error('Map library unavailable'));document.head.append(s);
  setTimeout(()=>reject(Error('Map library timed out')),9000);
 });return mapLib;
}

// A state is loaded on demand. Never issue 580 simultaneous geocoding requests.
// City coordinates are verified with Open-Meteo geocoding; unverified cities show 'unavailable'.
export async function resolveStateCities(state,names,{concurrency=3,onProgress=()=>{}}={}){
 const results=new Array(names.length);let cursor=0,finished=0;
 async function worker(){
  while(cursor<names.length){
   const index=cursor++,name=names[index];
   try{results[index]={name,point:await locateCity(state,name)};}
   catch(error){results[index]={name,point:null,error:error.message};}
   onProgress(++finished,names.length);
  }
 }
 await Promise.all(Array.from({length:Math.min(concurrency,names.length)},worker));
 return results;
}

export async function init(){
 const $=id=>document.getElementById(id),banner=$('weatherMessage');
 let states,city=null,areas=[],values={},cityEntries=[],map=null,layer=null,serial=0,weatherAt=null,areaMessage='';
 const stateCache=new Map();
 const status=s=>{banner.textContent=s};
 const temp=p=>p&&Number.isFinite(values[p.id]?.temp)?values[p.id].temp.toFixed(1)+' °C':'—';
 const currentState=()=>$('stateSelect').value;
 function stateRows(){return cityEntries.filter(x=>x.name.toLowerCase().includes($('placeSearch').value.trim().toLowerCase()));}
 function list(){
  const q=$('placeSearch').value.trim().toLowerCase();
  const items=city?[city,...areas].filter(x=>x.name.toLowerCase().includes(q)):stateRows();
  $('tempRank').innerHTML=items.map(x=>{
   const label=city?temp(x):(x.point?temp(x.point):'Unavailable');
   return `<button type="button" class="place-row" data-place="${esc(city?x.id:x.name)}"><b>${esc(x.name)}</b><span class="temp-value">${label}</span></button>`;
  }).join('')||'<p class="muted">No matching places found.</p>';
  $('tempRank').querySelectorAll('[data-place]').forEach(b=>b.onclick=()=>city?focusArea(b.dataset.place===city.id?city:areas.find(x=>x.id===b.dataset.place)):chooseCity(b.dataset.place));
  $('mapHeading').textContent=city?`${city.name} · ${temp(city)}${city.name==='Pune'?' · city reading':' · neighbourhoods'}`:`${currentState()} · cities`;
  $('mapSub').textContent=city?(city.name==='Pune'?'Pune has one modelled outdoor air temperature marker.':'Temperature labels show modelled 2 m outdoor air.'):'Temperature labels show modelled 2 m outdoor air; select a city for details.';
  $('rankHeading').textContent=city?(city.name==='Pune'?'Pune temperature':'Localities'):'Cities in '+currentState();
  $('viewKpi').textContent=city?.name||currentState();
  $('countKpi').textContent=city?areas.length:items.length;
  $('countDetail').textContent=city?(city.name==='Pune'?'City-level reading':'Mapped neighbourhoods'):'Cities listed for this state';
  $('backToCities').hidden=!city;
  const available=(city?[city,...areas]:cityEntries.map(x=>x.point).filter(Boolean)).filter(p=>Number.isFinite(values[p.id]?.temp));
  const warmest=available.sort((a,b)=>values[b.id].temp-values[a.id].temp)[0];
  $('hotKpi').textContent=warmest?temp(warmest):'—';
  $('hotDetail').textContent=warmest?.name||'Awaiting model values';
  $('updatedKpi').textContent=weatherAt?new Date(weatherAt).toLocaleTimeString('en-IN'):'—';
 }
 function focusArea(area){if(area&&map)map.flyTo([area.lat,area.lng],13);}
 function showMap(){
  if(!map){$('mapStatus').textContent=city?(city.name==='Pune'?`Pune city temperature: ${temp(city)}. No locality markers.`:`${city.name} outdoor temperature: ${temp(city)}. ${areas.length} mapped localities. ${areaMessage}`):'City temperatures will appear below when available.';return;}
  layer.clearLayers();const L=window.L;
  if(city){
   map.setView([city.lat,city.lng],11);
   classicMarker(L,city,values[city.id]).addTo(layer).bindPopup(`<b>${esc(city.name)}</b><br>Modelled 2 m outdoor air: ${temp(city)}`);
   for(const p of areas)classicMarker(L,p,values[p.id],'locality').addTo(layer).bindPopup(`<b>${esc(p.name)}</b><br>Modelled 2 m outdoor air: ${temp(p)}<br><small>Not a street thermometer.</small>`);
   $('mapStatus').textContent=city.name==='Pune'?`Pune city: ${temp(city)} · city-level weather reading, no locality markers.`:`${city.name}: ${temp(city)} · ${areas.length} mapped neighbourhoods. ${areaMessage}`;
  }else{
   const pins=cityEntries.filter(x=>x.point).map(x=>x.point);
   for(const p of pins)classicMarker(L,p,values[p.id]).addTo(layer)
    .bindPopup(`<b>${esc(p.name)}</b><br>Modelled 2 m outdoor air: ${temp(p)}<br><small>Click to open neighbourhoods.</small>`)
    .on('click',()=>chooseCity(p.name));
   if(pins.length)map.fitBounds(L.latLngBounds(pins.map(p=>[p.lat,p.lng])),{padding:[70,80],maxZoom:9});
   else map.setView([22.9,79],5);
   const available=pins.filter(p=>Number.isFinite(values[p.id]?.temp)).length;
   $('mapStatus').textContent=`${available} of ${cityEntries.length} listed cities have modelled temperatures. Pune is one city marker; other cities may offer neighbourhood detail.`;
  }
 }
 async function loadState(force=false){
  const my=++serial,state=currentState();city=null;areas=[];areaMessage='';values={};cityEntries=(states[state]||[]).map(name=>({name,point:null}));weatherAt=null;
  $('placeSearch').value='';list();showMap();
  if(!force&&stateCache.has(state)&&Date.now()-stateCache.get(state).at<15*60*1000){
   const cached=stateCache.get(state);cityEntries=cached.entries;values={...cached.values};weatherAt=cached.at;
   list();showMap();status(`Showing ${Object.keys(values).length} modelled city temperatures for ${state} (cached this session).`);return;
  }
  status(`Loading modelled temperatures for ${state}…`);
  // Show known major city readings first instead of waiting for every city geocoding call.
  const knownState={Pune:'Maharashtra',Mumbai:'Maharashtra',Nagpur:'Maharashtra',Delhi:'Delhi',Bengaluru:'Karnataka',Hyderabad:'Telangana',Chennai:'Tamil Nadu',Kolkata:'West Bengal',Ahmedabad:'Gujarat',Jaipur:'Rajasthan',Surat:'Gujarat',Lucknow:'Uttar Pradesh'};
  const instant=majorCities.filter(c=>knownState[c.name]===state&&states[state].includes(c.name));
  if(instant.length){
   const known=await Promise.all(instant.map(c=>locateCity(state,c.name)));
   if(my!==serial)return;
   for(const point of known){const row=cityEntries.find(x=>x.name===point.name);if(row)row.point=point;}
   list();showMap();
   try{const quick=await currentWeather(known,{force});if(my!==serial)return;
    Object.assign(values,quick.values);weatherAt=quick.at;list();showMap();
    status(`${Object.keys(quick.values).length} major city temperatures visible. Loading remaining ${state} cities…`);
   }catch(error){if(my!==serial)return;status(`Major city weather temporarily unavailable (${error.message}). Checking remaining cities…`);}
  }
  if(my!==serial)return;
  status(`Locating remaining listed cities in ${state}…`);
  const entries=await resolveStateCities(state,states[state],{
   onProgress:(finished,total)=>{if(my===serial&&finished%3===0)status(`Verifying city locations: ${finished}/${total} in ${state}…`);}
  });
  if(my!==serial)return;
  cityEntries=entries;list();showMap();
  const points=entries.map(x=>x.point).filter(Boolean);
  if(!points.length){status(`No city coordinates could be verified for ${state}. Try Refresh weather later.`);return;}
  status(`Fetching current modelled temperatures for ${points.length} verified cities in ${state}…`);
  try{
   // Open-Meteo accepts multiple coordinate pairs in one request; weather-service batches at 15.
   const result=await currentWeather(points,{force});if(my!==serial)return;
   values={...values,...result.values};weatherAt=result.at;stateCache.set(state,{entries,values:{...values},at:weatherAt});
   const missing=entries.length-points.length;
   status(`${Object.keys(result.values).length} of ${cityEntries.length} city temperatures loaded for ${state}. ${missing?missing+' city coordinates unavailable. ':''}${result.source} modelled 2 m outdoor air · ${result.modelTime||'model time unavailable'} (IST). ${result.note||''}`);
  }catch(err){if(my!==serial)return;status(`Weather unavailable for ${state}: ${err.message}. No temperature values have been invented.`);}
  list();showMap();
 }
 async function chooseCity(name){
  const my=++serial,state=currentState(),entry=cityEntries.find(x=>x.name===name);
  city=null;areas=[];areaMessage='';$('placeSearch').value='';
  if(!entry?.point){status(`The coordinates of ${name}, ${state} could not be verified. Try refreshing or another city.`);return;}
  city=entry.point;list();showMap();
  // City weather must not depend on neighbourhood availability or a previous state request.
  if(!Number.isFinite(values[city.id]?.temp)){
   status(`Fetching ${name} temperature…`);
   try{const weather=await currentWeather([city]);if(my!==serial)return;Object.assign(values,weather.values);weatherAt=weather.at;}
   catch(error){if(my!==serial)return;areaMessage=`City weather unavailable: ${error.message}.`;}
   list();showMap();
  }
  if(state==='Maharashtra' && name==='Pune'){
   areas=[];areaMessage='Pune is displayed as a single city reading (no locality drilldown).';
   list();showMap();status(`${name}: ${temp(city)}. Single city-level modelled outdoor air temperature; no Pune localities.`);return;
  }
  status(`${name}: ${temp(city)}. Loading neighbourhoods…`);
  try{areas=await loadNeighbourhoods(city)}catch(error){if(my!==serial)return;areaMessage=`Neighbourhood lookup unavailable (${error.message}). City temperature remains visible.`;}
  if(my!==serial)return;list();showMap();
  if(!areas.length){status(`${name}: ${temp(city)}. No mapped neighbourhoods available right now; city temperature remains on the map.`);return;}
  status(`${name}: ${temp(city)}. Loading ${areas.length} locality temperatures…`);
  try{
   const result=await currentWeather(areas);if(my!==serial)return;
   values={...values,...result.values};weatherAt=result.at;
   status(`${name}: ${temp(city)}. ${Object.keys(result.values).length} of ${areas.length} localities have modelled temperatures · ${result.source} · ${result.modelTime||'time unavailable'} (IST). ${result.note||''}`);
  }catch(error){if(my!==serial)return;areaMessage=`Locality weather unavailable: ${error.message}. City temperature remains visible.`;status(`${name}: ${temp(city)}. ${areaMessage}`);}
  list();showMap();
 }
 states=await statesPromise;
 $('stateSelect').innerHTML=Object.keys(states).sort().map(s=>`<option value="${esc(s)}">${esc(s)} (${states[s].length})</option>`).join('');
 $('stateSelect').value='Maharashtra';
 $('stateSelect').onchange=()=>loadState();
 $('backToCities').onclick=()=>{serial++;city=null;areas=[];areaMessage='';$('placeSearch').value='';list();showMap();status(`Showing modelled temperatures for cities in ${currentState()}.`)};
 $('placeSearch').oninput=list;
 $('weatherRetry').onclick=()=>loadState(true);
 loadState();
 leaflet().then(L=>{
  const holder=$('tempMap');holder.innerHTML='';map=L.map(holder,{minZoom:4,maxZoom:18}).setView([22.9,79],5);
  basemaps(L,map,{defaultView:'satellite'});
  layer=L.layerGroup().addTo(map);showMap();setTimeout(()=>map.invalidateSize(),100);
 }).catch(()=>{$('tempMap').innerHTML='<div class="city-fallback"><p>Map tiles unavailable. State, city and locality temperatures remain available in the list.</p></div>';});
}
