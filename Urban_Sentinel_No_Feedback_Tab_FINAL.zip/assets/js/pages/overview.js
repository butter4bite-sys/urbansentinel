import {currentWeather} from '../weather-service.js';
export function init(){
 const el=document.getElementById('puneWeather');
 if(el)currentWeather([{id:'pune',lat:18.5204,lng:73.8567,name:'Pune'}]).then(r=>{el.textContent=(r.values.pune?.temp?.toFixed(1)??'—')+'°C';document.getElementById('puneWeatherSource').textContent=(r.values.pune?.source||r.source||'Weather model')+' · 2 m air temperature · '+new Date(r.at).toLocaleTimeString('en-IN')}).catch(()=>{document.getElementById('puneWeatherSource').textContent='Weather unavailable from both providers; no readings invented.'});
}
