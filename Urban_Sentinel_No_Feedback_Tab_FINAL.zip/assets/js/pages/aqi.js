import {basemaps} from '../satellite-map.js';
import {statesPromise,locateCity} from '../locations-india.js';
import {currentAQI,aqiCategory} from '../aqi-service.js';
import {esc} from '../ui.js';
import {resolveStateCities} from './temperature.js';
let mapLoader;
function leaflet(){if(window.L)return Promise.resolve(window.L);if(mapLoader)return mapLoader;mapLoader=new Promise((resolve,reject)=>{
 const c=document.createElement('link');c.rel='stylesheet';c.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';document.head.append(c);
 const s=document.createElement('script');s.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';s.onload=()=>resolve(window.L);s.onerror=()=>reject(Error('Map library unavailable'));document.head.append(s);
 setTimeout(()=>reject(Error('Map library timed out')),10000);
});return mapLoader;}
export async function init(){
 const $=id=>document.getElementById(id),status=t=>$('aqiMessage').textContent=t;
 const states=await statesPromise;let rows=[],values={},selected=null,map=null,layer=null,seq=0,modelTime=null;
 const state=()=> $('aqiState').value;
 const reading=p=>p&&Number.isFinite(values[p.id]?.aqi)?values[p.id].aqi:null;
 function updateAdvice(){
  const value=reading(selected),cat=aqiCategory(value);
  $('aqiAdviceTitle').textContent=selected?`${selected.name} · ${value===null?'AQI unavailable':`US AQI ${value} · ${cat.label}`}`:'Select a city to check outdoor conditions';
  $('aqiAdviceText').textContent=selected?cat.advice:'Choose a city from the list or map. Guidance will appear here when its modelled AQI is available.';
  $('aqiAdvice').style.borderLeft=`4px solid ${cat.color}`;
  $('aqiAdviceSource').textContent=selected?'Guidance uses the US AQI scale. Modelled values may differ from local pollution sensors. Check official advisories before outdoor activity.':'Air quality varies throughout the day and between neighbourhoods.';
 }
 function selectCity(p){if(!p)return;selected=p;render();if(map)map.flyTo([p.lat,p.lng],11,{duration:.65});}
 function render(){
  const query=$('aqiSearch').value.trim().toLowerCase(),items=rows.filter(x=>x.name.toLowerCase().includes(query));
  $('aqiList').innerHTML=items.map(x=>{const n=reading(x.point),cat=aqiCategory(n);return `<button type="button" class="place-row ${selected?.id===x.point?.id?'aqi-selected':''}" data-city="${esc(x.name)}"><b>${esc(x.name)}</b><span class="aqi-city-reading" style="color:${cat.color}">${n===null?'—':n} <small>${cat.label}</small></span></button>`;}).join('')||'<p class="muted">No matching cities.</p>';
  $('aqiList').querySelectorAll('[data-city]').forEach(el=>el.onclick=()=>{const row=rows.find(r=>r.name===el.dataset.city);if(row?.point)selectCity(row.point);else status(`${row?.name||'City'} coordinates are unavailable; try refreshing.`)});
  $('aqiStateKpi').textContent=state();$('aqiCount').textContent=rows.length;
  const available=rows.filter(r=>reading(r.point)!==null).sort((a,b)=>reading(b.point)-reading(a.point));
  $('aqiHigh').textContent=available.length?reading(available[0].point):'—';$('aqiHighCity').textContent=available[0]?.name||'Awaiting model data';
  $('aqiUpdated').textContent=modelTime?modelTime.replace('T',' ').slice(5):'—';
  $('aqiMapTitle').textContent=selected?`${selected.name} · US AQI ${reading(selected)??'—'}`:`${state()} · AQI by city`;
  $('aqiBack').hidden=!selected;
  updateAdvice();renderMap();
 }
 function renderMap(){
  if(!map){$('aqiMapStatus').textContent=selected?`${selected.name}: US AQI ${reading(selected)??'unavailable'}. See outdoor guidance below.`:'City AQI values appear in the list even when the map is unavailable.';return;}
  const L=window.L;layer.clearLayers();const points=rows.map(r=>r.point).filter(Boolean);
  for(const p of points){const n=reading(p),cat=aqiCategory(n);
   const marker=L.circleMarker([p.lat,p.lng],{radius:8,weight:2,color:'#fff',fillColor:cat.color,fillOpacity:.96});
   marker.bindTooltip(n===null?'—':String(n),{permanent:true,direction:'top',offset:[0,-9],className:'classic-temperature-label',opacity:.98});
   marker.bindPopup(`<b>${esc(p.name)}</b><br>Modelled US AQI: ${n??'Unavailable'}<br>${esc(cat.label)}<br><small>Click marker to view outdoor guidance.</small>`);
   marker.on('click',()=>selectCity(p)).addTo(layer);
  }
  if(selected)map.setView([selected.lat,selected.lng],11);
  else if(points.length)map.fitBounds(L.latLngBounds(points.map(p=>[p.lat,p.lng])),{padding:[65,70],maxZoom:9});
  else map.setView([22.9,79],5);
  $('aqiMapStatus').textContent=`${points.filter(p=>reading(p)!==null).length} of ${rows.length} listed cities have modelled US AQI values. Click a city marker or zoom in for outdoor guidance.`;
 }
 async function load(force=false){const my=++seq;selected=null;values={};modelTime=null;$('aqiSearch').value='';rows=(states[state()]||[]).map(name=>({name,point:null}));render();status(`Locating cities in ${state()}…`);
  // Verify coordinates using the same directory/geocoding path as the temperature page.
  rows=await resolveStateCities(state(),states[state()]||[],{onProgress:(done,total)=>{if(my===seq&&done%4===0)status(`Locating ${state()} cities: ${done}/${total}…`);}});
  if(my!==seq)return;render();const points=rows.map(r=>r.point).filter(Boolean);
  if(!points.length){status(`City locations unavailable for ${state()}. Try Refresh AQI.`);return;}
  status(`Loading US AQI for ${points.length} verified cities in ${state()}…`);
  try{const data=await currentAQI(points,{force});if(my!==seq)return;values=data.values;modelTime=data.modelTime;
   status(`${Object.keys(values).length} of ${rows.length} cities have modelled US AQI readings · ${data.modelTime||'model time unavailable'} (IST). ${data.failed?'Some readings are unavailable.':''}`);
  }catch(error){if(my!==seq)return;status(`AQI unavailable: ${error.message}. No values have been invented.`);}render();
 }
 $('aqiState').innerHTML=Object.keys(states).sort().map(s=>`<option value="${esc(s)}">${esc(s)} (${states[s].length})</option>`).join('');$('aqiState').value='Maharashtra';
 $('aqiState').onchange=()=>load();$('aqiRetry').onclick=()=>load(true);$('aqiSearch').oninput=render;
 $('aqiBack').onclick=()=>{selected=null;render()};
 leaflet().then(L=>{const holder=$('aqiMap');holder.innerHTML='';map=L.map(holder,{minZoom:4,maxZoom:18}).setView([22.9,79],5);
  basemaps(L,map,{defaultView:'satellite'});
  layer=L.layerGroup().addTo(map);render();setTimeout(()=>map.invalidateSize(),100);
  // Zooming close to a city automatically selects its nearest marker and reveals advice below.
  map.on('zoomend',()=>{if(map.getZoom()<10||selected)return;const center=map.getCenter(),near=rows.map(r=>r.point).filter(Boolean).map(p=>({p,d:Math.hypot((p.lat-center.lat)*111,(p.lng-center.lng)*105)})).sort((a,b)=>a.d-b.d)[0];if(near&&near.d<24)selectCity(near.p);});
 }).catch(()=>{$('aqiMap').innerHTML='<div class="city-fallback"><p>Map tiles unavailable. The city AQI list and outdoor advice remain usable.</p></div>';});
 load();
}
