import {listProjects} from '../projects.js';
import {csvDownload} from '../utils.js';
import {esc,inr} from '../ui.js';
const show=(k,v,s)=>`<div class="kpi"><span class="kpi-label">${k}</span><strong class="kpi-value">${v}</strong><small>${s}</small></div>`;
function chart(items,total){return items.map(([label,value])=>`<div class="chartrow"><span>${esc(label)}</span><strong>${value}</strong><div class="bar"><span style="width:${total?100*value/total:0}%"></span></div></div>`).join('')||'<p class="muted">Save a cooling plan to populate this report.</p>'}
export async function init(){let items=listProjects();const total=items.length,done=items.reduce((s,p)=>s+(p.completed||[]).length,0),actions=items.reduce((s,p)=>s+p.assessment.steps.length,0),plan=items.reduce((s,p)=>s+p.assessment.spent,0),actual=items.reduce((s,p)=>s+(p.actualSpend||0),0);
 document.getElementById('insightKpis').innerHTML=show('Saved plans',total,'Saved on this browser')+show('Estimated total',inr(plan),'Not supplier prices')+show('Self-reported spend',inr(actual),'Entered by users')+show('Actions completed',`${done}/${actions}`,'Self-reported work');
 const counts=new Map();items.forEach(p=>counts.set(p.assessment.kind,(counts.get(p.assessment.kind)||0)+1));document.getElementById('typeChart').innerHTML=chart([...counts],total);
 document.getElementById('progressChart').innerHTML=chart([['Completed actions',done],['Not yet marked complete',Math.max(0,actions-done)]],actions);
 document.getElementById('insightRows').innerHTML=items.map(p=>`<tr><td><a href="projects.html?id=${encodeURIComponent(p.id)}">${esc(p.assessment.name)}</a></td><td>${esc(p.assessment.locality)}</td><td>${(p.completed||[]).length}/${p.assessment.steps.length}</td><td>${inr(p.assessment.spent)}</td><td>${inr(p.actualSpend||0)}</td><td>${(p.measurements||[]).length}</td></tr>`).join('')||'<tr><td colspan="6">No reports yet. Start with a cooling assessment.</td></tr>';
 document.getElementById('exportData').addEventListener('click',()=>csvDownload('Urban-Sentinel-project-insights.csv',['Project','Locality','Space','Planned INR','Actual INR','Actions completed','Actions total','Readings'],items.map(p=>[p.assessment.name,p.assessment.locality,p.assessment.kind,p.assessment.spent,p.actualSpend||0,(p.completed||[]).length,p.assessment.steps.length,(p.measurements||[]).length])));
}
