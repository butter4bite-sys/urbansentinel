import {getProfile,saveProfile} from '../property-profile.js';
import {storeCoolingPlan} from '../cooling-bridge.js';
import {assess,kinds,roofLabels,sunLabels,ventilationLabels,reportLines} from '../assessment.js';
import {problems} from '../recommendations.js';
import {statesPromise} from '../locations-india.js';
import {saveProject,getProject} from '../projects.js';
import {downloadPdf} from '../pdf.js';
import {esc,inr} from '../ui.js';
const selectOpts=(data,selected)=>Object.entries(data).map(([k,v])=>`<option value="${esc(k)}" ${k===selected?'selected':''}>${esc(v)}</option>`).join('');
const defaults={home:{name:'My home cooling plan',area:850,people:4,budget:50000},school:{name:'My school cooling plan',area:1200,people:45,budget:150000},shop:{name:'My shop cooling plan',area:400,people:8,budget:50000},neighbourhood:{name:'Society cooling project',area:2500,people:80,budget:300000}};
export async function init(){
 const page=document.body.dataset.page||'assessment',fixed=page==='assessment'?null:page;
 const $=id=>document.getElementById(id),root=$('assessment-root');
 const projectId=new URLSearchParams(location.search).get('project');let stored=null;
 const presetLocality=new URLSearchParams(location.search).get('locality');
 const selectedKind=new URLSearchParams(location.search).get('type');const startKind=fixed||(['home','school','shop','neighbourhood'].includes(selectedKind)?selectedKind:'home');
 const shared=getProfile();const initial={kind:startKind,...defaults[startKind],...(!projectId?{name:shared.name,roof:shared.roof,budget:shared.budget,city:shared.city,windowSide:shared.windowSide||'mixed',ventilation:shared.ventilation||'average',sun:shared.sun||'medium',area:shared.areaSqFt||defaults[startKind].area}:{}),...(stored?.assessment||{}),...(!stored&&presetLocality?{locality:presetLocality}:{})};
 const stateData=await statesPromise; const preferred=initial.state||'Maharashtra';
 root.innerHTML=`<div class="card"><div class="cardhead"><div><h2>Tell us about the space</h2><p>These inputs drive your recommendations. You can save projects locally in this browser, or download a PDF. No account is needed.</p></div><span class="badge">Step 1 of 2</span></div>
 <form id="assessForm" class="form-grid">
 <div class="field"><label for="aName">Project name</label><input id="aName" required maxlength="100" value="${esc(initial.name)}"></div>
 <div class="field"><label for="aKind">Type of space</label><select id="aKind" ${fixed?'disabled':''}>${selectOpts(kinds,initial.kind)}</select></div>
 <div class="field"><label for="aState">State / Union Territory</label><select id="aState" required>${Object.keys(stateData).sort().map(n=>`<option value="${esc(n)}" ${n===preferred?'selected':''}>${esc(n)}</option>`).join('')}</select></div>
 <div class="field"><label for="aCity">City</label><select id="aCity" required></select><small>Only cities belonging to the selected state are shown.</small></div>
 <div class="field"><label for="aLocality">Locality / area (optional)</label><input id="aLocality" maxlength="100" placeholder="Your neighbourhood" value="${esc(initial.locality&&initial.locality!=='Pune'?initial.locality:'')}"></div>
 <div class="field"><label for="aProblem">Primary problem</label><select id="aProblem">${selectOpts(problems,initial.problem||'heat')}</select></div>
 <div class="field"><label for="aArea">Floor area (sq ft)</label><input id="aArea" type="number" required min="50" max="100000" value="${initial.area}"></div>
 <div class="field"><label for="aPeople">Regular occupants</label><input id="aPeople" type="number" required min="1" max="20000" value="${initial.people}"></div>
 <div class="field"><label for="aRoof">Roof type</label><select id="aRoof">${selectOpts(roofLabels,initial.roof||'concrete')}</select></div>
 <div class="field"><label for="aFloor">Space location</label><select id="aFloor"><option value="top" ${initial.floor==='top'?'selected':''}>Top floor / directly below roof</option><option value="middle" ${initial.floor!=='top'?'selected':''}>Lower / middle floor</option></select></div>
 <div class="field"><label for="aSun">Direct sunlight</label><select id="aSun">${selectOpts(sunLabels,initial.sun||'medium')}</select></div>
 <div class="field"><label for="aVent">Ventilation</label><select id="aVent">${selectOpts(ventilationLabels,initial.ventilation||'average')}</select></div>
 <div class="field"><label for="aWindows">Main window exposure</label><select id="aWindows"><option value="mixed">Several directions / not sure</option><option value="west">West (afternoon sun)</option><option value="east">East (morning sun)</option><option value="south">South</option><option value="north">North</option></select></div>
 <div class="field"><label for="aIndoor">Measured indoor temperature °C (optional)</label><input id="aIndoor" type="number" min="10" max="55" step="0.1" placeholder="Optional thermometer reading" value="${initial.indoorTemp??''}"></div>
 <div class="field wide"><label for="aBudget">Budget (₹10,000–₹15,00,000)</label><div class="range-field"><input type="range" min="10000" max="1500000" step="5000" value="${initial.budget}" id="aBudgetSlider" aria-label="Budget slider"><input type="number" id="aBudget" min="10000" max="1500000" required value="${initial.budget}"></div></div>
 <div class="field wide"><label for="aNotes">Anything else? (optional)</label><textarea id="aNotes" rows="3" maxlength="1000" placeholder="E.g. tin roof, no AC, children use this room">${esc(initial.userNotes||'')}</textarea></div>
 <div class="field wide"><button class="btn" type="submit">Generate my cooling plan →</button> <span class="hint">Estimates are guidance, not verified contractor quotes.</span></div>
 </form></div>
 <section id="assessmentResults" hidden aria-live="polite"></section>`;
 const form=$('assessForm'),result=$('assessmentResults');
 function updateCityList(wanted){const available=stateData[$('aState').value]||[];$('aCity').innerHTML=available.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');if(wanted&&available.includes(wanted))$('aCity').value=wanted;}
 updateCityList(initial.city||'Pune');$('aState').addEventListener('change',()=>{updateCityList();$('aLocality').value=''});
 $('aWindows').value=initial.windowSide||'mixed';
 $('aBudgetSlider').addEventListener('input',e=>{$('aBudget').value=e.target.value});$('aBudget').addEventListener('input',e=>{$('aBudgetSlider').value=Math.min(1500000,Math.max(10000,Number(e.target.value)||10000))});
 let current=null,savedId=null;
 const read=()=>({kind:fixed||$('aKind').value,name:$('aName').value,locality:$('aLocality').value.trim()||$('aCity').value,state:$('aState').value,city:$('aCity').value,problem:$('aProblem').value,area:$('aArea').value,people:$('aPeople').value,roof:$('aRoof').value,floor:$('aFloor').value,sun:$('aSun').value,ventilation:$('aVent').value,windowSide:$('aWindows').value,indoorTemp:$('aIndoor').value,budget:$('aBudget').value,notes:$('aNotes').value});
 function render(){
  const entered=read();
  // The Cooling Plan's floor area is a per-floor footprint. Keep the existing aspect ratio
  // and synchronize real metre dimensions with the 3D builder, not just the printed area.
  const existing=getProfile(),areaMeters=Math.max(9,Number(entered.area)||850)/10.7639;
  const aspect=Math.max(.15,Math.min(7,(Number(existing.length)||12)/(Number(existing.width)||9)));
  const proposedLength=Math.max(3,Math.min(80,Math.sqrt(areaMeters*aspect)));
  const proposedWidth=Math.max(3,Math.min(80,Math.sqrt(areaMeters/aspect)));
  saveProfile({name:entered.name,city:entered.city,roof:entered.roof,budget:Number(entered.budget),orientation:entered.windowSide!=='mixed'?entered.windowSide:existing.orientation,windowSide:entered.windowSide,ventilation:entered.ventilation,sun:entered.sun,floorLocation:entered.floor,areaSqFt:Number(entered.area),length:Math.round(proposedLength*100)/100,width:Math.round(proposedWidth*100)/100,indoorMeasured:entered.indoorTemp?Number(entered.indoorTemp):null});
  current=assess(entered);current.userNotes=$('aNotes').value.trim();storeCoolingPlan(current,entered);
  result.hidden=false;
  const flagged=current.flags.map(f=>`<div class="finding ${f.level}"><strong>${esc(f.title)}</strong><p>${esc(f.detail)}</p></div>`).join('');
  const rows=current.steps.map((s,i)=>`<article class="solution"><div class="tagline">${s.phase} · Priority ${i+1}</div><h3>${esc(s.title)}</h3><div class="price">${inr(s.cost)}</div><p class="hint">${s.quantity} package${s.quantity>1?'s':''}${s.coverage?` · nominal reach up to ${s.coverage.toLocaleString('en-IN')} sq ft`:''}</p><p><b>Why:</b> ${esc(s.why)}</p><p><b>Next action:</b> ${esc(s.how)}</p>${s.kind==='product'&&s.query?`<a class="link" rel="noopener noreferrer" target="_blank" href="https://www.amazon.in/s?k=${encodeURIComponent(s.query)}">Browse matching products ↗</a>`:'<span class="hint">Request a written professional quote</span>'}</article>`).join('');
  result.innerHTML=`<div class="section-title"><h2>Your preliminary cooling plan</h2><span class="badge">Step 2 of 2 · ${esc(kinds[current.kind])}</span></div>
  <div class="kpis"><div class="kpi"><span class="kpi-label">Your budget</span><strong class="kpi-value">${inr(current.budget)}</strong><small>Set by you</small></div><div class="kpi"><span class="kpi-label">Proposed spend</span><strong class="kpi-value">${inr(current.spent)}</strong><small>Estimated cost, not a quote</small></div><div class="kpi"><span class="kpi-label">Unallocated</span><strong class="kpi-value">${inr(current.remaining)}</strong><small>Allow for contingency</small></div><div class="kpi"><span class="kpi-label">Suggested actions</span><strong class="kpi-value">${current.steps.length}</strong><small>Phased recommendations</small></div></div>
  <section class="card"><h3>What needs attention</h3><div class="finding-grid">${flagged}</div></section>
  <section class="card"><div class="cardhead"><div><h3>Prioritized improvements</h3><p>Apply where appropriate after an on-site review. No predicted temperature reduction.</p></div></div><div class="plan-grid">${rows||'<p>No action fits the budget. Start with a site visit.</p>'}</div></section>
  <section class="card"><div class="cardhead"><div><h3>Save or share this plan</h3><p>Plans are saved only in this browser. Download a PDF or backup for safekeeping.</p></div></div><div class="btnrow"><button class="btn" id="aSave" type="button">Save project</button><button class="btn secondary" id="aPdf" type="button">Download PDF report</button><a class="btn secondary" href="projects.html">My projects ↗</a><a class="btn secondary" href="3d-simulation.html">Visualize this cooling plan in 3D ↗</a><a class="btn secondary" href="marketplace.html">Independent providers ↗</a></div><p id="saveMessage" class="muted" role="status"></p></section>
  <div class="callout"><b>Site-specific safety:</b> ${current.notes.slice(0,-4).map(esc).join(' ')}<br><br><b>Evidence & limits:</b> Recommendations depend on answers you provided, not an inspection. Costs and assumed coverage are indicative. Verify on site, obtain written quotes, and consult qualified technicians for electrical, structural, ventilation and fire-safety work. No indoor cooling result is guaranteed.</div>`;
  result.querySelector('#aSave').addEventListener('click',()=>{const message=result.querySelector('#saveMessage');try{const p=saveProject(current,{id:savedId||undefined,completed:stored?.completed||[],actualSpend:stored?.actualSpend||0,measurements:stored?.measurements||[]});savedId=p.id;message.textContent='Saved in this browser. Export a backup from My Projects to keep a copy.'}catch(e){message.textContent='Save failed: '+e.message}});
  result.querySelector('#aPdf').addEventListener('click',()=>downloadPdf('Urban-Sentinel-Cooling-Assessment.pdf',reportLines(current)));
 }
 form.addEventListener('submit',e=>{e.preventDefault();if(!form.reportValidity())return;render();result.scrollIntoView({behavior:'smooth',block:'start'})});
 if(projectId){stored=getProject(projectId);if(stored){savedId=stored.id;const a=stored.assessment;if(a.state&&stateData[a.state])$('aState').value=a.state;updateCityList(a.city);for(const [key,id] of Object.entries({name:'aName',kind:'aKind',locality:'aLocality',problem:'aProblem',area:'aArea',people:'aPeople',roof:'aRoof',floor:'aFloor',sun:'aSun',ventilation:'aVent',windowSide:'aWindows',indoorTemp:'aIndoor',budget:'aBudget',userNotes:'aNotes'})){if(a[key]!==undefined&&$(id))$(id).value=a[key]}$('aBudgetSlider').value=a.budget;render()}}
}
