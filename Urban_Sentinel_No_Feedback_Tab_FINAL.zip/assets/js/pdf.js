// Small dependency-free downloadable PDF report (built-in PDF structure, Helvetica, text-only).
// Use ASCII 'INR' in PDFs; this avoids embedded font/licensing dependencies.
const ascii=s=>String(s??'').normalize('NFKD').replace(/[^\x20-\x7e]/g,'?');
function wrap(line,max=100){const clean=ascii(line);if(clean.length<=max)return[clean];const words=clean.split(' '),out=[];let row='';for(const w of words){if(w.length>max){if(row){out.push(row);row=''}for(let i=0;i<w.length;i+=max)out.push(w.slice(i,i+max));continue}if((row+' '+w).trim().length>max){out.push(row);row=w}else row=(row+' '+w).trim()}if(row)out.push(row);return out}
const escape=s=>s.replaceAll('\\','\\\\').replaceAll('(','\\(').replaceAll(')','\\)');
export function buildPdfBytes(lines){
 const raw=lines.flatMap(line=>wrap(line,91));const maxPerPage=48,pages=[];for(let j=0;j<raw.length;j+=maxPerPage)pages.push(raw.slice(j,j+maxPerPage));if(!pages.length)pages.push(['Urban Sentinel']);
 const objects=[],add=s=>{objects.push(s);return objects.length};
 const catalog=add(''),pagesRoot=add('');const font=add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');const refs=[];
 for(let i=0;i<pages.length;i++){
  const pageLines=pages[i];const stream=['BT','/F1 10 Tf','13 TL','45 792 Td',...pageLines.flatMap((s,j)=>[...(j?['T*']:[]),`(${escape(s)}) Tj`]),'ET'].join('\n');
  const len=new TextEncoder().encode(stream).length;
  const content=add(`<< /Length ${len} >>\nstream\n${stream}\nendstream`);
  const page=add(`<< /Type /Page /Parent ${pagesRoot} 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${content} 0 R >>`);refs.push(page);
 }
 objects[catalog-1]=`<< /Type /Catalog /Pages ${pagesRoot} 0 R >>`;
 objects[pagesRoot-1]=`<< /Type /Pages /Kids [${refs.map(p=>`${p} 0 R`).join(' ')}] /Count ${refs.length} >>`;
 let out='%PDF-1.4\n',offsets=[0];const encoder=new TextEncoder();
 for(let i=0;i<objects.length;i++){offsets.push(encoder.encode(out).length);out+=`${i+1} 0 obj\n${objects[i]}\nendobj\n`}
 const start=encoder.encode(out).length;out+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;
 for(const offset of offsets.slice(1))out+=`${String(offset).padStart(10,'0')} 00000 n \n`;
 out+=`trailer\n<< /Size ${objects.length+1} /Root ${catalog} 0 R >>\nstartxref\n${start}\n%%EOF`;
 return encoder.encode(out);
}
export function downloadPdf(filename,lines){const blob=new Blob([buildPdfBytes(lines)],{type:'application/pdf'}),url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000)}
export function downloadFile(filename,body,mime='text/plain'){const url=URL.createObjectURL(new Blob([body],{type:mime}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000)}
