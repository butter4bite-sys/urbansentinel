/** House Climate Studio: mouse-orbit architectural 3D scene drawn with Canvas 2D.
 * Positions are 3D coordinates, not a photographic reconstruction. Heat overlays use
 * the disclosed screening index (NOT measured temperature or CFD). No CDN required.
 */
import {getEnergy,saveEnergy,energyBreakdown,getHome,saveHome,thermalEstimate,thermalColor} from './home-energy-model.js';
import {getProfile,saveProfile,saveScenario,safe} from './property-profile.js';
import {currentWeather} from './weather-service.js';
import {searchCity,shortwaveAt} from './satellite-map.js';
import {todayIndia} from './solar-science.js';
import {roomSize,walkBounds,walkStep,placementInFront,drawIndoor} from './indoor-walkthrough.js';
import {mountImmersiveRoom} from './immersive-room.js';
const host=document.getElementById('climateGame');
const isXray=document.body.dataset.page==='xray-house';
if(host){
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const fmt=(x,d=1)=>Number(x).toLocaleString('en-IN',{maximumFractionDigits:d});
let energy=getEnergy(),home=getHome(),profile=getProfile();
let beforeMode=false;
const fitDistance=()=>Math.max(18,Math.hypot(Number(profile.length)||12,Number(profile.width)||9)*1.68);
let yaw=.76,pitch=.57,dist=fitDistance(),drag=null,placeTool='',lastHit=null,frame=0,anim=0;
let indoor=false, indoorEntered=false, indoorPosition={x:0,y:0}, indoorHeading=0, indoorLook=0, indoorFov=1.23, walking=false, lastTick=0;
const activeKeys=new Set(),pointers=new Map(); let touchWalk='',pinchStart=null;
const placementKeys={ac:'acCount',fans:'fanCount',lights:'lightsCount',fridge:'fridgeCount'};
let dimensions={sx:1,sy:1};
let posData;try{posData=JSON.parse(localStorage.getItem('us4.climate.positions')||'{}')}catch{posData={}}
let positions=Object.fromEntries(Object.keys(placementKeys).map(k=>[k,Array.isArray(posData[k])?posData[k]:[]]));
const defaults={ac:[[1.2,2.4],[-3,-1.5],[3,-1.6],[-3,1.6]],fans:[[.8,1.6],[-1.3,1.2],[1.6,-.9],[-2.2,-.2],[2.2,1.5]],lights:[[0,0],[-2.8,-1.8],[2.8,-1.8],[-2.8,1.8],[2.8,1.8],[0,2.5]],fridge:[[-1.0,2.1],[2.9,-2.1],[-3.1,2.1],[2.9,2.1]]};
function syncPositions(){for(const [k,key] of Object.entries(placementKeys)){const cnt=Number(energy[key])||0;positions[k]=(positions[k]||[]).slice(0,cnt);while(positions[k].length<cnt){const i=positions[k].length;positions[k].push([...defaults[k][i%defaults[k].length]])}}try{localStorage.setItem('us4.climate.positions',JSON.stringify(positions))}catch{}}
const restoreId=new URLSearchParams(location.search).get('scenario');
if(restoreId){try{const item=JSON.parse(localStorage.getItem('us4.scenarios')||'[]').find(s=>String(s.id)===restoreId&&s.scenarioType==='house-climate');if(item){
  profile=saveProfile(item.property||{});energy=saveEnergy(item.appliances||{});home=saveHome(item.conditions||{});
  if(item.positions&&Array.isArray(item.positions.ac)&&Array.isArray(item.positions.fans))positions={...positions,...item.positions};
}}catch{}}
syncPositions();
host.innerHTML=`<section class="cg-wrap" aria-label="Interactive 3D house climate studio">
 <div class="cg-title"><div><span class="us4-eyebrow">LIVE PROPERTY CLIMATE STUDIO</span><h2>Design, enter and inspect your house</h2><p>Enter actual room dimensions, orbit the exterior, or press <strong>Indoor</strong> for an immersive 3D walkthrough. Place appliances inside and watch the energy/heat estimates respond.</p></div><a class="btn secondary cg-energy-link" href="energy-savings.html">View shared electricity data →</a></div>
 <div class="cg-layout"><aside class="cg-controls us4-card">
 <div class="cg-section-title"><span>01</span> Building conditions</div>
 <div class="cg-inputs"><label class="us4-field">House type<select id="cg-house-type"><option value="bungalow">Single-floor bungalow</option><option value="duplex">Duplex house</option><option value="apartment">Apartment building</option><option value="sloped">Sloped-roof house</option><option value="school">School building</option><option value="shop">Shop / commercial</option></select></label>
 <div class="cg-type-details"><label class="us4-field">Floors <input id="cg-floors" type="number" min="1" max="6" step="1"></label><label class="us4-field">Room length (m) <input id="cg-length" type="number" min="3" max="80" step="0.5"></label><label class="us4-field">Room width (m) <input id="cg-width" type="number" min="3" max="80" step="0.5"></label><label class="us4-field">Ceiling height (m) <input id="cg-ceiling" type="number" min="2.2" max="4.5" step="0.1"></label></div>
 <p class="cg-fine cg-scale-note"><strong>True metric scale: 1 model unit = 1 metre.</strong> Changing the length, width or ceiling height changes the actual simulated room bounds, not just the displayed numbers. Shared with X-Ray, Assessment and Energy.</p></div>
 <div class="cg-inputs"><label class="us4-field">Outdoor air temperature · assumed <span id="cg-ambient-label"></span><input id="cg-ambient" type="range" min="18" max="45" step="1"></label>
 <label class="us4-field">Solar intensity (W/m²) · assumed <span id="cg-solar-label"></span><input id="cg-solar" type="range" min="0" max="1100" step="25"></label>
 <label class="us4-field">Window / courtyard shading <span id="cg-shade-label"></span><input id="cg-shade" type="range" min="0" max="80" step="5"></label>
 <div class="cg-checks"><label><input type="checkbox" id="cg-coat"> Reflective roof</label><label><input type="checkbox" id="cg-insulate"> Roof insulation</label></div><button class="btn secondary cg-city-weather" id="cg-city-weather" type="button">Use local weather data</button><p class="cg-fine" id="cg-weather-source" aria-live="polite">Current inputs are manually assumed; no live measurement is inferred.</p></div>
 <div class="cg-section-title"><span>02</span> Appliances inside</div>
 <div class="cg-counts"><label class="cg-step"><span><strong>Air conditioners</strong><small id="cg-ac-sub"></small></span><span class="cg-spinner"><button data-inc="acCount" data-step="-1" aria-label="Remove air conditioner">−</button><output id="cg-ac-count"></output><button data-inc="acCount" data-step="1" aria-label="Add air conditioner">+</button></span></label>
 <label class="cg-step"><span><strong>Ceiling fans</strong><small id="cg-fan-sub"></small></span><span class="cg-spinner"><button data-inc="fanCount" data-step="-1" aria-label="Remove fan">−</button><output id="cg-fan-count"></output><button data-inc="fanCount" data-step="1" aria-label="Add fan">+</button></span></label>
 <label class="cg-step"><span><strong>LED lights</strong><small id="cg-light-sub"></small></span><span class="cg-spinner"><button data-inc="lightsCount" data-step="-1" aria-label="Remove light">−</button><output id="cg-light-count"></output><button data-inc="lightsCount" data-step="1" aria-label="Add light">+</button></span></label>
 <label class="cg-step"><span><strong>Refrigerators</strong><small id="cg-fridge-sub"></small></span><span class="cg-spinner"><button data-inc="fridgeCount" data-step="-1" aria-label="Remove refrigerator">−</button><output id="cg-fridge-count"></output><button data-inc="fridgeCount" data-step="1" aria-label="Add refrigerator">+</button></span></label></div>
 <div class="cg-placement"><button id="cg-place-ac" class="cg-tool" type="button" aria-pressed="false">Place AC</button><button id="cg-place-fan" class="cg-tool" type="button" aria-pressed="false">Place fan</button><button id="cg-place-lights" class="cg-tool" type="button" aria-pressed="false">Place LED</button><button id="cg-place-fridge" class="cg-tool" type="button" aria-pressed="false">Place refrigerator</button><p>Choose an appliance, then tap its destination in the open-roof view. In Indoor mode, walk to a position and tap <b>Place here</b> or tap the scene.</p></div>
 <div class="cg-section-title"><span>03</span> Compare &amp; actions</div><div class="cg-choices"><button id="cg-before" class="btn secondary" type="button">Show original house</button><button id="cg-after" class="btn secondary" type="button">Show improved house</button></div><p class="cg-fine" id="cg-compare-status">Both views use the same rotatable building and camera angle.</p><div class="cg-choices"><button id="cg-default" class="btn secondary" type="button">Reset view</button><button id="cg-reset" class="btn secondary" type="button">Reset changes</button><button id="cg-save" class="btn" type="button">Save scenario</button></div><p id="cg-saved" class="cg-fine" aria-live="polite"></p>
 </aside>
 <div class="cg-main"><section class="cg-stage-area">
 <div class="cg-toolbar" role="group" aria-label="House visualization mode"><button data-mode="realistic" aria-pressed="false">Architectural</button><button data-mode="thermal" aria-pressed="true">Thermal view</button><button data-mode="energy" aria-pressed="false">Energy flow</button><span class="cg-toolbar-gap"></span><div class="cg-zoom-control" aria-label="Zoom"><button id="cg-zoom-out" type="button" aria-label="Zoom out">−</button><span>Zoom</span><button id="cg-zoom-in" type="button" aria-label="Zoom in">+</button></div><button id="cg-indoor" class="cg-indoor-btn" type="button" aria-pressed="false" title="Enter first-person walk-through">Indoor</button><button id="cg-roof" aria-pressed="true" title="Show inside of house">Open roof</button></div>
 <div class="cg-stage" id="cg-stage"><canvas id="cg-canvas" tabindex="0" role="img" aria-label="Rotatable architectural 3D house with interactive heat and appliance layout. Drag to rotate; use plus and minus controls to change appliances."></canvas>
 <div class="cg-stage-top"><span id="cg-stage-mode">ILLUSTRATIVE THERMAL LAYER</span><span id="cg-stage-house"></span></div>
 <div class="cg-controls-hint" id="cg-hints"><span>↻ Drag to rotate</span><span>⊕ Pinch or + / − to zoom</span><span>↔ Tap to position equipment</span></div>
 <div class="cg-mobile-movement" id="cg-mobile-movement" hidden aria-label="Mobile walking controls"><button data-walk="turn-left" type="button" aria-label="Turn left">↶</button><button data-walk="forward" type="button" aria-label="Walk forward">↑</button><button data-walk="turn-right" type="button" aria-label="Turn right">↷</button><button data-walk="left" type="button" aria-label="Step left">←</button><button data-walk="backward" type="button" aria-label="Walk backward">↓</button><button data-walk="right" type="button" aria-label="Step right">→</button><button id="cg-drop-mobile" class="cg-mobile-add" type="button">+ Add</button></div>
 <div class="cg-avatar" id="cg-avatar" hidden aria-hidden="true"><svg viewBox="0 0 58 90" class="cg-walker-svg" xmlns="http://www.w3.org/2000/svg"><circle cx="29" cy="15" r="10" fill="#d3d9c8"/><rect x="20" y="27" width="18" height="28" rx="7" fill="#7be0bd"/><line class="cg-walker-arm left" x1="21" y1="33" x2="12" y2="59"/><line class="cg-walker-arm right" x1="37" y1="33" x2="46" y2="59"/><line class="cg-walker-leg left" x1="25" y1="52" x2="21" y2="81"/><line class="cg-walker-leg right" x1="33" y1="52" x2="38" y2="81"/></svg><span>Walking view</span></div>
 <div class="cg-compass" aria-hidden="true"><div>N</div><span>✦</span></div>
 </div>
 <div class="cg-indoor-pad" id="cg-indoor-pad" hidden><div class="cg-indoor-help"><strong>Indoor · 3D walkthrough</strong><span>W/A/S/D to move · drag to look · mobile arrows to walk · choose an appliance and tap to place</span><span id="cg-indoor-location" class="cg-indoor-location">Position 0.0 m × 0.0 m</span></div><div class="cg-walk-buttons"><button data-walk="turn-left" type="button" aria-label="Turn left">↶</button><button data-walk="forward" type="button" aria-label="Walk forward">↑</button><button data-walk="turn-right" type="button" aria-label="Turn right">↷</button><button data-walk="left" type="button" aria-label="Step left">←</button><button data-walk="backward" type="button" aria-label="Walk backward">↓</button><button data-walk="right" type="button" aria-label="Step right">→</button></div><button class="cg-placement-action" id="cg-drop" type="button">Place selected here</button><button class="cg-exit" id="cg-exit-indoor" type="button">Exit Indoor</button><div class="cg-placement-feedback" id="cg-placement-feedback" aria-live="polite"></div></div>
 <div class="cg-gradient"><span>Lower relative heat</span><div class="cg-gradient-bar"></div><span>Higher relative heat</span></div>
 <div class="cg-metrics" aria-live="polite"><div><small>Modeled indoor air estimate</small><strong id="cg-temp">—</strong><span>Illustrative sensitivity model</span></div><div><small>Relative heat exposure</small><strong id="cg-index">—</strong><span>Lower is better</span></div><div><small>Monthly appliance electricity</small><strong id="cg-kwh">—</strong><span>Same inputs as Bill Detective</span></div><div><small>Fan comfort effect</small><strong id="cg-relief">—</strong><span>Air temperature unchanged</span></div></div>
 <div class="cg-explain"><span class="cg-info-icon">i</span><div id="cg-explain-text"></div></div>
 </section>
 <div class="cg-bottom"><div class="cg-source-note">This is a <b>rotatable conceptual building model</b>, not a 3D scan or a measured thermal image. The thermal colors represent a relative modeled heat/comfort index. AC cooling is an illustrative assumption; actual room temperature requires on-site data. Fans improve perceived comfort, not air temperature.</div><a href="energy-savings.html" class="cg-energy-cta">Open energy consumption map &amp; bill analysis ↗</a></div>
 </div></div></section>`;
const canvas=host.querySelector('#cg-canvas'),ctx=canvas.getContext('2d',{alpha:false});
const immersive=mountImmersiveRoom(host.querySelector('#cg-stage'),{
  turn(dx,dy){indoorHeading+=dx*.0049;indoorLook=clamp(indoorLook+dy*.0018,-.23,.23);requestDraw()},
  zoom(dir){zoom(dir)},
  tap(e){if(placeTool)placeIndoor(0,1.6)},
  exit(){setIndoor(false)}
});
const button=(id)=>host.querySelector(id);
const viewMode=()=>home.thermal==='energy'?'energy':home.thermal===false?'realistic':'thermal';
function activeHome(){return beforeMode?{...home,roofCoating:false,roofInsulation:false,shade:15,trees:0}:home}
function getModel(){return thermalEstimate({energy,home:activeHome(),profile})}
const P=(x,y,z)=>[x,y,z];
const physical=p=>[p[0]*dimensions.sx,p[1]*dimensions.sy,p[2]];
const add=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]],sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],scale=(a,s)=>a.map(v=>v*s);
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const norm=a=>scale(a,1/(Math.hypot(...a)||1));
let camera;
function setCamera(w,h){const f=clamp(Number(profile.floors)||1,1,4),ceil=clamp(Number(profile.ceilingHeight)||2.8,2.2,4.5),target=P(0,0,1.25+Math.min(2,f-1)*ceil),eye=add(target,P(dist*Math.cos(pitch)*Math.sin(yaw),-dist*Math.cos(pitch)*Math.cos(yaw),dist*Math.sin(pitch)));const fw=norm(sub(target,eye));const right=norm(cross(fw,P(0,0,1))),up=norm(cross(right,fw));return{eye,target,fw,right,up,w,h,focal:Math.min(w*1.22,h*1.70)}}
function proj(pt){const v=sub(pt,camera.eye),z=dot(v,camera.fw);return [camera.w/2+dot(v,camera.right)*camera.focal/Math.max(.01,z),camera.h*.57-dot(v,camera.up)*camera.focal/Math.max(.01,z),z]}
let faces=[],stickers=[];
function face(pts,color,alpha=1,outline=null){const points=pts.map(physical);faces.push({pts:points,color,alpha,outline,depth:points.reduce((s,p)=>s+dot(sub(p,camera.eye),camera.fw),0)/points.length})}
function box(x1,y1,z1,x2,y2,z2,color,alpha=1){const a=P(x1,y1,z1),b=P(x2,y1,z1),c=P(x2,y2,z1),d=P(x1,y2,z1),e=P(x1,y1,z2),f=P(x2,y1,z2),g=P(x2,y2,z2),h=P(x1,y2,z2);face([a,d,c,b],color,alpha);face([e,f,g,h],color,alpha);face([a,b,f,e],color,alpha);face([b,c,g,f],color,alpha);face([c,d,h,g],color,alpha);face([d,a,e,h],color,alpha)}
function quad(a,b,c,d,color,alpha=1){face([a,b,c,d],color,alpha)}
function path(pts,color,width=1.2,dash=[]){const points=pts.map(physical);stickers.push({type:'path',pts:points,color,width,dash,depth:points.reduce((s,p)=>s+dot(sub(p,camera.eye),camera.fw),0)/points.length})}
function circle(x,y,z,r,color){const point=physical(P(x,y,z));stickers.push({type:'circle',pos:point,r,color,depth:dot(sub(point,camera.eye),camera.fw)})}
function label(x,y,z,title,subtitle,color='#b2ffe1'){const point=physical(P(x,y,z));stickers.push({type:'label',pos:point,title,subtitle,color,depth:dot(sub(point,camera.eye),camera.fw)})}
function material(s){return s}
function buildHouse(){faces=[];stickers=[];const model=getModel(),mode=viewMode(),heat=mode==='thermal',isFlow=mode==='energy',cut=home.cutaway;const floors=clamp(Math.round(profile.floors)||1,1,6),floorHeight=clamp(Number(profile.ceilingHeight)||2.8,2.2,4.5),wallTop=floors*floorHeight+.45;
 const B={x1:-4.5,x2:4.5,y1:-3.3,y2:3.3,z0:.28,h:wallTop};const roofColor=heat?thermalColor(clamp(38+model.roofAbsorbed/model.area*65,5,100)):activeHome().roofCoating?'#e7eee9':profile.roof==='tile'?'#bd7a4a':'#647c85';
 // Landscaped site, driveway, home foundation, ornamental border.
 box(-8,-7.2,-.38,8,7.8,-.10,'#194c41');box(-8,-7.2,-.15,8,7.8,-.08,'#2b6550');
 for(let i=0;i<13;i++){const x=-7.5+i*1.25;path([P(x,-7.2,-.09),P(x,7.8,-.09)],'#356f56',.4)}
 for(let j=0;j<11;j++){const y=-6.9+j*1.37;path([P(-8,y,-.085),P(8,y,-.085)],'#356d55',.4)}
 box(-1.9,-7.2,-.07,2.25,-3.6,.02,'#b9b6a3');for(let j=0;j<7;j++)path([P(-1.9,-7+j*.47,.04),P(2.25,-7+j*.47,.04)],'#9c9c8a',.6);
 box(-5.1,-3.9,.06,5.1,3.8,.29,'#75847c');box(-4.76,-3.55,.27,4.76,3.55,.42,'#bdb9a6');
 // Heat map tessellation is a modeled indoor comfort field (roof opened only).
 if(cut){const cells=15;for(let i=0;i<cells;i++)for(let j=0;j<11;j++){const x=-4.42+i*(8.84/cells),y=-3.18+j*(6.36/11),cx=x+8.84/cells/2,cy=y+6.36/11/2;let index=model.heatIndex;
   for(const [ax,ay] of positions.ac){const d=Math.hypot(cx-ax,cy-ay);index-=Math.exp(-d*d/5)*Math.min(30,35/(1+energy.acCount*.1))}
   for(const [fx,fy] of positions.fans){const d=Math.hypot(cx-fx,cy-fy);index-=Math.exp(-d*d/3)*3.2}
   index+=1.5*Math.sin(i*.61+j*.32);const c=heat?thermalColor(clamp(index,0,100)):'#6f817f';quad(P(x,y,.445),P(x+8.82/cells,y,.445),P(x+8.82/cells,y+6.33/11,.445),P(x,y+6.33/11,.445),c,heat?.90:.64)}}
 // Architectural shell. Transparent walls in open roof, keeping detail visible.
 const wallAlpha=cut?.19:1,wallColor=heat?'#d7a85d':'#e7e1d2';
 for(let fl=0;fl<floors;fl++){
  const z=.45+fl*floorHeight,h=z+floorHeight;
  box(-4.5,-3.33,z,4.5,3.33,h,wallColor,wallAlpha);
  box(-4.62,-3.44,z-.07,4.62,3.44,z+.05,'#e8e2d4',cut?.12:1);
  const winColor=mode==='thermal'?'#3aa8bc':'#245568';
  for(const x of [-2.65,2.2]){
    quad(P(x-.85,-3.367,z+.67),P(x+.85,-3.367,z+.67),P(x+.85,-3.367,z+2.12),P(x-.85,-3.367,z+2.12),'#dedbcd',cut?.32:1);
    quad(P(x-.72,-3.388,z+.77),P(x+.72,-3.388,z+.77),P(x+.72,-3.388,z+2.02),P(x-.72,-3.388,z+2.02),winColor,cut?.4:1);
    path([P(x,-3.395,z+.78),P(x,-3.395,z+2.04)],'#d7edf2',3);
    path([P(x-.73,-3.395,z+1.38),P(x+.72,-3.395,z+1.38)],'#d7edf2',2.8);
    path([P(x-.62,-3.40,z+1.96),P(x+.15,-3.40,z+1.57)],'#9cbbc8',1.1);
    box(x-.95,-3.61,z+.62,x+.95,-3.34,z+.72,'#b5b7aa',cut?.40:1);
  }
  // Side windows
  for(const y of [-1.5,1.4]){quad(P(4.536,y-.51,z+.8),P(4.536,y+.51,z+.8),P(4.536,y+.51,z+1.95),P(4.536,y-.51,z+1.95),winColor,cut?.4:1);
   path([P(4.55,y,z+.8),P(4.55,y,z+1.95)],'#d2ecf0',2)}
 }
 // Building-type specific architectural detailing (same renderer and saved property).
 if(profile.type==='apartment'||profile.type==='duplex'){
  for(let fl=1;fl<floors;fl++){const bz=.42+fl*floorHeight;
   box(-3.75,-4.17,bz-.12,3.75,-3.28,bz+.03,'#d6d9d1',cut?.18:1);
   for(let bx=-3.55;bx<=3.55;bx+=1.15){path([P(bx,-4.18,bz+.05),P(bx,-4.18,bz+.92)],'#b9d6da',1.4)}
   path([P(-3.7,-4.18,bz+.92),P(3.7,-4.18,bz+.92)],'#b9d6da',2);
  }
 }
 if(profile.type==='shop'){
  quad(P(-3.9,-3.6,.6),P(3.9,-3.6,.6),P(3.9,-3.6,2.6),P(-3.9,-3.6,2.6),'#2a6974',cut?.25:1);
  box(-4.35,-4.05,2.72,4.35,-3.42,3.1,'#177b74',cut?.3:1);
 }
 if(profile.type==='school'){
  box(-3.2,-4.3,.38,3.2,-3.35,.58,'#b5aa91');
  for(const x of [-3.1,3.0])box(x,-4.2,.58,x+.14,-4.06,3.2,'#e7e5d8',cut?.2:1);
 }
 // Entry, porch columns, facade trim and outdoor service unit.
 box(-1.05,-3.53,.42,.6,-3.43,2.65,'#825c41',cut?.38:1);path([P(-.38,-3.56,.54),P(-.38,-3.56,2.54)],'#c49a6a',2);
 circle(.35,-3.57,1.44,.05,'#e4c891');
 box(-1.68,-4.85,2.93,2.2,-3.15,3.19,'#a9ada6',cut?.23:1);
 for(const x of [-1.53,1.99])box(x,-4.7,.25,x+.11,-4.59,3.06,'#f0eadb',cut?.23:1);
 box(-5.1,.6,.2,-4.45,1.66,1.42,'#aab8bd');
 for(let a=0;a<4;a++)path([P(-5.13,.75+a*.18,.4),P(-5.13,1.44,.4+a*.16)],'#5d7278',1);
 // Detailed sloped roof. In cutaway, roof is a faint lifted outline so equipment remains visible.
 const z=wallTop+.12,ridge=z+1.40,eave=z+.02,roofAlpha=cut?.10:1;
 const r1=P(-5,-3.85,eave),r2=P(5,-3.85,eave),r3=P(5,0,ridge),r4=P(-5,0,ridge),r5=P(-5,3.85,eave),r6=P(5,3.85,eave);
 if(profile.roof==='concrete'){
  box(-5.0,-3.82,wallTop+.06,5,3.82,wallTop+.46,roofColor,roofAlpha);
  if(heat&&!cut){for(let i=0;i<14;i++)for(let j=0;j<11;j++){
    const x=-4.93+i*(9.86/14),y=-3.75+j*(7.5/11),index=clamp(32+model.roofAbsorbed/model.area*80+5*Math.sin(i*.52)+7*Math.cos(j*.33)-activeHome().trees*1.5,5,100);
    quad(P(x,y,wallTop+.469),P(x+9.86/14,y,wallTop+.469),P(x+9.86/14,y+7.5/11,wallTop+.469),P(x,y+7.5/11,wallTop+.469),thermalColor(index));
  }}
  for(const x of [-4.95,4.7])box(x,-3.77,wallTop+.46,x+.24,3.8,wallTop+.85,'#e7e9dc',roofAlpha);
  for(const y of [-3.78,3.53])box(-5,y,wallTop+.46,5,y+.22,wallTop+.85,'#e4e9df',roofAlpha);
 }else{
  quad(r1,r2,r3,r4,roofColor,roofAlpha);quad(r4,r3,r6,r5,roofColor,roofAlpha);
  face([r1,r4,r5],wallColor,roofAlpha);face([r2,r6,r3],wallColor,roofAlpha);
  for(let i=1;i<=7;i++){const t=i/8,z0=eave+(ridge-eave)*t;path([P(-4.98,-3.85+3.85*t,z0+.025),P(4.98,-3.85+3.85*t,z0+.025)],activeHome().roofCoating?'#c7d1cf':'#9b5044',cut?.5:1.1);
   path([P(-4.98,3.85-3.85*t,z0+.025),P(4.98,3.85-3.85*t,z0+.025)],activeHome().roofCoating?'#c7d1cf':'#9b5044',cut?.5:1.1)}
  path([r4,r3],'#d6d9c7',3);
 }
 // Solar device on roof only when solar scenario configured elsewhere (not fabricated generation).
 let solar={};try{solar=JSON.parse(localStorage.getItem('us4.calc.solar')||'{}')}catch{};
 if(!cut&&solar.capacity>0){for(let i=0;i<3;i++)for(let j=0;j<2;j++){
  const x=-3.6+i*2.2,y=.3+j*1.55,h=profile.roof==='concrete'?wallTop+.5:ridge-(ridge-eave)*(y/3.85)+.06;
  quad(P(x,y,h),P(x+1.94,y,h),P(x+1.94,y+1.35,h-(profile.roof==='concrete'?.12:.5)),P(x,y+1.35,h-(profile.roof==='concrete'?.12:.5)),'#193c5e',1);
  path([P(x+1,y,h+.015),P(x+1,y+1.3,h-.3)],'#7296b0',1)
 }}
 // Ground plants and trees. Detailed foliage built as staggered canopy clusters.
 const treePts=[[-6.5,-1.3],[-6.7,2.8],[6.45,3.0],[6.5,-.65]];
 for(let t=0;t<clamp(Math.round(home.trees),0,4);t++){const [x,y]=treePts[t];box(x-.15,y-.14,-.05,x+.15,y+.14,2.4,'#745a39');for(let k=0;k<9;k++){const a=k*2.3999;const rr=.7+(k%3)*.27;const cx=x+Math.sin(a)*rr,cy=y+Math.cos(a)*rr;circle(cx,cy,2.55+(k%4)*.24,.6,k%3===0?'#6b9e56':k%3===1?'#397958':'#4b975c')}}
 // Planter edge / landscaping geometry.
 for(const x of [-4,-2.7,3.2,4.05])for(const y of [-5.1,4.9]){box(x-.32,y-.28,-.04,x+.32,y+.28,.22,'#ad977e');circle(x,y,.41,.29,'#5c9560')}
 // Furnished interior visible only in open-roof view.
 if(cut){
  // Partitions and furniture use distinctive muted realistic colors.
  box(-.1,-2.9,.48,.02,2.8,1.7,'#b5b3a9',.38);
  box(-3.6,1.05,.46,-1.3,2.7,.82,'#d4c7aa');box(-3.8,.97,.47,-1.1,1.2,1.1,'#8d9b9b');box(-3.45,1.2,.84,-1.45,2.35,.91,'#e7e7de');
  box(1.05,-1.85,.47,3.1,-.55,.83,'#576e70');box(1.2,-2.05,.45,3.15,-1.74,1.14,'#819a95');
  box(1.16,-1.1,.49,3.23,-.91,.9,'#819a95');box(1.5,1.7,.47,3.2,2.37,1.13,'#b1a594');
  box(-1.7,-1.58,.49,-.55,-.35,.65,'#c3b5a0');box(-1.95,-1.72,.46,-.36,-.29,.52,'#e3d6c2');
  // Carpet and table.
  quad(P(.3,-.1,.47),P(3.6,-.1,.47),P(3.6,1.33,.47),P(.3,1.33,.47),'#7d9389',.55);box(1.24,.28,.49,2.49,.85,.9,'#aa8163');
  for(let i=0;i<energy.acCount;i++){
   const [x,y]=positions.ac[i];const ax=.46/dimensions.sx,ay=.23/dimensions.sy;box(x-ax,y-ay,1.83,x+ax,y+ay,2.18,'#eef2e9');path([P(x-ax*.8,y-ay*1.03,2.02),P(x+ax*.8,y-ay*1.03,2.02)],'#6b9fa4',2);
   if(mode!=='realistic'){circle(x,y,2.4,.11,mode==='energy'?'#8dcfff':'#2ae9ff');label(x,y,2.74,`AC ${i+1}`,'', '#75e6ff')}
  }
  for(let i=0;i<energy.fanCount;i++){
   const [x,y]=positions.fans[i];const z=Math.min(2.55,floorHeight-.27);box(x-.05/dimensions.sx,y-.05/dimensions.sy,z-.26,x+.05/dimensions.sx,y+.05/dimensions.sy,z,'#d4e1d5');circle(x,y,z-.30,.10,'#a4bfc1');for(let j=0;j<3;j++){const a=j*Math.PI*2/3+frame*.003;path([P(x,y,z-.30),P(x+Math.cos(a)*.70/dimensions.sx,y+Math.sin(a)*.70/dimensions.sy,z-.30)],'#c1d0d1',5)}
   if(mode!=='realistic')label(x,y,2.78,`FAN ${i+1}`,'','#d4ffe2');
  }
  for(let i=0;i<energy.fridgeCount;i++){const [x,y]=positions.fridge[i];const dx=.35/dimensions.sx,dy=.35/dimensions.sy;box(x-dx,y-dy,.48,x+dx,y+dy,2.22,'#e5f1ec');path([P(x+dx,y-dy,.9),P(x+dx,y-dy,1.31)],'#6b8987',2);path([P(x+dx,y-dy,1.52),P(x+dx,y-dy,1.9)],'#6b8987',2);path([P(x-dx,y-dy,1.38),P(x+dx,y-dy,1.38)],'#879d95',2);if(mode!=='realistic')label(x,y,2.43,`FRIDGE ${i+1}`,'','#ffe1a1')}
  for(let i=0;i<energy.lightsCount;i++){const [x,y]=positions.lights[i];const z=Math.min(floorHeight-.16,3.2);circle(x,y,z,.19,'#ffeb9a');circle(x,y,z-.055,.12,'#fff7bd');if(mode!=='realistic')label(x,y,z+.29,`LED ${i+1}`,'','#ffeda6')}

 }
 // Meter and energy wiring. Routes depict conceptual household distribution, not the exact wiring.
 if(isFlow){const meter=P(-4.83,-3.52,1.36);circle(...meter,.2,'#f8ed92');label(-5.4,-3.4,2.1,'GRID METER','assumed source','#fff1a0');
   for(const [x,y] of [...positions.ac,...positions.fans])path([meter,P(-4.3,-2.86,1.3),P(x,y,.9)],'#96f7e3',2,[8,6]);
   for(const [x,y] of positions.fridge)path([meter,P(x,y,1.5)],'#fce79b',3,[7,6]);for(const [x,y] of positions.lights)path([meter,P(x,y,2.3)],'#ffe59f',1.4,[3,4]);
 }
 // In thermal mode, add sensor-style legend anchors around house.
 if(heat){label(-4.45,3.6,wallTop+.72,'ROOF HEAT','solar absorption','#ffc789');label(3.4,2.4,.75,'INDOOR','modeled index','#87edff')}
 return model;
}
function render(){if(!canvas.isConnected)return;const rect=canvas.getBoundingClientRect(),w=Math.max(100,rect.width),h=Math.max(100,rect.height),pixelRatio=Math.min(2,window.devicePixelRatio||1);
 const rw=Math.round(w*pixelRatio),rh=Math.round(h*pixelRatio);if(canvas.width!==rw||canvas.height!==rh){canvas.width=rw;canvas.height=rh}ctx.setTransform(pixelRatio,0,0,pixelRatio,0,0);const size=roomSize(profile);dimensions={sx:size.length/9,sy:size.width/6.6};
 if(indoor){
  const indoorProps={profile,position:indoorPosition,heading:indoorHeading,look:indoorLook,fov:indoorFov,energy,positions,mode:viewMode(),home:activeHome(),heatIndex:getModel().heatIndex,walking,frame};
  if(immersive.available){immersive.refresh(indoorProps)}
  else drawIndoor(ctx,w,h,indoorProps);
  return;
 }
 camera=setCamera(w,h);
 const sky=ctx.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#112d3b');sky.addColorStop(.57,'#1c3d49');sky.addColorStop(1,'#0f2528');ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
 // Atmospheric radial glow and subtle horizon grid.
 const glow=ctx.createRadialGradient(w*.49,h*.28,10,w*.48,h*.48,w*.6);glow.addColorStop(0,'rgba(58,135,136,.23)');glow.addColorStop(1,'rgba(9,18,28,0)');ctx.fillStyle=glow;ctx.fillRect(0,0,w,h);
 buildHouse();faces.sort((a,b)=>b.depth-a.depth);
 for(const f of faces){const pts=f.pts.map(proj);if(pts.some(p=>p[2]<=.1))continue;ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.closePath();ctx.globalAlpha=f.alpha;ctx.fillStyle=f.color;ctx.fill();if(f.outline){ctx.strokeStyle=f.outline;ctx.lineWidth=.6;ctx.stroke()}}
 ctx.globalAlpha=1;
 // 3D lines and labels above geometry to keep controls legible at any angle.
 for(const item of stickers.filter(p=>p.type==='path')){const pts=item.pts.map(proj);if(pts.some(p=>p[2]<=.1))continue;ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.strokeStyle=item.color;ctx.lineWidth=item.width;ctx.setLineDash(item.dash||[]);ctx.lineCap='round';ctx.stroke();ctx.setLineDash([])}
 for(const item of stickers.filter(p=>p.type==='circle')){const [x,y,z]=proj(item.pos);if(z<=0||![x,y,z,item.r].every(Number.isFinite))continue;const r=clamp(item.r*camera.focal/z,2,50);if(!Number.isFinite(r))continue;const g=ctx.createRadialGradient(x-r*.3,y-r*.4,r*.1,x,y,r);g.addColorStop(0,'#d2e5a9');g.addColorStop(.4,item.color);g.addColorStop(1,'#215845');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()}
 for(const item of stickers.filter(p=>p.type==='label')){const [x,y,z]=proj(item.pos);if(z<=0||x<-30||x>w+40||y<-10||y>h+20)continue;ctx.font='700 10px system-ui';const tw=ctx.measureText(item.title).width;ctx.fillStyle='rgba(7,29,34,.84)';ctx.beginPath();ctx.roundRect(x-tw/2-9,y-15,tw+18,23,7);ctx.fill();ctx.fillStyle=item.color;ctx.textAlign='center';ctx.fillText(item.title,x,y);ctx.textAlign='start'}
 // Five-metre metric scale marker, projected at the near edge of the actual plot.
 const scaleSize=roomSize(profile),y=scaleSize.width/2+1,x=-Math.min(scaleSize.length/2,4.5),left=proj([x,y,.30]),right=proj([x+Math.min(5,scaleSize.length),y,.30]);
 if(left[2]>.1&&right[2]>.1){ctx.strokeStyle='#c8fb94';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(left[0],left[1]);ctx.lineTo(right[0],right[1]);ctx.stroke();ctx.fillStyle='#e1ffda';ctx.font='bold 12px system-ui';ctx.fillText(`${Math.min(5,scaleSize.length)} m scale`,(left[0]+right[0])/2-26,Math.min(h-23,(left[1]+right[1])/2-9))}
 if(!home.cutaway){ctx.fillStyle='rgba(234,251,245,.65)';ctx.font='600 11px system-ui';ctx.fillText('Select Open roof to arrange appliances inside',16,h-60)}
}
let needsRender=true;function requestDraw(){needsRender=true}
function tick(now=performance.now()){if(!canvas.isConnected){cancelAnimationFrame(anim);return}const dt=clamp((now-(lastTick||now))/1000,0,.065);lastTick=now;frame++;
 if(indoor){const forward=(activeKeys.has('w')||activeKeys.has('arrowup')||touchWalk==='forward'?1:0)-(activeKeys.has('s')||activeKeys.has('arrowdown')||touchWalk==='backward'?1:0);
 const sideways=(activeKeys.has('d')||touchWalk==='right'?1:0)-(activeKeys.has('a')||touchWalk==='left'?1:0);
 const turning=(activeKeys.has('arrowright')||touchWalk==='turn-right'?1:0)-(activeKeys.has('arrowleft')||touchWalk==='turn-left'?1:0);
 if(turning)indoorHeading+=turning*dt*1.7;
 walking=Boolean(forward||sideways);
 if(walking){const speed=(activeKeys.has('shift')?3.5:2.2)*dt;indoorPosition=walkStep(indoorPosition,indoorHeading,forward*speed,sideways*speed,profile);needsRender=true}
 if(turning||walking)needsRender=true;button('#cg-avatar').classList.toggle('walking',walking);const posText=`Position ${fmt(indoorPosition.x)} m × ${fmt(indoorPosition.y)} m`;if(button('#cg-indoor-location').textContent!==posText)button('#cg-indoor-location').textContent=posText;
 }
 if(needsRender||indoor&&walking||viewMode()!=='realistic'&&frame%7===0){render();needsRender=false}anim=requestAnimationFrame(tick)}
function updateUI(){const model=getModel(),breakdown=energyBreakdown(energy);
 for(const [id,value] of [['ambient',home.ambient],['solar',home.irradiance],['shade',home.shade]]){button(`#cg-${id}`).value=value;button(`#cg-${id}-label`).textContent=id==='shade'?`${value}%`:id==='solar'?`${value} W/m²`:`${value}°C`}
 button('#cg-house-type').value=['bungalow','duplex','apartment','sloped','school','shop'].includes(profile.type)?profile.type:'bungalow';button('#cg-floors').value=profile.floors||1;button('#cg-length').value=profile.length||12;button('#cg-width').value=profile.width||9;button('#cg-ceiling').value=profile.ceilingHeight||2.8;
 button('#cg-coat').checked=Boolean(home.roofCoating);button('#cg-insulate').checked=Boolean(home.roofInsulation);
 button('#cg-weather-source').textContent=home.dataSource||'Current inputs are manually assumed; no live measurement is inferred.';
 for(const [id,key] of [['ac','acCount'],['fan','fanCount'],['light','lightsCount'],['fridge','fridgeCount']])button(`#cg-${id}-count`).textContent=energy[key];
 button('#cg-ac-sub').textContent=`${fmt(breakdown.loads.ac)} kWh/month`;
 button('#cg-fan-sub').textContent=`${fmt(breakdown.loads.fans)} kWh/month`;
 button('#cg-light-sub').textContent=`${fmt(breakdown.loads.lights)} kWh/month`;
 button('#cg-fridge-sub').textContent=`${fmt(breakdown.loads.fridge)} kWh/month`;
 button('#cg-temp').textContent=fmt(model.indoor)+'°C';button('#cg-index').textContent=Math.round(model.heatIndex)+'/100';button('#cg-kwh').textContent=fmt(breakdown.total)+' kWh';button('#cg-relief').textContent=fmt(model.fanRelief)+'°C eq.';
 button('#cg-stage-house').textContent=(beforeMode?'ORIGINAL · ':'IMPROVED · ')+`${profile.name||'House'} · ${profile.length||12} × ${profile.width||9} × ${profile.ceilingHeight||2.8} m`;button('#cg-indoor').setAttribute('aria-pressed',String(indoor));button('#cg-indoor-pad').hidden=!indoor;button('#cg-avatar').hidden=!indoor;button('#cg-mobile-movement').hidden=!indoor;button('#cg-roof').disabled=indoor;button('#cg-hints').hidden=indoor;
 const mode=viewMode();button('#cg-stage-mode').textContent=indoor?'IMMERSIVE WEBGL 3D · 1:1 METRIC SCALE':mode==='thermal'?'ILLUSTRATIVE THERMAL LAYER':mode==='energy'?'ASSUMED HOUSEHOLD ENERGY FLOW':'ARCHITECTURAL MODEL · VISUAL REFERENCE';
 host.querySelectorAll('[data-mode]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.mode===mode)));
 button('#cg-roof').textContent=home.cutaway?'Close roof':'Open roof';button('#cg-roof').setAttribute('aria-pressed',String(home.cutaway));
 for(const k of Object.keys(placementKeys))button(`#cg-place-${k==='fans'?'fan':k}`).setAttribute('aria-pressed',String(placeTool===k));button('#cg-drop').disabled=!placeTool;
 button('#cg-explain-text').innerHTML=`<b>Why did the display change?</b> Assumed outdoor air ${fmt(model.ambient,0)}°C + passive solar/internal effects ${fmt(model.passive-model.ambient)}°C − modeled AC effect ${fmt(model.coolingEffect)}°C. ${energy.fanCount} fan(s) affect comfort only. Roof absorption ${fmt(model.roofAbsorbed)} kW under assumed sunlight. <b>These are screening sensitivities, not measured or calibrated indoor temperatures.</b>`;
 requestDraw();}
for(const id of ['ambient','solar','shade'])button(`#cg-${id}`).addEventListener('input',e=>{home=saveHome({...home,[id==='ambient'?'ambient':id==='solar'?'irradiance':'shade']:Number(e.target.value),dataSource:'Manual input'});updateUI()});
button('#cg-city-weather').onclick=async()=>{
 const btn=button('#cg-city-weather');btn.disabled=true;button('#cg-weather-source').textContent='Looking up the selected city and requesting weather observations / model data…';
 try{
   let lat=Number(profile.lat),lon=Number(profile.lon);
   if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)<.001){const found=await searchCity(profile.city||'Pune');lat=found.lat;lon=found.lon;profile=saveProfile({...profile,lat,lon});}
   const result=await currentWeather([{id:'property',lat,lon,name:profile.city||'Property'}]);const rec=result.values?.property;
   if(!Number.isFinite(rec?.temp))throw Error('Temperature data unavailable');
   const next={ambient:clamp(Math.round(rec.temp),18,45)};let source=`${rec.source}: ${rec.time||'time unavailable'}${rec.stale?' (stale/cached)':''}. Outdoor 2m air temperature; not indoor.`;
   const hour=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',hour:'2-digit',hourCycle:'h23'}).format(new Date()));
   try{const solar=await shortwaveAt({lat,lon,date:todayIndia(),hour});next.irradiance=clamp(Math.round(solar.watts/25)*25,0,1100);source+=` Solar input: ${solar.source}, ${solar.time} (modelled).`}
   catch{source+=' Solar irradiance remains your previous assumption (provider unavailable).'}
   next.dataSource=source;home=saveHome(next);updateUI();
 }catch(err){button('#cg-weather-source').textContent=`Local weather unavailable (${String(err.message).slice(0,140)}). Existing assumptions retained.`;}
 finally{btn.disabled=false}
};
for(const [id,key] of [['cg-house-type','type'],['cg-floors','floors'],['cg-length','length'],['cg-width','width'],['cg-ceiling','ceilingHeight']])button('#'+id).addEventListener('change',e=>{const v=key==='type'?e.target.value:Number(e.target.value);const next={[key]:v};if(key==='type'){next.floors=v==='apartment'?4:v==='duplex'?2:1;if(v==='sloped')next.roof='tile';else if(profile.roof==='tile')next.roof='concrete';}profile=saveProfile(next);if(key==='length'||key==='width'){dist=fitDistance();const bounds=walkBounds(profile);indoorPosition={x:clamp(indoorPosition.x,bounds.xmin,bounds.xmax),y:clamp(indoorPosition.y,bounds.ymin,bounds.ymax)}}beforeMode=false;updateUI()});
button('#cg-before').onclick=()=>{beforeMode=true;button('#cg-compare-status').textContent='ORIGINAL: improvement choices temporarily hidden; saved improvements unchanged.';updateUI()};
button('#cg-after').onclick=()=>{beforeMode=false;button('#cg-compare-status').textContent='IMPROVED: your selected roof and shading measures are displayed.';updateUI()};
for(const [id,key] of [['coat','roofCoating'],['insulate','roofInsulation']])button(`#cg-${id}`).addEventListener('change',e=>{home=saveHome({[key]:e.target.checked});updateUI()});
for(const buttonEl of host.querySelectorAll('[data-inc]'))buttonEl.addEventListener('click',()=>{const key=buttonEl.dataset.inc;energy=saveEnergy({[key]:clamp(energy[key]+Number(buttonEl.dataset.step),0,key==='acCount'?8:16)});syncPositions();updateUI()});
for(const buttonEl of host.querySelectorAll('[data-mode]'))buttonEl.addEventListener('click',()=>{home=saveHome({thermal:buttonEl.dataset.mode==='realistic'?false:buttonEl.dataset.mode});updateUI()});
button('#cg-roof').onclick=()=>{home=saveHome({cutaway:!home.cutaway});updateUI()};
button('#cg-default').onclick=()=>{yaw=.76;pitch=.57;dist=fitDistance();indoor=false;indoorPosition={x:0,y:0};indoorHeading=0;placeTool='';updateUI()};
button('#cg-reset').onclick=()=>{home=saveHome({ambient:34,irradiance:800,roofCoating:false,roofInsulation:false,shade:15,cutaway:true,thermal:true});placeTool='';updateUI()};
button('#cg-save').onclick=()=>{const model=getModel();const ok=saveScenario({property:profile,scenarioType:'house-climate',appliances:energy,conditions:home,positions:JSON.parse(JSON.stringify(positions)),heatIndex:model.heatIndex,notes:'Illustrative model, not measured thermal data'});button('#cg-saved').textContent=ok?'Scenario saved in My Projects on this browser. Appliance values also sync to Energy & Savings.':'Unable to save; browser storage may be disabled.'};
for(const [id,key] of [['#cg-place-ac','ac'],['#cg-place-fan','fans'],['#cg-place-lights','lights'],['#cg-place-fridge','fridge']])button(id).onclick=()=>{placeTool=placeTool===key?'':key;if(!home.cutaway)home=saveHome({cutaway:true});updateUI()};
function placeAtCanonical(tool,loc){if(!tool||!placementKeys[tool])return;
 const key=placementKeys[tool],maximum={ac:8,fans:16,lights:30,fridge:12}[tool];if(energy[key]>=maximum){button('#cg-placement-feedback').textContent='Maximum number of this appliance reached. Use minus to remove an existing one.';return}energy=saveEnergy({[key]:energy[key]+1});syncPositions();const idx=energy[key]-1;
 const x=clamp(loc[0],-4.12,4.12),y=clamp(loc[1],-2.99,2.99);positions[tool][idx]=[x,y];syncPositions();
 button('#cg-placement-feedback').textContent=`${tool==='lights'?'LED light':tool==='fridge'?'Refrigerator':tool==='fans'?'Ceiling fan':'Air conditioner'} positioned at ${fmt(x*dimensions.sx)}m × ${fmt(y*dimensions.sy)}m in the room.`;
 updateUI();}
function placeIndoor(xOffset=0,distance=1.8){if(!placeTool){button('#cg-placement-feedback').textContent='Choose an appliance under “Appliances inside” first.';return}
 const angle=indoorHeading+xOffset,location=placementInFront(indoorPosition,angle,profile,distance);
 placeAtCanonical(placeTool,[location.x/dimensions.sx,location.y/dimensions.sy]);}
function setIndoor(value){indoor=Boolean(value);if(indoor&&!indoorEntered){indoorPosition={x:0,y:-roomSize(profile).width/2+1.15};indoorHeading=0;indoorEntered=true}activeKeys.clear();touchWalk='';walking=false;drag=null;pointers.clear();if(indoor){const b=walkBounds(profile);indoorPosition={x:clamp(indoorPosition.x,b.xmin,b.xmax),y:clamp(indoorPosition.y,b.ymin,b.ymax)};placeTool=placeTool||'';if(immersive.available)immersive.canvas.focus({preventScroll:true});else canvas.focus({preventScroll:true})}immersive.show(indoor);updateUI();}
button('#cg-indoor').onclick=()=>setIndoor(!indoor);button('#cg-exit-indoor').onclick=()=>setIndoor(false);
function zoom(dir){if(indoor){indoorFov=clamp(indoorFov-dir*.12,.60,1.60)}else{dist=clamp(dist*(dir>0?.86:1.16),Math.max(6,fitDistance()*.35),fitDistance()*2.7)}requestDraw()}
button('#cg-zoom-in').onclick=()=>zoom(1);button('#cg-zoom-out').onclick=()=>zoom(-1);
button('#cg-drop').onclick=()=>placeIndoor();button('#cg-drop-mobile').onclick=()=>placeIndoor();
for(const el of host.querySelectorAll('[data-walk]')){
 el.addEventListener('pointerdown',e=>{e.preventDefault();touchWalk=el.dataset.walk;el.setPointerCapture(e.pointerId);requestDraw()});
 for(const event of ['pointerup','pointercancel','lostpointercapture'])el.addEventListener(event,()=>{touchWalk='';requestDraw()});
}
function localScreen(e){const rect=canvas.getBoundingClientRect();return {x:e.clientX-rect.left,y:e.clientY-rect.top,w:rect.width,h:rect.height}}
canvas.addEventListener('pointerdown',e=>{pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(pointers.size===2){const pts=[...pointers.values()];pinchStart={length:Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y),dist,fov:indoorFov};drag=null;return}
 drag={x:e.clientX,y:e.clientY,yaw:indoor?indoorHeading:yaw,pitch:indoor?indoorLook:pitch,moved:false};try{canvas.setPointerCapture(e.pointerId)}catch{}});
canvas.addEventListener('pointermove',e=>{if(pointers.has(e.pointerId))pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(pointers.size===2&&pinchStart){const pts=[...pointers.values()],length=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);if(length>4){if(indoor)indoorFov=clamp(pinchStart.fov*pinchStart.length/length,.60,1.60);else dist=clamp(pinchStart.dist*pinchStart.length/length,Math.max(6,fitDistance()*.35),fitDistance()*2.7);requestDraw()}return}
 if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.hypot(dx,dy)>5)drag.moved=true;if(drag.moved){if(indoor){indoorHeading=drag.yaw+dx*.005;indoorLook=clamp(drag.pitch+dy*.0019,-.23,.23)}else{yaw=drag.yaw+dx*.009;pitch=clamp(drag.pitch+dy*.006,.10,1.40)}requestDraw()}});
canvas.addEventListener('pointerup',e=>{pointers.delete(e.pointerId);if(pointers.size<2)pinchStart=null;
 if(drag&&!drag.moved&&placeTool){const mouse=localScreen(e);
 if(indoor){placeIndoor(Math.atan((mouse.x-mouse.w/2)/(mouse.w/(2*Math.tan(indoorFov/2)))),clamp(1.4+(1-mouse.y/mouse.h)*2.4,1.1,4))}
 else if(home.cutaway){const cam=setCamera(mouse.w,mouse.h),r=cam.right,u=cam.up,f=cam.fw,cx=(mouse.x-mouse.w/2)/cam.focal,cy=-(mouse.y-mouse.h*.57)/cam.focal;
 const ray=norm(add(f,add(scale(r,cx),scale(u,cy))));const t=(.7-cam.eye[2])/(ray[2]||.000001);const hit=add(cam.eye,scale(ray,t));
 if(t>0&&Math.abs(hit[0])<dimensions.sx*4.15&&Math.abs(hit[1])<dimensions.sy*2.95)placeAtCanonical(placeTool,[hit[0]/dimensions.sx,hit[1]/dimensions.sy]);
 }}drag=null;requestDraw()});
canvas.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);drag=null;pinchStart=null});
canvas.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1:-1)},{passive:false});
canvas.addEventListener('keydown',e=>{if(indoor){const key=e.key.toLowerCase();if(['w','a','s','d','arrowleft','arrowright','arrowup','arrowdown','shift'].includes(key)){activeKeys.add(key);e.preventDefault()}if(key==='escape'){setIndoor(false);e.preventDefault()}}
 else{if(e.key==='ArrowLeft'){yaw-=.13;requestDraw();e.preventDefault()}else if(e.key==='ArrowRight'){yaw+=.13;requestDraw();e.preventDefault()}else if(e.key==='ArrowUp'){pitch=clamp(pitch+.1,.1,1.4);requestDraw();e.preventDefault()}else if(e.key==='ArrowDown'){pitch=clamp(pitch-.1,.1,1.4);requestDraw();e.preventDefault()}}});
window.addEventListener('keydown',e=>{if(indoor&&!['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName)&&!e.ctrlKey&&!e.altKey&&!e.metaKey){const key=e.key.toLowerCase();if(['w','a','s','d','arrowleft','arrowright','arrowup','arrowdown','shift'].includes(key)){activeKeys.add(key);e.preventDefault()}}});
window.addEventListener('keyup',e=>activeKeys.delete(e.key.toLowerCase()));
window.addEventListener('blur',()=>{activeKeys.clear();touchWalk=''});
window.addEventListener('urban-energy-change',()=>{energy=getEnergy();syncPositions();updateUI()});
window.addEventListener('urban-property-change',()=>{profile=getProfile();updateUI()});
window.addEventListener('storage',e=>{if(e.key==='us4.calc.electricity'){energy=getEnergy();syncPositions();updateUI()}else if(e.key==='us4.property'){profile=getProfile();updateUI()}});
window.addEventListener('resize',requestDraw);updateUI();tick();
}
