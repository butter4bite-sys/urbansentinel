/** House Climate Studio: mouse-orbit architectural 3D scene drawn with Canvas 2D.
 * Positions are 3D coordinates, not a photographic reconstruction. Heat overlays use
 * the disclosed screening index (NOT measured temperature or CFD). No CDN required.
 */
import {getEnergy,saveEnergy,energyBreakdown,getHome,saveHome,thermalEstimate,thermalColor} from './home-energy-model.js';
import {getProfile,saveProfile,saveScenario,safe} from './property-profile.js';
import {currentWeather} from './weather-service.js';
import {searchCity,shortwaveAt} from './satellite-map.js';
import {todayIndia} from './solar-science.js';
import {roomSize,walkBounds,walkStep,placementInFront,drawIndoor} from './indoor-walkthrough.js';
import {mountImmersiveRoom} from './immersive-room.js';
import {KINDS,getDesign,saveDesign,makeObject,autoLayout,placementArrays,floorEnergy,syncEnergyFromDesign,importAppliancesFromEnergy,floorObjects,floorSimulation} from './simulation-design.js';
import {getCoolingPlan,coolingPlanIssues,compareScenarios,baselineDesign,baselineHome,applyCoolingPlan} from './cooling-bridge.js';
const host=document.getElementById('climateGame');
const isXray=document.body.dataset.page==='xray-house';
if(host){
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const fmt=(x,d=1)=>Number(x).toLocaleString('en-IN',{maximumFractionDigits:d});
let energy=getEnergy(),home=getHome(),profile=getProfile();
let design=getDesign();
if(!design.objects.length)design=saveDesign(importAppliancesFromEnergy(design,energy,0));
else if(['ac','fans','lights','fridge'].some((kind)=>design.objects.filter(o=>o.kind===kind).length !== Number(energy[{ac:'acCount',fans:'fanCount',lights:'lightsCount',fridge:'fridgeCount'}[kind]]||0)))design=saveDesign(importAppliancesFromEnergy(design,energy,design.selectedFloor||0));
let activeFloor=Math.min(Math.max(0,design.selectedFloor||0),Math.max(0,(Number(profile.floors)||1)-1));
let simulationActive=false,simulationView='both';
const guidedDefault={...design.guided};

let beforeMode=false;
const fitDistance=()=>Math.max(18,Math.hypot(Number(profile.length)||12,Number(profile.width)||9)*1.68);
let yaw=.76,pitch=.57,dist=fitDistance(),drag=null,placeTool='',lastHit=null,frame=0,anim=0;
let indoor=false, indoorEntered=false, indoorPosition={x:0,y:0}, indoorHeading=0, indoorLook=0, indoorFov=1.23, walking=false, lastTick=0;
const activeKeys=new Set(),pointers=new Map(); let touchWalk='',pinchStart=null;
const placementKeys={ac:'acCount',fans:'fanCount',lights:'lightsCount',fridge:'fridgeCount'};
let dimensions={sx:1,sy:1};
let positions=placementArrays(design,activeFloor);
function syncPositions(){positions=placementArrays(design,activeFloor);try{localStorage.setItem('us4.climate.positions',JSON.stringify(positions))}catch{}}
const floorCount=()=>Math.max(1,Math.min(6,Math.round(Number(profile.floors)||1)));
function persistDesign(next,energySync=true){design=saveDesign(next);activeFloor=Math.max(0,Math.min(floorCount()-1,design.selectedFloor||0));syncPositions();if(energySync)energy=syncEnergyFromDesign(design);updateUI()}
function onFloorChange(floor){activeFloor=clamp(floor,0,floorCount()-1);design=saveDesign({...design,selectedFloor:activeFloor});syncPositions();indoorPosition={x:0,y:0};indoorEntered=false;placeTool='';updateUI()}
const restoreId=new URLSearchParams(location.search).get('scenario');
if(restoreId){try{const item=JSON.parse(localStorage.getItem('us4.scenarios')||'[]').find(s=>String(s.id)===restoreId&&s.scenarioType==='house-climate');if(item){
  profile=saveProfile(item.property||{});energy=saveEnergy(item.appliances||{});home=saveHome(item.conditions||{});
  if(item.design?.objects){design=saveDesign(item.design);activeFloor=design.selectedFloor||0;}
}}catch{}}
syncPositions();
host.innerHTML=`<section class="cg-wrap" aria-label="Interactive 3D house climate studio">
 <div class="cg-title"><div><span class="us4-eyebrow">PROPERTY · 3D SIMULATION</span><h2>Design your home. Then run a climate scenario.</h2><p>Answer a few questions to generate your multi-floor house, refine any floor manually, then press <strong>Start simulation</strong> to see modeled heat exposure and indicative wind paths. Use Indoor to walk through each floor.</p></div><a class="btn secondary cg-energy-link" href="energy-savings.html">View shared electricity data →</a></div>
 <div class="usjudge-intro" role="region" aria-label="Judge demonstration guide"><div><strong>Competition demonstration · a connected workflow</strong><p>1. Build your property or open the Cooling Planner · 2. Apply suggested measures · 3. Start Simulation · 4. Switch Original / Improved · 5. Review assumptions and connect to providers.</p></div><button type="button" id="cg-demo" class="btn secondary">Load example house</button></div><div class="cg-layout"><aside class="cg-controls us4-card">
 <div class="cg-guided cg-sim-panel" id="cg-guided"><div class="cg-panel-head"><span class="cg-mini-label">HOUSE SETUP · GUIDED</span><strong id="cg-wizard-progress">Step 1 / 3</strong></div>
  <div class="cg-wizard-step" data-step="0"><h3>1. Your building</h3><p>Select the house type, number of floors and actual metre dimensions in Building conditions below. These measurements determine the model size on every floor.</p><p class="cg-fine">Already completed a Cooling Plan? Your saved city, roof, budget and window direction will be loaded where available.</p></div>
  <div class="cg-wizard-step" data-step="1" hidden><h3>2. Windows and airflow</h3><label class="us4-field">Windows per floor <input id="cg-windows" type="number" min="0" max="12" value="2"></label><label class="us4-field">Main window direction<select id="cg-window-wall"><option value="opposite">Opposite walls (cross-flow)</option><option value="north">North</option><option value="south">South</option><option value="east">East</option><option value="west">West</option><option value="mixed">Mixed east and west</option></select></label><label class="cg-check-line"><input id="cg-windows-open" type="checkbox" checked> Windows open for airflow scenario</label><label class="cg-check-line"><input id="cg-vent-included" type="checkbox" checked> Add air vents on each floor</label><label class="cg-check-line"><input id="cg-exhaust-included" type="checkbox"> Add exhaust fans on each floor</label><p class="cg-fine">Placement is a starting suggestion, not a measured floor plan. Move or add openings manually afterwards.</p></div>
  <div class="cg-wizard-step" data-step="2" hidden><h3>3. Appliances and improvements</h3><div class="cg-quick-grid"><label>ACs (building total)<input id="cg-guide-ac" type="number" min="0" max="24"></label><label>Fans<input id="cg-guide-fans" type="number" min="0" max="36"></label><label>LED lights<input id="cg-guide-lights" type="number" min="0" max="48"></label><label>Refrigerators<input id="cg-guide-fridge" type="number" min="0" max="12"></label></div><div class="cg-checks"><label><input id="cg-guide-shade" type="checkbox"> External shading</label><label><input id="cg-guide-insulation" type="checkbox"> Insulation</label><label><input id="cg-guide-solar" type="checkbox"> Solar panels</label></div><p class="cg-fine">Appliance totals sync with Energy & Savings. Generated equipment is spread across the selected floors.</p></div>
  <div class="cg-wizard-nav"><button id="cg-wizard-back" class="btn secondary" type="button" disabled>Back</button><button id="cg-wizard-next" class="btn" type="button">Next →</button><button id="cg-generate" class="btn" type="button" hidden>Generate house</button></div><p class="cg-fine" id="cg-guide-status" aria-live="polite"></p></div>

 <div class="cg-section-title"><span>01</span> Building conditions</div>
 <div class="cg-inputs"><label class="us4-field">House type<select id="cg-house-type"><option value="bungalow">Single-floor bungalow</option><option value="duplex">Duplex house</option><option value="apartment">Apartment building</option><option value="sloped">Sloped-roof house</option><option value="school">School building</option><option value="shop">Shop / commercial</option></select></label>
 <div class="cg-type-details"><label class="us4-field">Floors <input id="cg-floors" type="number" min="1" max="6" step="1"></label><label class="us4-field">Room length (m) <input id="cg-length" type="number" min="3" max="80" step="0.5"></label><label class="us4-field">Room width (m) <input id="cg-width" type="number" min="3" max="80" step="0.5"></label><label class="us4-field">Ceiling height (m) <input id="cg-ceiling" type="number" min="2.2" max="4.5" step="0.1"></label></div>
 <p class="cg-fine cg-scale-note"><strong>True metric scale: 1 model unit = 1 metre.</strong> Changing the length, width or ceiling height changes the actual simulated room bounds, not just the displayed numbers. Shared with X-Ray, Assessment and Energy.</p></div>
 <div class="cg-inputs"><label class="us4-field">Outdoor air temperature · assumed <span id="cg-ambient-label"></span><input id="cg-ambient" type="range" min="18" max="45" step="1"></label>
 <label class="us4-field">Solar intensity (W/m²) · assumed <span id="cg-solar-label"></span><input id="cg-solar" type="range" min="0" max="1100" step="25"></label>
 <label class="us4-field">Window / courtyard shading <span id="cg-shade-label"></span><input id="cg-shade" type="range" min="0" max="80" step="5"></label>
 <div class="cg-checks"><label><input type="checkbox" id="cg-coat"> Reflective roof</label><label><input type="checkbox" id="cg-insulate"> Roof insulation</label></div><button class="btn secondary cg-city-weather" id="cg-city-weather" type="button">Use local weather data</button><p class="cg-fine" id="cg-weather-source" aria-live="polite">Current inputs are manually assumed; no live measurement is inferred.</p></div>
 <div class="cg-section-title"><span>02</span> Appliances on selected floor</div><p class="cg-fine">Use the floor selector above the model. Counts below apply to that floor; energy totals include all floors.</p>
 <div class="cg-counts"><label class="cg-step"><span><strong>Air conditioners</strong><small id="cg-ac-sub"></small></span><span class="cg-spinner"><button data-inc="acCount" data-step="-1" aria-label="Remove air conditioner">−</button><output id="cg-ac-count"></output><button data-inc="acCount" data-step="1" aria-label="Add air conditioner">+</button></span></label>
 <label class="cg-step"><span><strong>Ceiling fans</strong><small id="cg-fan-sub"></small></span><span class="cg-spinner"><button data-inc="fanCount" data-step="-1" aria-label="Remove fan">−</button><output id="cg-fan-count"></output><button data-inc="fanCount" data-step="1" aria-label="Add fan">+</button></span></label>
 <label class="cg-step"><span><strong>LED lights</strong><small id="cg-light-sub"></small></span><span class="cg-spinner"><button data-inc="lightsCount" data-step="-1" aria-label="Remove light">−</button><output id="cg-light-count"></output><button data-inc="lightsCount" data-step="1" aria-label="Add light">+</button></span></label>
 <label class="cg-step"><span><strong>Refrigerators</strong><small id="cg-fridge-sub"></small></span><span class="cg-spinner"><button data-inc="fridgeCount" data-step="-1" aria-label="Remove refrigerator">−</button><output id="cg-fridge-count"></output><button data-inc="fridgeCount" data-step="1" aria-label="Add refrigerator">+</button></span></label></div>
 <div class="cg-placement"><button id="cg-place-ac" class="cg-tool" type="button" aria-pressed="false">Place AC</button><button id="cg-place-fan" class="cg-tool" type="button" aria-pressed="false">Place fan</button><button id="cg-place-lights" class="cg-tool" type="button" aria-pressed="false">Place LED</button><button id="cg-place-fridge" class="cg-tool" type="button" aria-pressed="false">Place refrigerator</button><p>Choose an appliance, then tap its destination in the open-roof view. In Indoor mode, walk to a position and tap <b>Place here</b> or tap the scene.</p></div>
 <div class="cg-section-title"><span>03</span> Manual building editor</div>
 <div class="cg-manual-panel"><label class="us4-field">Object category<select id="cg-object-category"></select></label><label class="us4-field">Object<select id="cg-object-type"></select></label><label class="us4-field" id="cg-wall-wrap">Wall for windows / vents<select id="cg-object-wall"><option value="north">North</option><option value="south">South</option><option value="east">East</option><option value="west">West</option></select></label>
 <div class="cg-choices"><button class="btn secondary" type="button" id="cg-arm-object">Place on model</button><button class="btn secondary" type="button" id="cg-add-center">Add now</button><button class="btn secondary" type="button" id="cg-delete-last">Undo last on floor</button></div><p class="cg-fine">Place on model: tap an area with the roof open. Indoor: walk to a spot and press Place here. Windows, vents, shade and doors attach to the chosen wall.</p><div id="cg-objects-list" class="cg-objects-list" aria-live="polite"></div></div>
 <div class="cg-section-title"><span>04</span> Connected cooling plan</div><div class="usjudge-plan"><p id="cg-plan-brief">Checking the latest Cooling Planner result…</p><div class="cg-choices"><button id="cg-apply-plan" class="btn" type="button">Apply saved Cooling Plan</button><a class="btn secondary" href="assessment.html?type=home">Edit Cooling Plan ↗</a></div><p id="cg-plan-message" class="cg-fine" role="status" aria-live="polite"></p></div><div class="cg-section-title"><span>05</span> Compare &amp; actions</div><div class="cg-choices"><button id="cg-before" class="btn secondary" type="button">Show original house</button><button id="cg-after" class="btn secondary" type="button">Show improved house</button></div><p class="cg-fine" id="cg-compare-status">Both views use the same rotatable building and camera angle.</p><div id="cg-comparison" class="usjudge-compare" aria-live="polite"><p>Choose Original or Improved to compare.</p></div><div class="cg-choices"><button id="cg-default" class="btn secondary" type="button">Reset view</button><button id="cg-reset" class="btn secondary" type="button">Reset changes</button><button id="cg-save" class="btn" type="button">Save scenario</button></div><p id="cg-saved" class="cg-fine" aria-live="polite"></p>
 </aside>
 <div class="cg-main"><section class="cg-stage-area">
 <div class="cg-toolbar" role="group" aria-label="Model visualization mode"><span class="cg-view-label">3D HOUSE MODEL · 1 UNIT = 1 METRE</span><span class="cg-toolbar-gap"></span><label class="cg-floor-picker">Edit floor <select id="cg-active-floor" aria-label="Selected floor"></select></label><div class="cg-zoom-control" aria-label="Zoom"><button id="cg-zoom-out" type="button" aria-label="Zoom out">−</button><span>Zoom</span><button id="cg-zoom-in" type="button" aria-label="Zoom in">+</button></div><button id="cg-indoor" class="cg-indoor-btn" type="button" aria-pressed="false" title="Enter first-person walk-through">Indoor</button><button id="cg-roof" aria-pressed="true" title="Show inside of house">Open roof</button></div>
 <div class="cg-stage" id="cg-stage"><canvas id="cg-canvas" tabindex="0" role="img" aria-label="Rotatable architectural 3D house with interactive heat and appliance layout. Drag to rotate; use plus and minus controls to change appliances."></canvas>
 <div class="cg-stage-top"><span id="cg-stage-mode">ILLUSTRATIVE THERMAL LAYER</span><span id="cg-stage-house"></span></div>
 <div class="cg-controls-hint" id="cg-hints"><span>↻ Drag to rotate</span><span>⊕ Pinch or + / − to zoom</span><span>↔ Tap to position equipment</span></div>
 <div class="cg-mobile-movement" id="cg-mobile-movement" hidden aria-label="Mobile walking controls"><button data-walk="turn-left" type="button" aria-label="Turn left">↶</button><button data-walk="forward" type="button" aria-label="Walk forward">↑</button><button data-walk="turn-right" type="button" aria-label="Turn right">↷</button><button data-walk="left" type="button" aria-label="Step left">←</button><button data-walk="backward" type="button" aria-label="Walk backward">↓</button><button data-walk="right" type="button" aria-label="Step right">→</button><button id="cg-drop-mobile" class="cg-mobile-add" type="button">+ Add</button></div>
 <div class="cg-avatar" id="cg-avatar" hidden aria-hidden="true"><svg viewBox="0 0 58 90" class="cg-walker-svg" xmlns="http://www.w3.org/2000/svg"><circle cx="29" cy="15" r="10" fill="#d3d9c8"/><rect x="20" y="27" width="18" height="28" rx="7" fill="#7be0bd"/><line class="cg-walker-arm left" x1="21" y1="33" x2="12" y2="59"/><line class="cg-walker-arm right" x1="37" y1="33" x2="46" y2="59"/><line class="cg-walker-leg left" x1="25" y1="52" x2="21" y2="81"/><line class="cg-walker-leg right" x1="33" y1="52" x2="38" y2="81"/></svg><span>Walking view</span></div>
 <div class="cg-compass" aria-hidden="true"><div>N</div><span>✦</span></div>
 </div>
 <div class="cg-indoor-pad" id="cg-indoor-pad" hidden><div class="cg-indoor-help"><strong>Indoor · 3D walkthrough</strong><span>W/A/S/D to move · drag to look · mobile arrows to walk · choose an appliance and tap to place</span><span id="cg-indoor-location" class="cg-indoor-location">Position 0.0 m × 0.0 m</span></div><div class="cg-walk-buttons"><button data-walk="turn-left" type="button" aria-label="Turn left">↶</button><button data-walk="forward" type="button" aria-label="Walk forward">↑</button><button data-walk="turn-right" type="button" aria-label="Turn right">↷</button><button data-walk="left" type="button" aria-label="Step left">←</button><button data-walk="backward" type="button" aria-label="Walk backward">↓</button><button data-walk="right" type="button" aria-label="Step right">→</button></div><div class="cg-floor-steps"><button id="cg-floor-down" type="button">↓ Floor</button><strong id="cg-indoor-floor-label">Ground floor</strong><button id="cg-floor-up" type="button">↑ Floor</button></div><button class="cg-placement-action" id="cg-drop" type="button">Place selected here</button><button class="cg-exit" id="cg-exit-indoor" type="button">Exit Indoor</button><div class="cg-placement-feedback" id="cg-placement-feedback" aria-live="polite"></div></div>
 <div class="cg-sim-startbar"><div><b>Run a heat + wind scenario</b><small>Animation and estimates use the selected floor's windows, ACs, fans, roof and local assumptions.</small></div><button id="cg-start-simulation" class="btn" type="button">▶ Start simulation</button><button id="cg-stop-simulation" class="btn secondary" type="button" hidden>Stop simulation</button></div>
 <div class="usjudge-method"><strong>What these results mean</strong><p>Wind arrows represent opportunities from selected window and vent positions, not a CFD simulation. Heat colours and the risk index are illustrative rankings, not thermal-camera readings, indoor thermometer predictions or engineering certification. Roof absorbed solar power is estimated from area × solar irradiance × (1 − roof reflectance) × (1 − shade fraction).</p><details><summary>Read the modelling assumptions</summary><p>Airflow uses an opening-direction screening index. The thermal index is a transparent sensitivity model affected by user-selected appliances and shading. Fans influence comfort but do not cool dry-bulb air. Installation costs from the Cooling Planner are planning allowances, not supplier quotations. These outputs must be checked by an engineer before real building work.</p></details></div><div class="cg-simulation-panel" id="cg-simulation-panel" hidden><div class="cg-sim-options"><label>Wind from<select id="cg-wind-from"><option>north</option><option>east</option><option>south</option><option>west</option></select></label><label>Wind speed (m/s) <input id="cg-wind-speed" type="range" min="0" max="12" step="0.5" value="3.5"></label><output id="cg-wind-speed-out">3.5 m/s</output><label>Display<select id="cg-sim-overlay"><option value="both">Heat and wind</option><option value="heat">Heat only</option><option value="wind">Wind only</option></select></label></div><div class="cg-simulation-readings"><div><small>Selected-floor heat / comfort risk</small><strong id="cg-sim-heat">—</strong></div><div><small>Wind opportunity index</small><strong id="cg-sim-wind">—</strong></div><div><small>Cross ventilation</small><strong id="cg-sim-cross">—</strong></div><div><small>Roof absorbed solar power</small><strong id="cg-sim-roof">—</strong></div></div><p id="cg-sim-explanation" class="cg-fine"></p></div>
 <div class="cg-gradient" id="cg-heat-legend" hidden><span>Lower relative heat</span><div class="cg-gradient-bar"></div><span>Higher relative heat</span></div>
 <div class="cg-metrics" id="cg-main-metrics" hidden aria-live="polite"><div><small>Estimated roof solar absorption</small><strong id="cg-temp">—</strong><span>At the assumed irradiance; not indoor heat</span></div><div><small>Heat / comfort risk index</small><strong id="cg-index">—</strong><span>Lower is better</span></div><div><small>Monthly appliance electricity</small><strong id="cg-kwh">—</strong><span>Same inputs as Bill Detective</span></div><div><small>Fan count · selected floor</small><strong id="cg-relief">—</strong><span>Air movement is not air cooling</span></div></div>
 <div class="cg-explain" id="cg-simulation-explain" hidden><span class="cg-info-icon">i</span><div id="cg-explain-text"></div></div>
 </section>
 <div class="cg-bottom"><div class="cg-source-note">This is a <b>rotatable conceptual building model</b>, not a 3D scan or a measured thermal image. The thermal colors represent a relative modeled heat/comfort index. AC cooling is an illustrative assumption; actual room temperature requires on-site data. Fans improve perceived comfort, not air temperature.</div><a href="energy-savings.html" class="cg-energy-cta">Open energy consumption map &amp; bill analysis ↗</a></div>
 </div></div></section>`;
const canvas=host.querySelector('#cg-canvas'),ctx=canvas.getContext('2d',{alpha:false});
const immersive=mountImmersiveRoom(host.querySelector('#cg-stage'),{
  turn(dx,dy){indoorHeading+=dx*.0049;indoorLook=clamp(indoorLook+dy*.0018,-.23,.23);requestDraw()},
  zoom(dir){zoom(dir)},
  tap(e){if(placeTool)placeIndoor(0,1.6)},
  exit(){setIndoor(false)}
});
const button=(id)=>host.querySelector(id);
const viewMode=()=>simulationActive?(simulationView==='wind'?'realistic':'thermal'):'realistic';
function activeHome(){return beforeMode?baselineHome(home):home}
function visualDesign(){return beforeMode?baselineDesign(design):design}
function getModel(){return thermalEstimate({energy,home:activeHome(),profile})}
const P=(x,y,z)=>[x,y,z];
const physical=p=>[p[0]*dimensions.sx,p[1]*dimensions.sy,p[2]];
const add=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]],sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],scale=(a,s)=>a.map(v=>v*s);
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const norm=a=>scale(a,1/(Math.hypot(...a)||1));
let camera;
function setCamera(w,h){const f=clamp(Number(profile.floors)||1,1,4),ceil=clamp(Number(profile.ceilingHeight)||2.8,2.2,4.5),target=P(0,0,1.25+activeFloor*ceil),eye=add(target,P(dist*Math.cos(pitch)*Math.sin(yaw),-dist*Math.cos(pitch)*Math.cos(yaw),dist*Math.sin(pitch)));const fw=norm(sub(target,eye));const right=norm(cross(fw,P(0,0,1))),up=norm(cross(right,fw));return{eye,target,fw,right,up,w,h,focal:Math.min(w*1.22,h*1.70)}}
function proj(pt){const v=sub(pt,camera.eye),z=dot(v,camera.fw);return [camera.w/2+dot(v,camera.right)*camera.focal/Math.max(.01,z),camera.h*.57-dot(v,camera.up)*camera.focal/Math.max(.01,z),z]}
let faces=[],stickers=[];
function face(pts,color,alpha=1,outline=null){const points=pts.map(physical);faces.push({pts:points,color,alpha,outline,depth:points.reduce((s,p)=>s+dot(sub(p,camera.eye),camera.fw),0)/points.length})}
function box(x1,y1,z1,x2,y2,z2,color,alpha=1){const a=P(x1,y1,z1),b=P(x2,y1,z1),c=P(x2,y2,z1),d=P(x1,y2,z1),e=P(x1,y1,z2),f=P(x2,y1,z2),g=P(x2,y2,z2),h=P(x1,y2,z2);face([a,d,c,b],color,alpha);face([e,f,g,h],color,alpha);face([a,b,f,e],color,alpha);face([b,c,g,f],color,alpha);face([c,d,h,g],color,alpha);face([d,a,e,h],color,alpha)}
function quad(a,b,c,d,color,alpha=1){face([a,b,c,d],color,alpha)}
function path(pts,color,width=1.2,dash=[]){const points=pts.map(physical);stickers.push({type:'path',pts:points,color,width,dash,depth:points.reduce((s,p)=>s+dot(sub(p,camera.eye),camera.fw),0)/points.length})}
function circle(x,y,z,r,color){const point=physical(P(x,y,z));stickers.push({type:'circle',pos:point,r,color,depth:dot(sub(point,camera.eye),camera.fw)})}
function label(x,y,z,title,subtitle,color='#b2ffe1'){const point=physical(P(x,y,z));stickers.push({type:'label',pos:point,title,subtitle,color,depth:dot(sub(point,camera.eye),camera.fw)})}
function material(s){return s}
function buildHouse(){faces=[];stickers=[];const model=getModel(),mode=viewMode(),heat=mode==='thermal',isFlow=mode==='energy',cut=home.cutaway;const floors=clamp(Math.round(profile.floors)||1,1,6),floorHeight=clamp(Number(profile.ceilingHeight)||2.8,2.2,4.5),wallTop=floors*floorHeight+.45;
 const B={x1:-4.5,x2:4.5,y1:-3.3,y2:3.3,z0:.28,h:wallTop};const roofColor=heat?thermalColor(clamp(38+model.roofAbsorbed/model.area*65,5,100)):activeHome().roofCoating?'#e7eee9':profile.roof==='tile'?'#bd7a4a':'#647c85';
 // Landscaped site, driveway, home foundation, ornamental border.
 box(-8,-7.2,-.38,8,7.8,-.10,'#194c41');box(-8,-7.2,-.15,8,7.8,-.08,'#2b6550');
 for(let i=0;i<13;i++){const x=-7.5+i*1.25;path([P(x,-7.2,-.09),P(x,7.8,-.09)],'#356f56',.4)}
 for(let j=0;j<11;j++){const y=-6.9+j*1.37;path([P(-8,y,-.085),P(8,y,-.085)],'#356d55',.4)}
 box(-1.9,-7.2,-.07,2.25,-3.6,.02,'#b9b6a3');for(let j=0;j<7;j++)path([P(-1.9,-7+j*.47,.04),P(2.25,-7+j*.47,.04)],'#9c9c8a',.6);
 box(-5.1,-3.9,.06,5.1,3.8,.29,'#75847c');box(-4.76,-3.55,.27,4.76,3.55,.42,'#bdb9a6');
 // Visualized selected-floor plane, with a heat field only when simulation is running.
 if(cut){const cells=14,rows=10,z=.455+activeFloor*floorHeight,sim=floorSimulation(visualDesign(),profile,activeHome(),activeFloor);for(let i=0;i<cells;i++)for(let j=0;j<rows;j++){
  const x=-4.42+i*8.84/cells,y=-3.18+j*6.36/rows,cx=x+8.84/cells/2,cy=y+6.36/rows/2;let index=sim.heatScore;
  if(simulationActive){for(const o of floorObjects(visualDesign(),activeFloor).filter(o=>o.kind==='ac')){const d=Math.hypot(cx-o.x*4.5,cy-o.y*3.3);index-=Math.exp(-d*d/3.8)*13;}
   for(const o of floorObjects(visualDesign(),activeFloor).filter(o=>o.kind==='fans')){const d=Math.hypot(cx-o.x*4.5,cy-o.y*3.3);index-=Math.exp(-d*d/3)*2.8;}}
  const c=simulationActive&&simulationView!=='wind'?thermalColor(clamp(index,0,100)):'#a6b8a9';
  quad(P(x,y,z),P(x+8.84/cells,y,z),P(x+8.84/cells,y+6.36/rows,z),P(x,y+6.36/rows,z),c,simulationActive?.80:.40);
 }}
 // Architectural shell. Transparent walls in open roof, keeping detail visible.
 const wallAlpha=cut?.19:1,wallColor=heat?'#d7a85d':'#e7e1d2';
 for(let fl=0;fl<floors;fl++){
  const z=.45+fl*floorHeight,h=z+floorHeight;
  box(-4.5,-3.33,z,4.5,3.33,h,wallColor,wallAlpha);
  box(-4.62,-3.44,z-.07,4.62,3.44,z+.05,'#e8e2d4',cut?.12:1);
  const winColor=simulationActive&&simulationView!=='wind'?'#58b3c6':'#5b9dac';
  // User-placed windows and doors appear at their chosen wall and floor.
  for(const o of floorObjects(visualDesign(),fl).filter(o=>['window','door','vent','exhaust','shade','curtain','insulation'].includes(o.kind))){
   const x=clamp(o.x*4.5,-4.08,4.08),y=clamp(o.y*3.3,-2.95,2.95),wall=o.wall||'north';
   const hh=o.kind==='door'?2.0:o.kind==='shade'?.14:o.kind==='vent'||o.kind==='exhaust'?.43:1.17;
   const zz=z+(o.kind==='door'?0:o.kind==='shade'?2.02:o.kind==='vent'||o.kind==='exhaust'?1.87:.85);
   const width=o.kind==='door'?.66:o.kind==='vent'||o.kind==='exhaust'?.40:.62;
   const color=o.kind==='shade'?'#86a07c':o.kind==='insulation'?'#d8dcbe':o.kind==='curtain'?'#c0ad8c':o.kind==='exhaust'?'#8aafb0':o.kind==='door'?'#8b654a':winColor;
   if(wall==='north'||wall==='south'){const yy=wall==='north'?3.37:-3.37;
    quad(P(x-width,yy,zz),P(x+width,yy,zz),P(x+width,yy,zz+hh),P(x-width,yy,zz+hh),color,cut?.66:1);
    path([P(x,yy+(wall==='north'?.013:-.013),zz),P(x,yy+(wall==='north'?.013:-.013),zz+hh)],'#e1ece8',o.kind==='window'?2.6:1.2);
   }else{const xx=wall==='east'?4.56:-4.56;
    quad(P(xx,y-width,zz),P(xx,y+width,zz),P(xx,y+width,zz+hh),P(xx,y-width,zz+hh),color,cut?.66:1);
    path([P(xx,y,zz),P(xx,y,zz+hh)],'#e1ece8',o.kind==='window'?2.5:1.2);
   }
  }

 }
 // Building-type specific architectural detailing (same renderer and saved property).
 if(profile.type==='apartment'||profile.type==='duplex'){
  for(let fl=1;fl<floors;fl++){const bz=.42+fl*floorHeight;
   box(-3.75,-4.17,bz-.12,3.75,-3.28,bz+.03,'#d6d9d1',cut?.18:1);
   for(let bx=-3.55;bx<=3.55;bx+=1.15){path([P(bx,-4.18,bz+.05),P(bx,-4.18,bz+.92)],'#b9d6da',1.4)}
   path([P(-3.7,-4.18,bz+.92),P(3.7,-4.18,bz+.92)],'#b9d6da',2);
  }
 }
 if(profile.type==='shop'){
  quad(P(-3.9,-3.6,.6),P(3.9,-3.6,.6),P(3.9,-3.6,2.6),P(-3.9,-3.6,2.6),'#2a6974',cut?.25:1);
  box(-4.35,-4.05,2.72,4.35,-3.42,3.1,'#177b74',cut?.3:1);
 }
 if(profile.type==='school'){
  box(-3.2,-4.3,.38,3.2,-3.35,.58,'#b5aa91');
  for(const x of [-3.1,3.0])box(x,-4.2,.58,x+.14,-4.06,3.2,'#e7e5d8',cut?.2:1);
 }
 // Entry, porch columns, facade trim and outdoor service unit.
 box(-1.05,-3.53,.42,.6,-3.43,2.65,'#825c41',cut?.38:1);path([P(-.38,-3.56,.54),P(-.38,-3.56,2.54)],'#c49a6a',2);
 circle(.35,-3.57,1.44,.05,'#e4c891');
 box(-1.68,-4.85,2.93,2.2,-3.15,3.19,'#a9ada6',cut?.23:1);
 for(const x of [-1.53,1.99])box(x,-4.7,.25,x+.11,-4.59,3.06,'#f0eadb',cut?.23:1);
 box(-5.1,.6,.2,-4.45,1.66,1.42,'#aab8bd');
 for(let a=0;a<4;a++)path([P(-5.13,.75+a*.18,.4),P(-5.13,1.44,.4+a*.16)],'#5d7278',1);
 // Detailed sloped roof. In cutaway, roof is a faint lifted outline so equipment remains visible.
 const z=wallTop+.12,ridge=z+1.40,eave=z+.02,roofAlpha=cut?.10:1;
 const r1=P(-5,-3.85,eave),r2=P(5,-3.85,eave),r3=P(5,0,ridge),r4=P(-5,0,ridge),r5=P(-5,3.85,eave),r6=P(5,3.85,eave);
 if(profile.roof==='concrete'){
  box(-5.0,-3.82,wallTop+.06,5,3.82,wallTop+.46,roofColor,roofAlpha);
  if(heat&&!cut){for(let i=0;i<14;i++)for(let j=0;j<11;j++){
    const x=-4.93+i*(9.86/14),y=-3.75+j*(7.5/11),index=clamp(32+model.roofAbsorbed/model.area*80+5*Math.sin(i*.52)+7*Math.cos(j*.33)-activeHome().trees*1.5,5,100);
    quad(P(x,y,wallTop+.469),P(x+9.86/14,y,wallTop+.469),P(x+9.86/14,y+7.5/11,wallTop+.469),P(x,y+7.5/11,wallTop+.469),thermalColor(index));
  }}
  for(const x of [-4.95,4.7])box(x,-3.77,wallTop+.46,x+.24,3.8,wallTop+.85,'#e7e9dc',roofAlpha);
  for(const y of [-3.78,3.53])box(-5,y,wallTop+.46,5,y+.22,wallTop+.85,'#e4e9df',roofAlpha);
 }else{
  quad(r1,r2,r3,r4,roofColor,roofAlpha);quad(r4,r3,r6,r5,roofColor,roofAlpha);
  face([r1,r4,r5],wallColor,roofAlpha);face([r2,r6,r3],wallColor,roofAlpha);
  for(let i=1;i<=7;i++){const t=i/8,z0=eave+(ridge-eave)*t;path([P(-4.98,-3.85+3.85*t,z0+.025),P(4.98,-3.85+3.85*t,z0+.025)],activeHome().roofCoating?'#c7d1cf':'#9b5044',cut?.5:1.1);
   path([P(-4.98,3.85-3.85*t,z0+.025),P(4.98,3.85-3.85*t,z0+.025)],activeHome().roofCoating?'#c7d1cf':'#9b5044',cut?.5:1.1)}
  path([r4,r3],'#d6d9c7',3);
 }
 // Solar device on roof only when solar scenario configured elsewhere (not fabricated generation).
 let solar={};try{solar=JSON.parse(localStorage.getItem('us4.calc.solar')||'{}')}catch{};
 if(!cut&&solar.capacity>0){for(let i=0;i<3;i++)for(let j=0;j<2;j++){
  const x=-3.6+i*2.2,y=.3+j*1.55,h=profile.roof==='concrete'?wallTop+.5:ridge-(ridge-eave)*(y/3.85)+.06;
  quad(P(x,y,h),P(x+1.94,y,h),P(x+1.94,y+1.35,h-(profile.roof==='concrete'?.12:.5)),P(x,y+1.35,h-(profile.roof==='concrete'?.12:.5)),'#193c5e',1);
  path([P(x+1,y,h+.015),P(x+1,y+1.3,h-.3)],'#7296b0',1)
 }}
 // Ground plants and trees. Detailed foliage built as staggered canopy clusters.
 const treePts=[[-6.5,-1.3],[-6.7,2.8],[6.45,3.0],[6.5,-.65]];
 for(let t=0;t<clamp(Math.round(home.trees),0,4);t++){const [x,y]=treePts[t];box(x-.15,y-.14,-.05,x+.15,y+.14,2.4,'#745a39');for(let k=0;k<9;k++){const a=k*2.3999;const rr=.7+(k%3)*.27;const cx=x+Math.sin(a)*rr,cy=y+Math.cos(a)*rr;circle(cx,cy,2.55+(k%4)*.24,.6,k%3===0?'#6b9e56':k%3===1?'#397958':'#4b975c')}}
 // Planter edge / landscaping geometry.
 for(const x of [-4,-2.7,3.2,4.05])for(const y of [-5.1,4.9]){box(x-.32,y-.28,-.04,x+.32,y+.28,.22,'#ad977e');circle(x,y,.41,.29,'#5c9560')}
 // Actual furniture and devices are placed on the selected floor, not only at ground level.
 if(cut){const bz=.45+activeFloor*floorHeight,local=floorObjects(visualDesign(),activeFloor);
  // Furnishings keep the original complete-house visual language; layout follows selected level.
  box(-3.6,1.15,bz,-1.25,2.65,bz+.47,'#d5c3ac',.88);box(1.3,-1.95,bz,3.15,-.6,bz+.72,'#668580',.95);
  box(-.2,-.7,bz,.85,.55,bz+.42,'#b89e80',.98);box(-3.7,-2.9,bz,-2.45,-1.55,bz+.65,'#a4b2a5',.95);
  for(const o of local){const x=o.x*4.5,y=o.y*3.3,zz=bz;switch(o.kind){
   case 'ac':box(x-.55,y-.17,zz+1.68,x+.55,y+.17,zz+2.07,'#e7f3ee');path([P(x-.4,y-.19,zz+1.9),P(x+.4,y-.19,zz+1.9)],'#6fafa9',2);break;
   case 'fans':{const h=zz+floorHeight-.36;box(x-.05,y-.05,h-.35,x+.05,y+.05,h,'#d9e0db');for(let i=0;i<3;i++){const a=i*2.094+frame*.045;path([P(x,y,h-.38),P(x+Math.cos(a)*.65/dimensions.sx,y+Math.sin(a)*.65/dimensions.sy,h-.38)],'#bfe3df',5)}break;}
   case 'lights':circle(x,y,zz+floorHeight-.12,.16,'#ffedac');break;
   case 'fridge':box(x-.34,y-.35,zz,x+.34,y+.35,zz+1.7,'#eaf3ed');path([P(x-.31,y-.37,zz+.88),P(x+.31,y-.37,zz+.88)],'#74918e',2);break;
   case 'cooler':box(x-.34,y-.29,zz,x+.34,y+.29,zz+.83,'#9ed4dd');break;
   case 'heater':box(x-.35,y-.16,zz,x+.35,y+.16,zz+.65,'#a86852');break;
   case 'bed':box(x-.95,y-.58,zz,x+.95,y+.58,zz+.48,'#d2bba6');break;
   case 'sofa':box(x-.8,y-.4,zz,x+.8,y+.40,zz+.76,'#638f8b');break;
   case 'desk':box(x-.66,y-.38,zz+.52,x+.66,y+.38,zz+.64,'#b69b7b');break;
   case 'counter':box(x-.9,y-.28,zz,x+.9,y+.28,zz+.9,'#b7bbb1');break;
   case 'solar':if(activeFloor===floorCount()-1)box(x-.7,y-.6,wallTop+.51,x+.7,y+.6,wallTop+.56,'#274f72');break;
   case 'tree':{const tx=x*1.3,ty=y*1.3;box(tx-.10,ty-.10,-.05,tx+.10,ty+.10,2.3,'#765b38');circle(tx,ty,2.65,.72,'#4c9865');break;}
   default:break;
  }
  if(simulationActive&&['ac','fans','cooler','heater','exhaust'].includes(o.kind))label(x,y,zz+2.45,KINDS[o.kind].name.toUpperCase(),'','#a5f5e1');
  }
  label(-4.3,3.15,bz+1.2,`FLOOR ${activeFloor+1}`,`${local.length} objects`,'#e5ffbe');
 }
 // Meter and energy wiring. Routes depict conceptual household distribution, not the exact wiring.
 if(isFlow){const meter=P(-4.83,-3.52,.45+activeFloor*floorHeight+1.05);circle(...meter,.2,'#f8ed92');label(-5.4,-3.4,2.1,'GRID METER','assumed source','#fff1a0');
   for(const [x,y] of [...positions.ac,...positions.fans])path([meter,P(-4.3,-2.86,1.3),P(x,y,.9)],'#96f7e3',2,[8,6]);
   for(const [x,y] of positions.fridge)path([meter,P(x,y,1.5)],'#fce79b',3,[7,6]);for(const [x,y] of positions.lights)path([meter,P(x,y,2.3)],'#ffe59f',1.4,[3,4]);
 }
 // In thermal mode, add sensor-style legend anchors around house.
 if(simulationActive&&heat){label(-4.45,3.6,wallTop+.72,'ROOF HEAT','solar absorption','#ffc789');label(3.4,2.4,.75+activeFloor*floorHeight,'INDOOR','modeled index','#87edff')}
 return model;
}
function render(){if(!canvas.isConnected)return;const rect=canvas.getBoundingClientRect(),w=Math.max(100,rect.width),h=Math.max(100,rect.height),pixelRatio=Math.min(2,window.devicePixelRatio||1);
 const rw=Math.round(w*pixelRatio),rh=Math.round(h*pixelRatio);if(canvas.width!==rw||canvas.height!==rh){canvas.width=rw;canvas.height=rh}ctx.setTransform(pixelRatio,0,0,pixelRatio,0,0);const size=roomSize(profile);dimensions={sx:size.length/9,sy:size.width/6.6};
 if(indoor){
  const indoorProps={profile,position:indoorPosition,heading:indoorHeading,look:indoorLook,fov:indoorFov,energy:floorEnergy(design,activeFloor,energy),positions:placementArrays(design,activeFloor),openings:floorObjects(visualDesign(),activeFloor).filter(o=>['window','door','vent','exhaust','curtain'].includes(o.kind)),objects:floorObjects(visualDesign(),activeFloor),floor:activeFloor,mode:viewMode(),home:activeHome(),heatIndex:floorSimulation(visualDesign(),profile,activeHome(),activeFloor).heatScore,walking,frame};
  if(immersive.available){immersive.refresh(indoorProps)}
  else drawIndoor(ctx,w,h,indoorProps);
  return;
 }
 camera=setCamera(w,h);
 const sky=ctx.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#112d3b');sky.addColorStop(.57,'#1c3d49');sky.addColorStop(1,'#0f2528');ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
 // Atmospheric radial glow and subtle horizon grid.
 const glow=ctx.createRadialGradient(w*.49,h*.28,10,w*.48,h*.48,w*.6);glow.addColorStop(0,'rgba(58,135,136,.23)');glow.addColorStop(1,'rgba(9,18,28,0)');ctx.fillStyle=glow;ctx.fillRect(0,0,w,h);
 buildHouse();faces.sort((a,b)=>b.depth-a.depth);
 for(const f of faces){const pts=f.pts.map(proj);if(pts.some(p=>p[2]<=.1))continue;ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.closePath();ctx.globalAlpha=f.alpha;ctx.fillStyle=f.color;ctx.fill();if(f.outline){ctx.strokeStyle=f.outline;ctx.lineWidth=.6;ctx.stroke()}}
 ctx.globalAlpha=1;
 // 3D lines and labels above geometry to keep controls legible at any angle.
 for(const item of stickers.filter(p=>p.type==='path')){const pts=item.pts.map(proj);if(pts.some(p=>p[2]<=.1))continue;ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.strokeStyle=item.color;ctx.lineWidth=item.width;ctx.setLineDash(item.dash||[]);ctx.lineCap='round';ctx.stroke();ctx.setLineDash([])}
 for(const item of stickers.filter(p=>p.type==='circle')){const [x,y,z]=proj(item.pos);if(z<=0||![x,y,z,item.r].every(Number.isFinite))continue;const r=clamp(item.r*camera.focal/z,2,50);if(!Number.isFinite(r))continue;const g=ctx.createRadialGradient(x-r*.3,y-r*.4,r*.1,x,y,r);g.addColorStop(0,'#d2e5a9');g.addColorStop(.4,item.color);g.addColorStop(1,'#215845');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()}
 for(const item of stickers.filter(p=>p.type==='label')){const [x,y,z]=proj(item.pos);if(z<=0||x<-30||x>w+40||y<-10||y>h+20)continue;ctx.font='700 10px system-ui';const tw=ctx.measureText(item.title).width;ctx.fillStyle='rgba(7,29,34,.84)';ctx.beginPath();ctx.roundRect(x-tw/2-9,y-15,tw+18,23,7);ctx.fill();ctx.fillStyle=item.color;ctx.textAlign='center';ctx.fillText(item.title,x,y);ctx.textAlign='start'}
 // Five-metre metric scale marker, projected at the near edge of the actual plot.
 const scaleSize=roomSize(profile),y=scaleSize.width/2+1,x=-Math.min(scaleSize.length/2,4.5),left=proj([x,y,.30]),right=proj([x+Math.min(5,scaleSize.length),y,.30]);
 if(left[2]>.1&&right[2]>.1){ctx.strokeStyle='#c8fb94';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(left[0],left[1]);ctx.lineTo(right[0],right[1]);ctx.stroke();ctx.fillStyle='#e1ffda';ctx.font='bold 12px system-ui';ctx.fillText(`${Math.min(5,scaleSize.length)} m scale`,(left[0]+right[0])/2-26,Math.min(h-23,(left[1]+right[1])/2-9))}
 if(simulationActive&&!indoor){if(simulationView!=='heat')drawWindStreams(w,h);if(simulationView!=='wind')drawHeatRays(w,h)}
 if(!home.cutaway){ctx.fillStyle='rgba(234,251,245,.65)';ctx.font='600 11px system-ui';ctx.fillText('Select Open roof to arrange appliances inside',16,h-60)}
}
let needsRender=true;function requestDraw(){needsRender=true}
function tick(now=performance.now()){if(!canvas.isConnected){cancelAnimationFrame(anim);return}const dt=clamp((now-(lastTick||now))/1000,0,.065);lastTick=now;frame++;
 if(indoor){const forward=(activeKeys.has('w')||activeKeys.has('arrowup')||touchWalk==='forward'?1:0)-(activeKeys.has('s')||activeKeys.has('arrowdown')||touchWalk==='backward'?1:0);
 const sideways=(activeKeys.has('d')||touchWalk==='right'?1:0)-(activeKeys.has('a')||touchWalk==='left'?1:0);
 const turning=(activeKeys.has('arrowright')||touchWalk==='turn-right'?1:0)-(activeKeys.has('arrowleft')||touchWalk==='turn-left'?1:0);
 if(turning)indoorHeading+=turning*dt*1.7;
 walking=Boolean(forward||sideways);
 if(walking){const speed=(activeKeys.has('shift')?3.5:2.2)*dt;indoorPosition=walkStep(indoorPosition,indoorHeading,forward*speed,sideways*speed,profile);needsRender=true}
 if(turning||walking)needsRender=true;button('#cg-avatar').classList.toggle('walking',walking);const posText=`Position ${fmt(indoorPosition.x)} m × ${fmt(indoorPosition.y)} m`;if(button('#cg-indoor-location').textContent!==posText)button('#cg-indoor-location').textContent=posText;
 }
 if(needsRender||indoor&&walking||(simulationActive&&frame%3===0)){render();needsRender=false}anim=requestAnimationFrame(tick)}
function updateUI(){const model=getModel(),breakdown=energyBreakdown(energy),perFloor=floorEnergy(design,activeFloor,energy),sim=floorSimulation(visualDesign(),profile,activeHome(),activeFloor);
 for(const [id,value] of [['ambient',home.ambient],['solar',home.irradiance],['shade',home.shade]]){button(`#cg-${id}`).value=value;button(`#cg-${id}-label`).textContent=id==='shade'?`${value}%`:id==='solar'?`${value} W/m²`:`${value}°C`}
 button('#cg-house-type').value=['bungalow','duplex','apartment','sloped','school','shop'].includes(profile.type)?profile.type:'bungalow';button('#cg-floors').value=profile.floors||1;button('#cg-length').value=profile.length||12;button('#cg-width').value=profile.width||9;button('#cg-ceiling').value=profile.ceilingHeight||2.8;
 button('#cg-coat').checked=Boolean(home.roofCoating);button('#cg-insulate').checked=Boolean(home.roofInsulation);
 button('#cg-weather-source').textContent=home.dataSource||'Current inputs are manually assumed; no live measurement is inferred.';
 for(const [id,key] of [['ac','acCount'],['fan','fanCount'],['light','lightsCount'],['fridge','fridgeCount']])button(`#cg-${id}-count`).textContent=perFloor[key];
 button('#cg-ac-sub').textContent=`${fmt(breakdown.loads.ac)} kWh/month`;
 button('#cg-fan-sub').textContent=`${fmt(breakdown.loads.fans)} kWh/month`;
 button('#cg-light-sub').textContent=`${fmt(breakdown.loads.lights)} kWh/month`;
 button('#cg-fridge-sub').textContent=`${fmt(breakdown.loads.fridge)} kWh/month`;
 button('#cg-temp').textContent=fmt(model.roofAbsorbed)+' kW';button('#cg-index').textContent=sim.heatScore+'/100';button('#cg-kwh').textContent=fmt(breakdown.total)+' kWh';button('#cg-relief').textContent=String(sim.fans);
 updateFloorSelectors();button('#cg-stage-house').textContent=(beforeMode?'ORIGINAL · ':'DESIGN · ')+`${profile.name||'House'} · Floor ${activeFloor+1}/${floorCount()} · ${profile.length||12} × ${profile.width||9} × ${profile.ceilingHeight||2.8} m`;button('#cg-indoor').setAttribute('aria-pressed',String(indoor));button('#cg-indoor-pad').hidden=!indoor;button('#cg-avatar').hidden=!indoor;button('#cg-mobile-movement').hidden=!indoor;button('#cg-roof').disabled=indoor;button('#cg-hints').hidden=indoor;
 const mode=viewMode();button('#cg-stage-mode').textContent=indoor?(immersive.available?'IMMERSIVE WEBGL 3D · 1:1 METRIC SCALE':'INDOOR WALKTHROUGH · COMPATIBILITY MODE'):mode==='thermal'?'ILLUSTRATIVE THERMAL LAYER':mode==='energy'?'ASSUMED HOUSEHOLD ENERGY FLOW':'ARCHITECTURAL MODEL · VISUAL REFERENCE';
 updateJudgeSummary();host.querySelectorAll('[data-mode]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.mode===mode)));
 button('#cg-simulation-explain').hidden=!simulationActive;button('#cg-main-metrics').hidden=!simulationActive;button('#cg-heat-legend').hidden=!simulationActive||simulationView==='wind';button('#cg-indoor-floor-label').textContent=activeFloor===0?'Ground floor':`Floor ${activeFloor+1}`;button('#cg-floor-up').disabled=activeFloor>=floorCount()-1;button('#cg-floor-down').disabled=activeFloor<=0;button('#cg-start-simulation').hidden=simulationActive;button('#cg-stop-simulation').hidden=!simulationActive;button('#cg-simulation-panel').hidden=!simulationActive;button('#cg-sim-heat').textContent=sim.heatScore+'/100';button('#cg-sim-wind').textContent=sim.airflowIndex+'/100';button('#cg-sim-cross').textContent=sim.crossFlow?'Potential':'Limited';button('#cg-sim-roof').textContent=fmt(sim.roofAbsorbedKw)+' kW';button('#cg-sim-explanation').textContent=`${sim.openings} open vents/windows/doors on this floor; ${sim.inlet} windward and ${sim.outlet} leeward. ${sim.qualifier}. Fans can change perceived comfort but not dry-bulb air temperature.`;button('#cg-wind-speed-out').textContent=fmt(design.windSpeed)+' m/s';renderObjectList();button('#cg-roof').textContent=home.cutaway?'Close roof':'Open roof';button('#cg-roof').setAttribute('aria-pressed',String(home.cutaway));
 for(const k of Object.keys(placementKeys))button(`#cg-place-${k==='fans'?'fan':k}`).setAttribute('aria-pressed',String(placeTool===k));button('#cg-drop').disabled=!placeTool;
 button('#cg-explain-text').innerHTML=`<b>Why did the display change?</b> Assumed outdoor air ${fmt(model.ambient,0)}°C and solar irradiance ${fmt(model.irr,0)} W/m² affect the roof absorption estimate (${fmt(model.roofAbsorbed)} kW). The selected floor has ${sim.ac} AC(s) and ${sim.fans} fan(s); these change the relative comfort-risk score using a deliberately simplified screening method. <b>No indoor temperature decrease, verified electricity saving or engineered airflow is predicted.</b>`;
 requestDraw();}

function updateJudgeSummary(){
 const plan=getCoolingPlan();const issues=coolingPlanIssues(plan,profile);
 const brief=button('#cg-plan-brief');const apply=button('#cg-apply-plan');
 if(plan){brief.textContent=`Saved Cooling Plan: ${plan.steps.length} recommended action(s), ₹${Math.round(plan.spent).toLocaleString('en-IN')} estimated allowance against ₹${Math.round(plan.budget).toLocaleString('en-IN')} budget. ${issues.length?issues.join(' '):'Property dimensions and city match.'}`;apply.disabled=false;}
 else{brief.textContent='No submitted Cooling Plan on this browser. Complete the Cooling Planner first, or use the guided setup.';apply.disabled=true;}
 const result=compareScenarios(design,profile,home,energy,plan);const selected=result.floorRows[Math.min(activeFloor,result.floorRows.length-1)];
 const money=n=>'₹'+Math.round(n).toLocaleString('en-IN');
 const signed=n=>n>0?`−${n} points`:n<0?`+${Math.abs(n)} points`:'No modelled change';
 button('#cg-comparison').innerHTML=`<h3>Before vs After · same model, same camera</h3><p class="cg-fine">Toggle Original / Improved above. Baseline removes proposed upgrades but keeps existing appliances and opening positions. These indices are illustrative, not measured °C.</p><div class="usjudge-tablewrap"><table class="usjudge-table"><thead><tr><th>Measure</th><th>Original</th><th>Improved</th></tr></thead><tbody><tr><th>Building-wide heat/comfort risk</th><td>${result.originalRisk}/100</td><td>${result.improvedRisk}/100 (${signed(result.riskChange)})</td></tr><tr><th>Floor ${activeFloor+1} heat/comfort risk</th><td>${selected.baseline.heatScore}/100</td><td>${selected.improved.heatScore}/100</td></tr><tr><th>Floor ${activeFloor+1} airflow opportunity</th><td>${selected.baseline.airflowIndex}/100</td><td>${selected.improved.airflowIndex}/100</td></tr><tr><th>Roof solar energy absorbed *</th><td>${fmt(result.originalRoof)} kW</td><td>${fmt(result.improvedRoof)} kW</td></tr><tr><th>Monthly appliance use (all floors) *</th><td colspan="2">${fmt(result.electricity)} kWh with current appliance inventory; no modeled savings attributed to roof treatments</td></tr><tr><th>Cooling plan budget / allowance *</th><td>${money(result.budget||0)} budget</td><td>${result.planCost!=null?money(result.planCost)+' estimated allocation':'No submitted plan'}</td></tr></tbody></table></div><p class="cg-fine">Selected upgrades: ${safe(result.activeMeasures.join(', ')||'No additional upgrades')}. * Screening assumptions, not an invoice, meter reading or indoor temperature prediction.</p>`;
}
button('#cg-apply-plan').onclick=()=>{
 const plan=getCoolingPlan();if(!plan)return;const issues=coolingPlanIssues(plan,profile);
 if(issues.length&&!confirm(issues.join(' ')+' Apply only the recommendations you have selected in that plan?'))return;
 const result=applyCoolingPlan(plan,design,profile,home);
 if(!result.applied.length){button('#cg-plan-message').textContent='This plan contains advisory actions only. There are no directly modelable upgrades to apply; use manual editing as appropriate.';return;}
 home=saveHome(result.home);beforeMode=false;persistDesign(result.design);
 button('#cg-plan-message').textContent='Applied: '+result.applied.join(', ')+'. '+(result.advisory.join(' ')||'Compare Original and Improved, then Start Simulation.');
};
button('#cg-demo').onclick=()=>{
 if(design.objects.length&&!confirm('Replace the current 3D layout with a labeled example? Save a scenario first if you want to keep these objects.'))return;
 const example={floors:Math.max(2,floorCount()),windows:3,windowWall:'opposite',openWindows:'open',vents:true,exhaust:false,ac:2,fans:4,lights:6,fridge:1,roofShade:false,insulation:false,solar:false};
 profile=saveProfile({name:'Example duplex (demonstration)',type:'duplex',floors:2,length:12,width:9,ceilingHeight:2.9,city:'Pune',roof:'concrete'});
 home=saveHome({ambient:34,irradiance:800,roofCoating:false,roofInsulation:false,shade:15,cutaway:true});
 persistDesign(autoLayout({...example,floors:2},profile,energy));dist=fitDistance();beforeMode=false;simulationActive=false;
 button('#cg-guide-status').textContent='Example loaded. This is demonstration data, not a measured property. Choose upgrades, then press Start Simulation.';
};
// Per-floor menu is shared by overhead placement and first-person movement.
let lastFloorOptions='';function updateFloorSelectors(){const html=Array.from({length:floorCount()},(_,i)=>`<option value="${i}">${i===0?'Ground floor':`Floor ${i+1}`}</option>`).join('');const select=button('#cg-active-floor');if(html!==lastFloorOptions){select.innerHTML=html;lastFloorOptions=html}select.value=String(activeFloor)}
function renderObjectList(){const list=floorObjects(design,activeFloor);button('#cg-objects-list').innerHTML=list.length?`<div class="cg-object-list-head">Floor ${activeFloor+1} · ${list.length} objects</div>`+list.map(o=>`<div class="cg-object-row"><span>${safe(KINDS[o.kind]?.name||o.kind)}${KINDS[o.kind]?.wall?' · '+safe(o.wall):''}</span><button type="button" data-delete-object="${safe(o.id)}" aria-label="Remove ${safe(KINDS[o.kind]?.name)}">×</button></div>`).join(''):'<p class="cg-fine">No objects on this floor. Generate a layout or add objects manually.</p>';}
function drawWindStreams(w,h){const sim=floorSimulation(design,profile,activeHome(),activeFloor),dir={north:[0,-1],south:[0,1],east:[-1,0],west:[1,0]}[design.windFrom]||[1,0];
 const floorZ=.45+activeFloor*(Number(profile.ceilingHeight)||2.8);const strength=clamp(Number(design.windSpeed)||0,0,12)/12;
 if(strength===0)return;
 ctx.save();ctx.lineWidth=2.2;ctx.lineCap='round';
 for(let s=0;s<Math.max(6,sim.inlet*5);s++){
  const phase=(frame*.017*(.25+strength)+s*.149)%1;
  let side=(s%6-2.5)*.66;
  // Without facing openings, show the wind travelling outside the building rather than through it.
  if(!sim.inlet)side+=side>0?5:-5;
  let travel=sim.crossFlow?12.5:sim.inlet?7.1:9.1;
  const c=[-dir[0]*5.85+dir[1]*side,-dir[1]*4.8-dir[0]*side];
  const a=P(c[0]+dir[0]*phase*travel,c[1]+dir[1]*phase*travel,floorZ+.61+(s%4)*.27);
  const b=P(a[0]-dir[0]*(.48+strength*.65),a[1]-dir[1]*(.48+strength*.65),a[2]);
  const pa=proj(physical(a)),pb=proj(physical(b));if(pa[2]>.1&&pb[2]>.1){ctx.strokeStyle=`rgba(71,227,255,${(.30+.59*strength).toFixed(2)})`;ctx.beginPath();ctx.moveTo(pb[0],pb[1]);ctx.lineTo(pa[0],pa[1]);ctx.stroke();ctx.fillStyle='#c3fbff';ctx.beginPath();ctx.arc(pa[0],pa[1],1.9,0,Math.PI*2);ctx.fill()}
 }
 ctx.restore();}
function drawHeatRays(w,h){const solar=Number(home.irradiance)||0;if(solar<5)return;
 const ceiling=Number(profile.ceilingHeight)||2.8,top=.45+floorCount()*ceiling,alpha=Math.min(.74,Math.max(.15,solar/1150));
 ctx.save();ctx.lineWidth=2.2;
 for(let i=0;i<13;i++){const x=(i%5-2)*1.62,y=(Math.floor(i/5)-1)*1.45,progress=(frame*.012+i*.33)%1,z=top+2.1-progress*2.0;
  const a=proj(physical(P(x,y,z))),b=proj(physical(P(x,y,z+.42)));
  if(a[2]>.1&&b[2]>.1){ctx.strokeStyle=`rgba(255,168,82,${alpha.toFixed(2)})`;ctx.beginPath();ctx.moveTo(b[0],b[1]);ctx.lineTo(a[0],a[1]);ctx.stroke()}
 }
 ctx.restore()}
// Guided setup intentionally requires an explicit click so it never destroys a manually designed floor.
let wizardStep=0;const wizardNodes=[...host.querySelectorAll('.cg-wizard-step')];
function showWizard(){wizardNodes.forEach((el,i)=>el.hidden=i!==wizardStep);button('#cg-wizard-progress').textContent=`Step ${wizardStep+1} / 3`;button('#cg-wizard-back').disabled=wizardStep===0;button('#cg-wizard-next').hidden=wizardStep===2;button('#cg-generate').hidden=wizardStep!==2;}
button('#cg-wizard-back').onclick=()=>{wizardStep=Math.max(0,wizardStep-1);showWizard()};button('#cg-wizard-next').onclick=()=>{wizardStep=Math.min(2,wizardStep+1);showWizard()};
button('#cg-windows').value=guidedDefault.windows??2;button('#cg-window-wall').value=guidedDefault.windowWall||profile.windowSide||profile.orientation||'opposite';if(![...button('#cg-window-wall').options].some(o=>o.value===button('#cg-window-wall').value))button('#cg-window-wall').value='opposite';
button('#cg-windows-open').checked=guidedDefault.openWindows!=='closed';button('#cg-vent-included').checked=guidedDefault.vents!==false;
button('#cg-exhaust-included').checked=Boolean(guidedDefault.exhaust);button('#cg-guide-shade').checked=Boolean(guidedDefault.roofShade);button('#cg-guide-insulation').checked=Boolean(guidedDefault.insulation||home.roofInsulation);button('#cg-guide-solar').checked=Boolean(guidedDefault.solar);
for(const [key,label] of [['ac','acCount'],['fans','fanCount'],['lights','lightsCount'],['fridge','fridgeCount']])button('#cg-guide-'+key).value=guidedDefault[key]??energy[label];
button('#cg-generate').onclick=()=>{if(design.hasGuided && design.objects.length && !confirm('Generate a fresh layout? This replaces objects on all floors.'))return;
 const answers={floors:floorCount(),windows:Number(button('#cg-windows').value),windowWall:button('#cg-window-wall').value,openWindows:button('#cg-windows-open').checked?'open':'closed',vents:button('#cg-vent-included').checked,exhaust:button('#cg-exhaust-included').checked,roofShade:button('#cg-guide-shade').checked,insulation:button('#cg-guide-insulation').checked,solar:button('#cg-guide-solar').checked};for(const k of ['ac','fans','lights','fridge'])answers[k]=Number(button('#cg-guide-'+k).value)||0;
 home=saveHome({roofInsulation:answers.insulation,shade:answers.roofShade?Math.max(35,Number(home.shade)||15):home.shade});profile=saveProfile({...profile,windowSide:answers.windowWall,ventilation:answers.vents?'good':'average'});
 persistDesign(autoLayout(answers,profile,energy));button('#cg-guide-status').textContent=`Generated ${floorCount()} floor(s), including windows and equipment. Select a floor to refine it manually.`;
};showWizard();
const groups=[...new Set(Object.values(KINDS).map(x=>x.group))];button('#cg-object-category').innerHTML=groups.map(g=>`<option>${safe(g)}</option>`).join('');
function renderToolOptions(){const group=button('#cg-object-category').value,opts=Object.entries(KINDS).filter(([,v])=>v.group===group);button('#cg-object-type').innerHTML=opts.map(([k,v])=>`<option value="${k}">${safe(v.name)}</option>`).join('');updateWallVisible()}
function updateWallVisible(){button('#cg-wall-wrap').hidden=!KINDS[button('#cg-object-type').value]?.wall}
button('#cg-object-category').onchange=renderToolOptions;button('#cg-object-type').onchange=updateWallVisible;renderToolOptions();
button('#cg-arm-object').onclick=()=>{const kind=button('#cg-object-type').value;placeTool=placeTool===kind?'':kind;if(!home.cutaway)home=saveHome({cutaway:true});button('#cg-arm-object').textContent=placeTool?'Tap model to place '+KINDS[placeTool].name:'Place on model';updateUI()};
button('#cg-add-center').onclick=()=>placeAtCanonical(button('#cg-object-type').value,[0,0]);
button('#cg-delete-last').onclick=()=>{const list=floorObjects(design,activeFloor);if(!list.length)return;persistDesign({...design,objects:design.objects.filter(o=>o.id!==list.at(-1).id)})};
button('#cg-objects-list').onclick=e=>{const id=e.target.closest('[data-delete-object]')?.dataset.deleteObject;if(id)persistDesign({...design,objects:design.objects.filter(o=>o.id!==id)})};
button('#cg-active-floor').onchange=e=>onFloorChange(Number(e.target.value));button('#cg-floor-up').onclick=()=>onFloorChange(activeFloor+1);button('#cg-floor-down').onclick=()=>onFloorChange(activeFloor-1);
button('#cg-start-simulation').onclick=()=>{simulationActive=true;simulationView='both';home=saveHome({cutaway:true});updateUI()};button('#cg-stop-simulation').onclick=()=>{simulationActive=false;updateUI()};
button('#cg-wind-from').value=design.windFrom;button('#cg-wind-speed').value=design.windSpeed;
button('#cg-wind-from').onchange=e=>persistDesign({...design,windFrom:e.target.value},false);button('#cg-wind-speed').oninput=e=>persistDesign({...design,windSpeed:Number(e.target.value)},false);button('#cg-sim-overlay').onchange=e=>{simulationView=e.target.value;updateUI()};

for(const id of ['ambient','solar','shade'])button(`#cg-${id}`).addEventListener('input',e=>{home=saveHome({...home,[id==='ambient'?'ambient':id==='solar'?'irradiance':'shade']:Number(e.target.value),dataSource:'Manual input'});updateUI()});
button('#cg-city-weather').onclick=async()=>{
 const btn=button('#cg-city-weather');btn.disabled=true;button('#cg-weather-source').textContent='Looking up the selected city and requesting weather observations / model data…';
 try{
   let lat=Number(profile.lat),lon=Number(profile.lon);
   if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)<.001){const found=await searchCity(profile.city||'Pune');lat=found.lat;lon=found.lon;profile=saveProfile({...profile,lat,lon});}
   const result=await currentWeather([{id:'property',lat,lon,name:profile.city||'Property'}]);const rec=result.values?.property;
   if(!Number.isFinite(rec?.temp))throw Error('Temperature data unavailable');
   const next={ambient:clamp(Math.round(rec.temp),18,45)};let source=`${rec.source}: ${rec.time||'time unavailable'}${rec.stale?' (stale/cached)':''}. Outdoor 2m air temperature; not indoor.`;
   const hour=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',hour:'2-digit',hourCycle:'h23'}).format(new Date()));
   try{const solar=await shortwaveAt({lat,lon,date:todayIndia(),hour});next.irradiance=clamp(Math.round(solar.watts/25)*25,0,1100);source+=` Solar input: ${solar.source}, ${solar.time} (modelled).`}
   catch{source+=' Solar irradiance remains your previous assumption (provider unavailable).'}
   next.dataSource=source;home=saveHome(next);updateUI();
 }catch(err){button('#cg-weather-source').textContent=`Local weather unavailable (${String(err.message).slice(0,140)}). Existing assumptions retained.`;}
 finally{btn.disabled=false}
};
for(const [id,key] of [['cg-house-type','type'],['cg-floors','floors'],['cg-length','length'],['cg-width','width'],['cg-ceiling','ceilingHeight']])button('#'+id).addEventListener('change',e=>{const v=key==='type'?e.target.value:Number(e.target.value);const next={[key]:v};if(['length','width','floors','type'].includes(key)){const lengthAmount=key==='length'?v:Number(profile.length)||12;const widthAmount=key==='width'?v:Number(profile.width)||9;next.areaSqFt=Math.round(lengthAmount*widthAmount*10.7639)}if(key==='type'){next.floors=v==='apartment'?4:v==='duplex'?2:1;if(v==='sloped')next.roof='tile';else if(profile.roof==='tile')next.roof='concrete';}profile=saveProfile(next);if(key==='type'||key==='floors'){activeFloor=Math.min(activeFloor,floorCount()-1);design=saveDesign({...design,selectedFloor:activeFloor,objects:design.objects.map(o=>o.floor>=floorCount()?{...o,floor:floorCount()-1}:o)});syncPositions()}if(key==='length'||key==='width'){dist=fitDistance();const bounds=walkBounds(profile);indoorPosition={x:clamp(indoorPosition.x,bounds.xmin,bounds.xmax),y:clamp(indoorPosition.y,bounds.ymin,bounds.ymax)}}beforeMode=false;updateUI()});
button('#cg-before').onclick=()=>{beforeMode=true;button('#cg-compare-status').textContent='ORIGINAL: improvement choices temporarily hidden; saved improvements unchanged.';updateUI()};
button('#cg-after').onclick=()=>{beforeMode=false;button('#cg-compare-status').textContent='IMPROVED: your selected roof and shading measures are displayed.';updateUI()};
for(const [id,key] of [['coat','roofCoating'],['insulate','roofInsulation']])button(`#cg-${id}`).addEventListener('change',e=>{home=saveHome({[key]:e.target.checked});updateUI()});
for(const buttonEl of host.querySelectorAll('[data-inc]'))buttonEl.addEventListener('click',()=>{const key=buttonEl.dataset.inc,kind=Object.entries(KINDS).find(([,v])=>v.energy===key)?.[0],step=Number(buttonEl.dataset.step);if(!kind)return;
 const list=floorObjects(design,activeFloor).filter(o=>o.kind===kind),items=[...design.objects];if(step>0)items.push(makeObject(kind,activeFloor,Math.random()*.8-.4,Math.random()*.7-.35));else if(list.length){const ix=items.findIndex(o=>o.id===list.at(-1).id);if(ix>=0)items.splice(ix,1)}persistDesign({...design,objects:items});});
for(const buttonEl of host.querySelectorAll('[data-mode]'))buttonEl.addEventListener('click',()=>{simulationView=buttonEl.dataset.mode==='realistic'?'wind':buttonEl.dataset.mode==='energy'?'wind':'heat';simulationActive=buttonEl.dataset.mode!=='realistic';updateUI()});
button('#cg-roof').onclick=()=>{home=saveHome({cutaway:!home.cutaway});updateUI()};
button('#cg-default').onclick=()=>{yaw=.76;pitch=.57;dist=fitDistance();indoor=false;indoorPosition={x:0,y:0};indoorHeading=0;placeTool='';updateUI()};
button('#cg-reset').onclick=()=>{if(!confirm('Reset your environmental improvement assumptions? Manual room objects will be kept.'))return;home=saveHome({ambient:34,irradiance:800,roofCoating:false,roofInsulation:false,shade:15,cutaway:true,thermal:true});simulationActive=false;placeTool='';updateUI()};
button('#cg-save').onclick=()=>{const model=getModel();const ok=saveScenario({property:profile,scenarioType:'house-climate',appliances:energy,conditions:home,positions:JSON.parse(JSON.stringify(positions)),design:JSON.parse(JSON.stringify(design)),heatIndex:model.heatIndex,notes:'Illustrative model, not measured thermal data'});button('#cg-saved').textContent=ok?'Scenario saved in My Projects on this browser. Appliance values also sync to Energy & Savings.':'Unable to save; browser storage may be disabled.'};
for(const [id,key] of [['#cg-place-ac','ac'],['#cg-place-fan','fans'],['#cg-place-lights','lights'],['#cg-place-fridge','fridge']])button(id).onclick=()=>{placeTool=placeTool===key?'':key;if(!home.cutaway)home=saveHome({cutaway:true});updateUI()};
function placeAtCanonical(tool,loc){if(!tool||!KINDS[tool])return;
 const wall=button('#cg-object-wall').value;const x=clamp(loc[0]/4.5,-.86,.86),y=clamp(loc[1]/3.3,-.86,.86);
 const wallObj=KINDS[tool].wall,placed=makeObject(tool,activeFloor,wallObj?(wall==='east'?.87:wall==='west'?-.87:x):x,wallObj?(wall==='north'?.87:wall==='south'?-.87:y):y,wall);
 persistDesign({...design,objects:[...design.objects,placed].slice(-450)});
 button('#cg-placement-feedback').textContent=`${KINDS[tool].name} added on floor ${activeFloor+1}. This floor now has ${floorObjects(design,activeFloor).length} objects.`;
}
function placeIndoor(xOffset=0,distance=1.8){if(!placeTool){button('#cg-placement-feedback').textContent='Choose an object in the Manual building editor first.';return}const angle=indoorHeading+xOffset,location=placementInFront(indoorPosition,angle,profile,distance);placeAtCanonical(placeTool,[location.x/dimensions.sx,location.y/dimensions.sy])}
function setIndoor(value){indoor=Boolean(value);if(indoor&&!indoorEntered){indoorPosition={x:0,y:-roomSize(profile).width/2+1.15};indoorHeading=0;indoorEntered=true}activeKeys.clear();touchWalk='';walking=false;drag=null;pointers.clear();if(indoor){const b=walkBounds(profile);indoorPosition={x:clamp(indoorPosition.x,b.xmin,b.xmax),y:clamp(indoorPosition.y,b.ymin,b.ymax)};placeTool=placeTool||'';if(immersive.available)immersive.canvas.focus({preventScroll:true});else canvas.focus({preventScroll:true})}immersive.show(indoor);updateUI();}
button('#cg-indoor').onclick=()=>setIndoor(!indoor);button('#cg-exit-indoor').onclick=()=>setIndoor(false);
function zoom(dir){if(indoor){indoorFov=clamp(indoorFov-dir*.12,.60,1.60)}else{dist=clamp(dist*(dir>0?.86:1.16),Math.max(6,fitDistance()*.35),fitDistance()*2.7)}requestDraw()}
button('#cg-zoom-in').onclick=()=>zoom(1);button('#cg-zoom-out').onclick=()=>zoom(-1);
button('#cg-drop').onclick=()=>placeIndoor();button('#cg-drop-mobile').onclick=()=>placeIndoor();
for(const el of host.querySelectorAll('[data-walk]')){
 el.addEventListener('pointerdown',e=>{e.preventDefault();touchWalk=el.dataset.walk;el.setPointerCapture(e.pointerId);requestDraw()});
 for(const event of ['pointerup','pointercancel','lostpointercapture'])el.addEventListener(event,()=>{touchWalk='';requestDraw()});
}
function localScreen(e){const rect=canvas.getBoundingClientRect();return {x:e.clientX-rect.left,y:e.clientY-rect.top,w:rect.width,h:rect.height}}
canvas.addEventListener('pointerdown',e=>{pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(pointers.size===2){const pts=[...pointers.values()];pinchStart={length:Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y),dist,fov:indoorFov};drag=null;return}
 drag={x:e.clientX,y:e.clientY,yaw:indoor?indoorHeading:yaw,pitch:indoor?indoorLook:pitch,moved:false};try{canvas.setPointerCapture(e.pointerId)}catch{}});
canvas.addEventListener('pointermove',e=>{if(pointers.has(e.pointerId))pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(pointers.size===2&&pinchStart){const pts=[...pointers.values()],length=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);if(length>4){if(indoor)indoorFov=clamp(pinchStart.fov*pinchStart.length/length,.60,1.60);else dist=clamp(pinchStart.dist*pinchStart.length/length,Math.max(6,fitDistance()*.35),fitDistance()*2.7);requestDraw()}return}
 if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.hypot(dx,dy)>5)drag.moved=true;if(drag.moved){if(indoor){indoorHeading=drag.yaw+dx*.005;indoorLook=clamp(drag.pitch+dy*.0019,-.23,.23)}else{yaw=drag.yaw+dx*.009;pitch=clamp(drag.pitch+dy*.006,.10,1.40)}requestDraw()}});
canvas.addEventListener('pointerup',e=>{pointers.delete(e.pointerId);if(pointers.size<2)pinchStart=null;
 if(drag&&!drag.moved&&placeTool){const mouse=localScreen(e);
 if(indoor){placeIndoor(Math.atan((mouse.x-mouse.w/2)/(mouse.w/(2*Math.tan(indoorFov/2)))),clamp(1.4+(1-mouse.y/mouse.h)*2.4,1.1,4))}
 else if(home.cutaway){const cam=setCamera(mouse.w,mouse.h),r=cam.right,u=cam.up,f=cam.fw,cx=(mouse.x-mouse.w/2)/cam.focal,cy=-(mouse.y-mouse.h*.57)/cam.focal;
 const ray=norm(add(f,add(scale(r,cx),scale(u,cy))));const t=(.55+activeFloor*(Number(profile.ceilingHeight)||2.8)-cam.eye[2])/(ray[2]||.000001);const hit=add(cam.eye,scale(ray,t));
 if(t>0&&Math.abs(hit[0])<dimensions.sx*4.15&&Math.abs(hit[1])<dimensions.sy*2.95)placeAtCanonical(placeTool,[hit[0]/dimensions.sx,hit[1]/dimensions.sy]);
 }}drag=null;requestDraw()});
canvas.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);drag=null;pinchStart=null});
canvas.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1:-1)},{passive:false});
canvas.addEventListener('keydown',e=>{if(indoor){const key=e.key.toLowerCase();if(['w','a','s','d','arrowleft','arrowright','arrowup','arrowdown','shift'].includes(key)){activeKeys.add(key);e.preventDefault()}if(key==='escape'){setIndoor(false);e.preventDefault()}}
 else{if(e.key==='ArrowLeft'){yaw-=.13;requestDraw();e.preventDefault()}else if(e.key==='ArrowRight'){yaw+=.13;requestDraw();e.preventDefault()}else if(e.key==='ArrowUp'){pitch=clamp(pitch+.1,.1,1.4);requestDraw();e.preventDefault()}else if(e.key==='ArrowDown'){pitch=clamp(pitch-.1,.1,1.4);requestDraw();e.preventDefault()}}});
window.addEventListener('keydown',e=>{if(indoor&&!['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName)&&!e.ctrlKey&&!e.altKey&&!e.metaKey){const key=e.key.toLowerCase();if(['w','a','s','d','arrowleft','arrowright','arrowup','arrowdown','shift'].includes(key)){activeKeys.add(key);e.preventDefault()}}});
window.addEventListener('keyup',e=>activeKeys.delete(e.key.toLowerCase()));
window.addEventListener('blur',()=>{activeKeys.clear();touchWalk=''});
window.addEventListener('urban-energy-change',()=>{energy=getEnergy();const adjusted=importAppliancesFromEnergy(design,energy,activeFloor);if(JSON.stringify(adjusted.objects)!==JSON.stringify(design.objects))design=saveDesign(adjusted);syncPositions();updateUI()});
window.addEventListener('urban-property-change',()=>{profile=getProfile();updateUI()});
window.addEventListener('storage',e=>{if(e.key==='us4.calc.electricity'){energy=getEnergy();design=saveDesign(importAppliancesFromEnergy(design,energy,activeFloor));syncPositions();updateUI()}else if(e.key==='us4.property'){profile=getProfile();updateUI()}});
window.addEventListener('resize',requestDraw);updateUI();tick();
}
