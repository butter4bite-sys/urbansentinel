/** Urban Sentinel immersive interior — standalone WebGL 1 renderer.
 * 1 world unit = 1 metre. Geometry is an editable concept, not a measured scan.
 * No CDN, no authentication or personal data access.
 */
const VERT=`precision mediump float;
attribute vec3 aPosition;attribute vec3 aNormal;attribute vec2 aUV;attribute vec3 aTint;attribute float aMat;
uniform mat4 uViewProjection;varying vec3 vWorld;varying vec3 vNormal;varying vec2 vUV;varying vec3 vTint;varying float vMat;
void main(){vWorld=aPosition;vNormal=aNormal;vUV=aUV;vTint=aTint;vMat=aMat;gl_Position=uViewProjection*vec4(aPosition,1.);}`;
const FRAG=`precision highp float;
varying vec3 vWorld;varying vec3 vNormal;varying vec2 vUV;varying vec3 vTint;varying float vMat;
uniform vec3 uEye;uniform float uTime;uniform float uLed;uniform float uHeat;uniform float uHeatMode;uniform float uEnergyMode;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
vec3 materials(){vec3 c=vTint;float m=vMat;
if(m<.5){float n=noise(vUV*4.2)*.035+noise(vUV*13.)*.025;c*=1.-n;}
else if(m<1.5){ // wood planks, metre-scaled
 float row=floor(vUV.y*1.7),t=fract(vUV.y*1.7);float col=fract(vUV.x*1.55+mod(row,2.)*.48);float gr=step(t,.025)+step(.987,t)+step(col,.025)+step(.98,col);
 float grain=.035*sin(vUV.x*27.+noise(vUV*2.)*3.)+.060*noise(vUV*15.);
 c*=1.+grain; c=mix(c,c*.60,min(1.,gr*.50));}
else if(m<2.5){ // polished marble / porcelain
 float vein=pow(max(0.,sin(vUV.x*3.7+vUV.y*1.45+noise(vUV*4.)*6.)),20.);
 c*=1.-.14*vein+.027*noise(vUV*18.);}
else if(m<3.5){ // upholstered fabric
 c*=.9+.12*noise(vUV*37.)+.04*hash(floor(vUV*77.));}
else if(m<4.5){ // matte painted metal
 c*=.94+.055*noise(vUV*15.);}
else if(m<5.5){ // window glass: lit exterior sky and greenery
 float skyline=smoothstep(.30,.76,fract(vUV.y*.16));
 vec3 sky=mix(vec3(.24,.47,.57),vec3(.71,.83,.85),skyline);
 float glint=pow(max(0.,sin(vUV.x*.35+uTime*.08)),15.)*.14;
 c=mix(sky,c,.25)+glint;}
else if(m<6.5){ // backlit LED
 c=vTint*(1.65+.24*sin(uTime*.35));}
else if(m<7.5){ // rug patterned woven textile
 c*=.87+.13*noise(vUV*24.);float border=step(fract(vUV.x*.15),.04)+step(fract(vUV.y*.15),.04);c=mix(c,c*.7,clamp(border,0.,1.)*.35);}
else if(m<8.5){ // greenery
 c*=.75+.45*noise(vUV*9.);}
if(uHeatMode>.5){float hot=clamp(uHeat/100.,0.,1.);vec3 heat=mix(vec3(.10,.53,.83),vec3(1.,.26,.08),smoothstep(.22,.86,hot));c=mix(c,heat,m<5.5?.13:.07);}
if(uEnergyMode>.5 && m>5.5&&m<6.5)c+=vec3(.07,.17,.16);
return c;
}
void main(){vec3 n=normalize(vNormal);vec3 sun=normalize(vec3(.35,.84,-.48));
 float direct=max(dot(n,sun),0.);float fill=max(dot(n,normalize(vec3(-.5,.55,.5))),0.);
 float light=.39+direct*.43+fill*.16+clamp(uLed,0.,1.)*.12;
 vec3 viewDir=normalize(uEye-vWorld);vec3 halfway=normalize(sun+viewDir);
 float shininess=vMat>3.5&&vMat<5.5?45.:vMat>4.5&&vMat<5.5?110.:18.;
 float spec=pow(max(dot(n,halfway),0.),shininess)*(vMat>3.5?.23:.07);
 vec3 col=materials()*light+vec3(spec)+vec3(.02,.035,.035);
 if(vMat>5.5&&vMat<6.5)col=materials()*1.12; if(vMat>4.5&&vMat<5.5)col=materials()*.94+vec3(.10);
 float fog=clamp((length(vWorld-uEye)-19.)/46.,0.,.45);col=mix(col,vec3(.42,.55,.58),fog);
 col=pow(max(col,vec3(0.)),vec3(.88));
 gl_FragColor=vec4(col,1.);
}`;
const RAD=Math.PI/180;
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
function compile(gl,kind,source){const s=gl.createShader(kind);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error('WebGL shader: '+gl.getShaderInfoLog(s));return s;}
function shaderProgram(gl){const p=gl.createProgram();gl.attachShader(p,compile(gl,gl.VERTEX_SHADER,VERT));gl.attachShader(p,compile(gl,gl.FRAGMENT_SHADER,FRAG));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error('WebGL linking: '+gl.getProgramInfoLog(p));return p;}
function multiply(a,b){const o=new Float32Array(16);for(let row=0;row<4;row++)for(let col=0;col<4;col++)for(let k=0;k<4;k++)o[col*4+row]+=a[k*4+row]*b[col*4+k];return o;}
function perspective(fovy,aspect,near=.09,far=180){const f=1/Math.tan(fovy*.5);return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)/(near-far),-1,0,0,2*far*near/(near-far),0]);}
const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];const unit=a=>{const m=Math.hypot(...a)||1;return a.map(v=>v/m)};const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
function lookAt(eye,yaw,pitch){const f=unit([Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),Math.cos(yaw)*Math.cos(pitch)]);const r=unit(cross([0,1,0],f));const u=unit(cross(f,r));return new Float32Array([r[0],u[0],-f[0],0,r[1],u[1],-f[1],0,r[2],u[2],-f[2],0,-dot(r,eye),-dot(u,eye),dot(f,eye),1]);}
const MAT={plaster:0,wood:1,marble:2,fabric:3,metal:4,glass:5,light:6,carpet:7,leaf:8};
const rgb=h=>{h=h.replace('#','');return[parseInt(h.slice(0,2),16)/255,parseInt(h.slice(2,4),16)/255,parseInt(h.slice(4,6),16)/255]};
class Geometry {
 constructor(){this.data=[];this.vertices=0;}
 tri(a,b,c,n,uv,col,mat){const tone=rgb(col);for(const [p,t] of [[a,uv[0]],[b,uv[1]],[c,uv[2]]])this.data.push(...p,...n,...t,...tone,mat);this.vertices+=3}
 quad(a,b,c,d,n,uv,color,mat){this.tri(a,b,c,n,uv.slice(0,3),color,mat);this.tri(a,c,d,n,[uv[0],uv[2],uv[3]],color,mat)}
 cuboid(x,y,z,w,h,d,color='#dfddd2',mat=0){let x1=x-w/2,x2=x+w/2,y1=y,y2=y+h,z1=z-d/2,z2=z+d/2;
  const p=(x,y,z)=>[x,y,z],U=(a,b,c,d)=>[[0,0],[a,0],[a,b],[0,b]];
  this.quad(p(x1,y1,z1),p(x2,y1,z1),p(x2,y2,z1),p(x1,y2,z1),[0,0,-1],U(w,h),color,mat);
  this.quad(p(x2,y1,z2),p(x1,y1,z2),p(x1,y2,z2),p(x2,y2,z2),[0,0,1],U(w,h),color,mat);
  this.quad(p(x1,y1,z2),p(x1,y1,z1),p(x1,y2,z1),p(x1,y2,z2),[-1,0,0],U(d,h),color,mat);
  this.quad(p(x2,y1,z1),p(x2,y1,z2),p(x2,y2,z2),p(x2,y2,z1),[1,0,0],U(d,h),color,mat);
  this.quad(p(x1,y2,z1),p(x2,y2,z1),p(x2,y2,z2),p(x1,y2,z2),[0,1,0],U(w,d),color,mat);
  this.quad(p(x1,y1,z2),p(x2,y1,z2),p(x2,y1,z1),p(x1,y1,z1),[0,-1,0],U(w,d),color,mat);
 }
 // Simple extruded diagonal blade/leaf: narrow cuboid stretching between endpoints in XZ.
 stick(a,b,thickness=.04,color='#dddcd3',mat=4){const dx=b[0]-a[0],dz=b[2]-a[2],dist=Math.hypot(dx,dz);const ang=Math.atan2(dz,dx),nx=-Math.sin(ang)*thickness/2,nz=Math.cos(ang)*thickness/2;
  const p1=[a[0]+nx,a[1],a[2]+nz],p2=[b[0]+nx,b[1],b[2]+nz],p3=[b[0]-nx,b[1],b[2]-nz],p4=[a[0]-nx,a[1],a[2]-nz];this.quad(p1,p2,p3,p4,[0,1,0],[[0,0],[dist,0],[dist,thickness],[0,thickness]],color,mat);}
}
function furnish(g,room,energy,positions,conditions,mode,elapsed,openings=null,objects=[]){
 const L=room.length,W=room.width,H=room.height,rx=L/2,rz=W/2;
 const cx=(v)=>v*L/12,cz=v=>v*W/9,mini=Math.min(1,L/10,W/7);
 // Real-metre floor, marble kick, ceiling and skirting.
 g.cuboid(0,-.20,0,L+.3,.20,W+.3,'#d2d0c8',2);
 g.cuboid(0,-.03,0,L,.05,W,'#b99169',1);
 g.cuboid(0,H-.10,0,L,.11,W,'#eee8db',0);
 for(const zz of [-rz+.04,rz-.04])g.cuboid(0,.0,zz,L,.13,.08,'#ddd6c8',2);
 for(const xx of [-rx+.04,rx-.04])g.cuboid(xx,0,0,.08,.13,W,'#ddd6c8',2);
 // The guided house uses its real selected-floor opening positions. Legacy callers retain the original designed interior.
 if(Array.isArray(openings)){
   // Each wall is assembled around door/window apertures, so a selected window changes the actual 3D geometry.
   const walls=['north','south','east','west'];
   for(const wall of walls){
    const alongX=wall==='north'||wall==='south',length=alongX?L:W;
    const items=openings.filter(o=>o.wall===wall && ['window','door','vent','exhaust','curtain'].includes(o.kind)).map(o=>{
       const center=(alongX?o.x:o.y)*length/2;
       const ww=o.kind==='door'?Math.min(1.05,length*.30):o.kind==='vent'||o.kind==='exhaust'?.55:Math.min(1.4,length*.25);
       const bottom=o.kind==='door'?0:o.kind==='vent'||o.kind==='exhaust'?Math.min(H-1.0,1.82):.87;
       const height=Math.min(o.kind==='door'?2.12:o.kind==='vent'||o.kind==='exhaust'?.46:1.24,H-bottom-.22);
       return {o,a:Math.max(-length/2+.2,center-ww/2),b:Math.min(length/2-.2,center+ww/2),bottom,height};
    }).sort((a,b)=>a.a-b.a);
    const addWall=(start,end,y,h,color='#e2e0d6')=>{if(end-start<.02||h<.02)return;const c=(start+end)/2;
      if(alongX)g.cuboid(c,y,wall==='north'?rz-.07:-rz+.07,end-start,h,.14,color,0);
      else g.cuboid(wall==='east'?rx-.07:-rx+.07,y,c,.14,h,end-start,color,0);
    };
    let cursor=-length/2;
    for(const it of items){if(it.a<cursor-.01)continue;addWall(cursor,it.a,0,H);
     addWall(it.a,it.b,0,it.bottom);addWall(it.a,it.b,it.bottom+it.height,H-it.bottom-it.height);
     const center=(it.a+it.b)/2,span=it.b-it.a,glass=it.o.kind==='door'?'#627f81':it.o.open===false?'#59899c':'#7cc1c4';
     if(alongX){const z=(wall==='north'?rz:-rz)+(wall==='north'?-.19:.19);g.cuboid(center,it.bottom+.02,z,span-.08,it.height-.04,.04,glass,5);
       g.cuboid(center,it.bottom,z,span,.052,.12,'#e9eee6',4);g.cuboid(center,it.bottom+it.height-.07,z,span,.07,.12,'#e9eee6',4);
       if(it.o.kind==='window')g.cuboid(center,it.bottom+.06,z,.055,it.height-.09,.08,'#e5edeb',4);
     }else{const x=(wall==='east'?rx:-rx)+(wall==='east'?-.19:.19);g.cuboid(x,it.bottom+.02,center,.04,it.height-.04,span-.08,glass,5);
       g.cuboid(x,it.bottom,center,.12,.052,span,'#e9eee6',4);g.cuboid(x,it.bottom+it.height-.07,center,.12,.07,span,'#e9eee6',4);
       if(it.o.kind==='window')g.cuboid(x,it.bottom+.04,center,.08,it.height-.09,.055,'#e5edeb',4);
     }
     cursor=it.b;
    }
    addWall(cursor,length/2,0,H);
   }
   // Visible outdoor reference through real openings, purely illustrative landscape.
   g.cuboid(0,0,rz+2.25,L+8,1.3,.09,'#568672',8);
   for(let j=-3;j<=3;j++){const x=j*L*.3;g.cuboid(x,.15,rz+2.1,.12,1.3,.11,'#765d42',1);g.cuboid(x,1.16,rz+2.12,.77,.8,.74,'#60956b',8)}
 }else{
 // Rear wall, plaster above/below prominent picture window, side walls.
 const winW=Math.min(2.9,L*.40),winY=.88,winH=Math.min(1.40,H-1.32),back=rz-.085;
 const xseg=(L-winW)/2;
 for(const x of [-(L+winW)/4,(L+winW)/4])g.cuboid(x,.0,back,xseg,H,.17,'#d5d9cf',0);
 g.cuboid(0,0,back,winW,winY,.17,'#d5d9cf',0);
 g.cuboid(0,winY+winH,back,winW,H-winY-winH,.17,'#d5d9cf',0);
 g.cuboid(0,winY,rz-.135,winW-.12,winH,.035,'#6aabc1',5);
 g.cuboid(0,winY,rz-.195,winW+.15,.07,.17,'#efeae3',2);
 g.cuboid(0,winY+winH-.05,rz-.195,winW+.15,.09,.16,'#eeeae4',2);
 for(const x of [-winW/2,0,winW/2])g.cuboid(x,winY,rz-.18,.05,winH,.09,'#f1f3ed',4);
 // Outside view: landscaping behind glass, rendered as true 3D distant panels.
 g.cuboid(0,0,rz+2.2,L+8,1.7,.10,'#5a8f75',8);
 for(let i=-4;i<=4;i++){const x=i*(L*.27);g.cuboid(x,.15,rz+2.01,.12,1.5,.11,'#70543b',1);g.cuboid(x,1.2,rz+2.0,.9,.85,.9,'#5c9671',8)}
 // Front-wall main doorway and secondary glass panel; door is translucent reflective glass rather than a fake solid wall.
 const doorW=Math.min(1.65,L*.23),doorH=Math.min(2.28,H-.28),front=-rz+.08;
 for(const x of [-(L+doorW)/4,(L+doorW)/4])g.cuboid(x,0,front,(L-doorW)/2,H,.16,'#ddd9cd',0);
 g.cuboid(0,doorH,front,doorW,H-doorH,.16,'#ddd9cd',0);
 g.cuboid(0,0,front-.09,doorW-.09,doorH-.03,.035,'#547f85',5);
 for(const dx of [-doorW/2,doorW/2])g.cuboid(dx,0,front-.14,.07,doorH,.12,'#e9ddd1',4);
 g.cuboid(doorW*.35,1.0,front-.22,.045,.25,.08,'#d9b577',4);
 // Side walls with framed windows; wall surfaces are true 3D, windows are illuminated glass panels.
 for(const side of [-1,1]){
   const sideX=side*(rx-.075),cw=Math.min(W*.24,1.48),ww=Math.min(1.55,H-.9),wy=.88;
   g.cuboid(sideX,0,-(W+cw)/4,.15,H,(W-cw)/2,'#e6e4dc',0);
   g.cuboid(sideX,0,(W+cw)/4,.15,H,(W-cw)/2,'#e6e4dc',0);
   g.cuboid(sideX,0,0,.15,wy,cw,'#e6e4dc',0);
   g.cuboid(sideX,wy+ww,0,.15,H-wy-ww,cw,'#e6e4dc',0);
   g.cuboid(sideX-side*.022,wy,0,.034,ww-.025,cw-.05,'#6ca9b9',5);
   g.cuboid(sideX-side*.062,wy,0,.08,.065,cw+.10,'#f4f3ed',4);
   g.cuboid(sideX-side*.062,wy+ww-.055,0,.08,.065,cw+.10,'#f4f3ed',4);
   for(const z of [-cw/2,0,cw/2])g.cuboid(sideX-side*.065,wy,z,.07,ww,.07,'#f5f1e9',4);
 }
 }
 // Modern living area: scaled furniture still has plausible metric sizes.
 const s=Math.max(.50,mini);
 const livingX=clamp(-L*.18,-rx+1.3,rx-1.5),livingZ=clamp(-W*.02,-rz+1.2,rz-1.3);
 g.cuboid(livingX,.018,livingZ,Math.min(3.55,L*.43),.035,Math.min(2.65,W*.34),'#b9c0b0',7); // rug
 const sofaZ=livingZ+Math.min(.85,W*.12);
 g.cuboid(livingX,.10,sofaZ,2.48*s,.50,.91*s,'#71948e',3);
 g.cuboid(livingX,.55,sofaZ+.32*s,2.48*s,.62,.27*s,'#7d9a91',3);
 for(const j of [-1,0,1])g.cuboid(livingX+j*.74*s,.50,sofaZ-.06*s,.68*s,.19,.68*s,j===0?'#bfd2bd':'#9cb5ae',3);
 for(const x of [-1.2,1.2])g.cuboid(livingX+x*s,.13,sofaZ,.15,.68,.9*s,'#648078',3);
 g.cuboid(livingX,.04,livingZ-.72*s,1.50*s,.42,.77*s,'#9f7655',1);
 g.cuboid(livingX,.46,livingZ-.72*s,1.56*s,.065,.80*s,'#d9c9ad',2);
 for(const x of [-.52,.52])for(const z of [-.27,.27])g.cuboid(livingX+x*s,.13,livingZ-.72*s+z*s,.10,.31,.10,'#73543b',1);
 // TV wall opposite living room, with floating console, display and shelf decor.
 const tx=clamp(livingX+2.55*s,-rx+1.0,rx-.52),tz=livingZ;
 g.cuboid(tx,.25,tz,.38,.43,2.25*s,'#ae9274',1);
 g.cuboid(tx-.22,1.12,tz,.035,1.0,1.72*s,'#182d37',4);
 g.cuboid(tx-.244,1.16,tz,.021,.90,1.61*s,'#325e70',5);
 g.cuboid(tx-.09,.67,tz,.21,.05,1.22*s,'#c9b495',2);
 // Detailed fitted kitchen near back-left, countertops and handles.
 const kitchenZ=rz-.75,kitchenX=clamp(-L*.18,-rx+1.45,rx-1.4),cabW=Math.min(3.4,L*.43);
 g.cuboid(kitchenX,.06,kitchenZ,cabW,.78,.68,'#d8d5c9',4);
 g.cuboid(kitchenX,.82,kitchenZ,cabW,.070,.75,'#565d63',2);
 g.cuboid(kitchenX,1.65,kitchenZ+.08,cabW,.68,.45,'#e2d5bf',1);
 for(let j=1;j<4;j++){const xx=kitchenX-cabW/2+cabW*j/4;g.cuboid(xx,.13,kitchenZ-.365,.028,.61,.05,'#989b90',4);g.cuboid(xx,1.70,kitchenZ-.17,.028,.60,.045,'#c1b39e',4)}
 g.cuboid(kitchenX,.92,kitchenZ-.375,.68,.035,.45,'#8c959a',4);g.cuboid(kitchenX,1.0,kitchenZ-.38,.035,.22,.035,'#aeb3b4',4);
 for(const xx of [kitchenX+.72,kitchenX+.98])for(const zz of [kitchenZ-.11,kitchenZ+.13])g.cuboid(xx,.905,zz,.14,.015,.14,'#24282e',4);
 // Decorative wall art, plant, floor lamp and bench give the scene depth.
 g.cuboid(-rx+.15,1.19,clamp(livingZ,-rz+1,rz-1),.08,.91,1.15,'#b59e7c',1);
 g.cuboid(-rx+.106,1.30,clamp(livingZ,-rz+1,rz-1),.025,.70,.92,'#4a6b63',7);
 const plantX=rx-.68,plantZ=rz-1.15;
 g.cuboid(plantX,.03,plantZ,.50,.48,.50,'#c7b4a4',2);
 g.cuboid(plantX,.51,plantZ,.12,1.20,.10,'#7f845c',8);
 for(let j=0;j<7;j++){const a=j*2.40;g.cuboid(plantX+Math.cos(a)*.25,1.2+Math.sin(a*.8)*.18,plantZ+Math.sin(a)*.24,.46,.25,.20,'#59866d',8)}
 // Appliance positions are canonical X[-4.5,4.5], Y[-3.3,3.3] -> dimensions in real metres.
 const mapPosition=pair=>[clamp(pair[0]*L/9,-rx+.50,rx-.50),clamp(pair[1]*W/6.6,-rz+.40,rz-.40)];
 const list=(key,n)=>Array.isArray(positions?.[key])?positions[key].slice(0,n):[];
 list('fridge',energy?.fridgeCount||0).forEach((p,i)=>{const [x,z]=mapPosition(p);let hh=Math.min(1.92,H-.27);g.cuboid(x,.04,z,.73,hh,.72,'#e6eceb',4);g.cuboid(x,.04,z-.370,.70,hh,.018,'#f0f3f0',4);g.cuboid(x,.05+hh*.45,z-.396,.72,.030,.04,'#899e9d',4);g.cuboid(x+.26,.85,z-.415,.025,.29,.03,'#78928f',4);g.cuboid(x+.26,1.45,z-.415,.025,.25,.03,'#78928f',4);});
 list('ac',energy?.acCount||0).forEach(p=>{const [x,z]=mapPosition(p);const ax=clamp(x,-rx+.76,rx-.76);g.cuboid(ax,H-.70,z,1.12,.35,.30,'#f1f3f0',4);g.cuboid(ax,H-.50,z-.16,.94,.05,.024,'#8dabad',4);g.cuboid(ax+.40,H-.37,z-.165,.11,.04,.025,'#78cad5',6)});
 list('lights',energy?.lightsCount||0).forEach(p=>{const[x,z]=mapPosition(p);g.cuboid(x,H-.13,z,.44,.075,.44,'#fff3bb',6);g.cuboid(x,H-.19,z,.25,.04,.25,'#fff6cf',6)});
 list('fans',energy?.fanCount||0).forEach((p,i)=>{const[x,z]=mapPosition(p);let y=H-.46;g.cuboid(x,y,z,.095,.40,.095,'#bac6be',4);g.cuboid(x,y-.12,z,.37,.13,.37,'#e2e4dd',4);
  const a=(elapsed*.002+i*.8);for(let b=0;b<3;b++){const t=a+b*Math.PI*2/3;const end=[x+Math.cos(t)*.57,y-.09,z+Math.sin(t)*.57];g.stick([x,y-.09,z],end,.20,'#c7dad7',4)} });
 // Manually placed climate-related objects are real 3D geometry in the selected-floor walkthrough.
 for(const o of objects||[]){const x=clamp(o.x*L/2,-rx+.45,rx-.45),z=clamp(o.y*W/2,-rz+.45,rz-.45);
  if(o.kind==='heater'){g.cuboid(x,.03,z,.66,.72,.38,'#ae6855',4);for(let j=0;j<4;j++)g.cuboid(x-.20+j*.13,.14,z-.20,.035,.42,.04,'#ed9a69',6)}
  if(o.kind==='cooler'){g.cuboid(x,.03,z,.60,1.02,.55,'#a0bec4',4);g.cuboid(x,.60,z-.29,.45,.25,.03,'#385f67',5)}
  if(o.kind==='bed'){g.cuboid(x,.10,z,1.72,.37,1.2,'#c8af95',1);g.cuboid(x,.42,z+.43,1.65,.13,.28,'#8faaa1',3)}
  if(o.kind==='desk'){g.cuboid(x,.68,z,1.12,.09,.56,'#b9a185',1);for(const dx of [-.48,.48])g.cuboid(x+dx,.0,z,.08,.7,.08,'#8e765a',1)}
  if(o.kind==='counter'){g.cuboid(x,.03,z,1.4,.81,.60,'#babdb6',2);g.cuboid(x,.83,z,1.45,.05,.64,'#6d7779',2)}
  if(o.kind==='sofa'){g.cuboid(x,.10,z,1.55,.42,.75,'#628e83',3);g.cuboid(x,.46,z+.26,1.55,.43,.21,'#7d9d91',3)}
 }
 // Real usable metre markers around the floor near the exit.
 for(let x=-Math.floor(L/2)+1;x<Math.floor(L/2);x++)g.cuboid(x,.02,-rz+.42,.018,.01,.085,'#79928a',4);
}
export function mountImmersiveRoom(container,callbacks={}){
 const canvas=document.createElement('canvas');canvas.className='cg-immersive-3d';canvas.id='cg-immersive-3d';canvas.tabIndex=0;canvas.setAttribute('aria-label','Actual 3D walk-through of the configured indoor room');canvas.hidden=true;container.appendChild(canvas);
 const warning=document.createElement('div');warning.className='cg-immersive-message';warning.hidden=true;container.appendChild(warning);
 const hud=document.createElement('div');hud.className='cg-immersive-hud';hud.innerHTML='<span class="cg-crosshair">+</span><span class="cg-immersive-caption">DRAG TO LOOK · WASD TO WALK · PRESS ESC TO EXIT</span>';hud.hidden=true;container.appendChild(hud);
 let gl=null,p=null,vbo=null,frameData=null,count=0,geometrySignature='',visible=false,stopped=false,lastAngle=0,raf=0;
 let vpLoc,timeLoc,eyeLoc,ledLoc,heatLoc,heatModeLoc,energyModeLoc;
 const attrs={};
 try{gl=canvas.getContext('webgl',{alpha:false,antialias:true,preserveDrawingBuffer:false,powerPreference:'default'});if(!gl)throw Error('WebGL unavailable on this device');
   p=shaderProgram(gl);gl.useProgram(p);vbo=gl.createBuffer();
   ['aPosition','aNormal','aUV','aTint','aMat'].forEach(k=>attrs[k]=gl.getAttribLocation(p,k));
   vpLoc=gl.getUniformLocation(p,'uViewProjection');timeLoc=gl.getUniformLocation(p,'uTime');eyeLoc=gl.getUniformLocation(p,'uEye');ledLoc=gl.getUniformLocation(p,'uLed');heatLoc=gl.getUniformLocation(p,'uHeat');heatModeLoc=gl.getUniformLocation(p,'uHeatMode');energyModeLoc=gl.getUniformLocation(p,'uEnergyMode');
   gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE); // interior faces visible from either side
 }catch(err){warning.textContent='3D graphics are not available: '+String(err.message);return {available:false,show:()=>{},refresh:()=>{},destroy:()=>{},canvas}};
 let inputs={profile:{length:12,width:9,ceilingHeight:2.8},energy:{lightsCount:5},home:{},positions:{},position:{x:0,y:0},heading:0,look:0,fov:1.23,heatIndex:50,mode:'realistic'};
 const wantGeometry=()=>[inputs.profile?.length,inputs.profile?.width,inputs.profile?.ceilingHeight,inputs.energy?.acCount,inputs.energy?.fanCount,inputs.energy?.lightsCount,inputs.energy?.fridgeCount,JSON.stringify(inputs.positions),JSON.stringify(inputs.openings),JSON.stringify(inputs.objects),inputs.floor].join('|');
 function recreate(t){const {profile,energy,positions,home,mode,openings,objects}=inputs;const room={length:clamp(Number(profile?.length)||12,3,80),width:clamp(Number(profile?.width)||9,3,80),height:clamp(Number(profile?.ceilingHeight)||2.8,2.2,4.5)};
  const g=new Geometry();furnish(g,room,energy,positions,home,mode,t,openings,objects);frameData=new Float32Array(g.data);count=g.vertices;gl.bindBuffer(gl.ARRAY_BUFFER,vbo);gl.bufferData(gl.ARRAY_BUFFER,frameData,gl.DYNAMIC_DRAW);geometrySignature=wantGeometry();
  const stride=12*4;let offset=0;for(const [name,n] of [['aPosition',3],['aNormal',3],['aUV',2],['aTint',3],['aMat',1]]){gl.enableVertexAttribArray(attrs[name]);gl.vertexAttribPointer(attrs[name],n,gl.FLOAT,false,stride,offset);offset+=n*4;}
 }
 let lastGeometry=0;
 function draw(t){if(stopped||!visible||!canvas.isConnected)return;const width=Math.max(1,Math.floor(canvas.clientWidth*Math.min(1.6,window.devicePixelRatio||1))),height=Math.max(1,Math.floor(canvas.clientHeight*Math.min(1.6,window.devicePixelRatio||1)));
  if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;gl.viewport(0,0,width,height)}
  const signature=wantGeometry();if(signature!==geometrySignature||t-lastGeometry>150&&inputs.energy?.fanCount>0){recreate(t);lastGeometry=t}
  const {profile,position,heading,look,fov}=inputs,roomHeight=clamp(Number(profile?.ceilingHeight)||2.8,2.2,4.5),eye=[position.x,Math.min(roomHeight-.30,1.65),position.y];
  const projection=perspective(clamp(Number(fov)||1.23,.65,1.52),width/height),view=lookAt(eye,heading,clamp(-look*1.9,-.47,.47));
  gl.useProgram(p);gl.clearColor(.14,.24,.27,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  gl.uniformMatrix4fv(vpLoc,false,multiply(projection,view));gl.uniform3fv(eyeLoc,eye);gl.uniform1f(timeLoc,t*.001);gl.uniform1f(ledLoc,clamp((inputs.energy?.lightsCount||0)/10,0,1));gl.uniform1f(heatLoc,inputs.heatIndex||55);gl.uniform1f(heatModeLoc,inputs.mode==='thermal'?1:0);gl.uniform1f(energyModeLoc,inputs.mode==='energy'?1:0);
  gl.bindBuffer(gl.ARRAY_BUFFER,vbo);gl.drawArrays(gl.TRIANGLES,0,count);raf=requestAnimationFrame(draw);
 }
 const pointers=new Map();let drag=null;
 canvas.addEventListener('pointerdown',e=>{canvas.focus({preventScroll:true});pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});drag={x:e.clientX,y:e.clientY,px:e.clientX,py:e.clientY,moved:false};try{canvas.setPointerCapture(e.pointerId)}catch{}});
 canvas.addEventListener('pointermove',e=>{if(pointers.has(e.pointerId))pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(!drag||pointers.size>1)return;const dx=e.clientX-drag.px,dy=e.clientY-drag.py;drag.px=e.clientX;drag.py=e.clientY;if(Math.abs(e.clientX-drag.x)+Math.abs(e.clientY-drag.y)>5)drag.moved=true;if(drag.moved)callbacks.turn?.(dx,dy)});
 canvas.addEventListener('pointerup',e=>{pointers.delete(e.pointerId);if(drag&&!drag.moved&&pointers.size===0)callbacks.tap?.(e);drag=null});canvas.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);drag=null});
 canvas.addEventListener('wheel',e=>{e.preventDefault();callbacks.zoom?.(e.deltaY<0?1:-1)},{passive:false});
 canvas.addEventListener('keydown',e=>{if(e.key==='Escape'){callbacks.exit?.();e.preventDefault()}});
 canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();visible=false;warning.textContent='3D graphics context was lost. Please reload this page.';warning.hidden=false});
 return {available:true,canvas,show(v){visible=!!v;canvas.hidden=!visible;hud.hidden=!visible;warning.hidden=true;if(visible){canvas.focus({preventScroll:true});cancelAnimationFrame(raf);raf=requestAnimationFrame(draw)}else cancelAnimationFrame(raf)},refresh(next){inputs={...inputs,...next}},destroy(){stopped=true;cancelAnimationFrame(raf);canvas.remove();hud.remove();warning.remove()}};
}
