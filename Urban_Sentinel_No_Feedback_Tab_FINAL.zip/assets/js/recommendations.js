// Indicative starter allowances. Not supplier prices, engineering sizes or purchase quotes.
export const problems={heat:'Too hot / uncomfortable',air:'Dust, smoke or poor indoor air quality',ventilation:'Poor ventilation / stuffy rooms',energy:'High electricity bills',water:'Water waste / leaking taps',balanced:'Multiple problems / general improvements'};
export const options=[
 {id:'heat-audit',name:'Heat and sun-exposure assessment',tag:'heat',cost:1800,coverage:100000,kind:'service',priority:1,why:'Identifies the rooms and windows causing the greatest heat load.',steps:'Record indoor temperature at different times and identify hot roofs, glazed walls and crowded zones; seek a qualified site survey before major work.'},
 {id:'thermal-curtain',name:'Thermal curtains / blinds',tag:'heat',cost:3200,coverage:160,kind:'product',query:'thermal blackout curtains sun blocking india',priority:2,why:'Blocks direct sun at windows and reduces solar gain in targeted spaces.',steps:'Start with the sun-facing classroom, shopfront or shared room. Measure window dimensions and install safely.'},
 {id:'solar-film',name:'Solar-control window film',tag:'heat',cost:4500,coverage:250,kind:'product',query:'heat control window film for glass UV reflective',priority:3,why:'Reduces solar heat through exposed glass while retaining some daylight.',steps:'Measure exposed glass and check window-glass compatibility; choose suitable film and a competent installer.'},
 {id:'bldc-fan',name:'Efficient BLDC ceiling / wall fans',tag:'heat',cost:5200,coverage:170,kind:'product',query:'BLDC ceiling fan energy efficient',priority:4,why:'Improves thermal comfort through air movement without cooling the whole building.',steps:'Identify occupied zones, confirm ceiling clearance and electrical safety, and have fans installed by a qualified electrician.'},
 {id:'inverter-ac',name:'Inverter AC for enclosed rooms',tag:'heat',cost:58000,coverage:180,kind:'product',query:'1.5 ton inverter split air conditioner india',priority:5,why:'Provides active cooling in selected enclosed rooms where passive measures are insufficient.',steps:'Use a professional cooling-load calculation, check electrical capacity, provide fresh air and include annual electricity and service costs.'},
 {id:'roof-paint',name:'Reflective cool-roof treatment',tag:'heat',cost:36000,coverage:650,kind:'product',query:'solar reflective cool roof coating waterproof',priority:6,why:'Can reduce solar heat absorption by suitable exposed roofs.',steps:'Survey waterproofing, roof finish, roof area, structural condition and professional application requirements first.'},
 {id:'thermal-insulation',name:'Roof / wall insulation upgrade',tag:'heat',cost:44000,coverage:700,kind:'product',query:'roof thermal insulation boards india',priority:7,why:'Reduces heat transfer through roof and walls over time.',steps:'Get a site-specific moisture/fire-safety assessment and safe installation design.'},
 {id:'entrance-shade',name:'Shade canopy over exposed areas',tag:'heat',cost:35000,coverage:400,kind:'product',query:'UV outdoor shade canopy heavy duty',priority:8,why:'Shades entrances, queues, walkways and some shared outdoor spaces.',steps:'Choose a permitted location and check anchoring, storm wind, drainage and pedestrian access.'},
 {id:'dust-seals',name:'Window/door gap seals and pre-filter kits',tag:'air',cost:2600,coverage:260,kind:'product',query:'door window weather sealing tape air dust',priority:1,why:'Can reduce dust entering through uncontrolled gaps.',steps:'Seal unintended leaks, but retain adequate required fresh-air ventilation.'},
 {id:'air-monitor',name:'Indoor particle / CO₂ monitoring starter kit',tag:'air',cost:7800,coverage:1500,kind:'product',query:'PM2.5 CO2 indoor air quality monitor',priority:2,why:'Helps identify particle problems and possible ventilation shortfalls.',steps:'Position away from outlets and confirm sensor calibration and limitations before interpreting readings.'},
 {id:'hepa',name:'True HEPA air purifier',tag:'air',cost:19000,coverage:250,kind:'product',query:'True HEPA air purifier CADR 250 400',priority:3,why:'Filters fine airborne particles but does not lower temperature or replace ventilation.',steps:'Size using CADR, noise and room volume; check replacement-filter availability and running costs.'},
 {id:'vent-audit',name:'Ventilation airflow assessment',tag:'ventilation',cost:2800,coverage:100000,kind:'service',priority:1,why:'Checks supply and exhaust routes before adding equipment.',steps:'Check outdoor-air routes, exhaust points, occupancy and fire-safety constraints with a competent technician.'},
 {id:'exhaust-fan',name:'Exhaust / fresh-air fan',tag:'ventilation',cost:8500,coverage:350,kind:'product',query:'exhaust ventilation fan fresh air',priority:2,why:'Moves stale air out where a proper outside-air path is available.',steps:'Assess window/duct placement and ensure adequate make-up air, safe wiring and acceptable noise.'},
 {id:'fresh-air-unit',name:'Filtered fresh-air ventilation unit',tag:'ventilation',cost:18000,coverage:450,kind:'product',query:'fresh air fan inline duct filter',priority:3,why:'Brings outdoor air into occupied rooms with suitable filtration.',steps:'Confirm intake air quality, airflow requirements and safe duct/penetration design.'},
 {id:'energy-meter',name:'Plug-in energy use monitor',tag:'energy',cost:2500,coverage:1200,kind:'product',query:'plug in energy monitor power meter',priority:1,why:'Measures where electricity is being spent.',steps:'Monitor representative devices safely; do not exceed meter ratings.'},
 {id:'led',name:'Efficient LED lighting upgrade',tag:'energy',cost:3800,coverage:270,kind:'product',query:'energy efficient LED ceiling light commercial',priority:2,why:'Reduces lighting electricity and unnecessary internal heat.',steps:'Count fittings, assess lux/lighting needs and have an electrician replace inefficient lights.'},
 {id:'fan-energy',name:'Replace inefficient fans with BLDC models',tag:'energy',cost:5600,coverage:180,kind:'product',query:'BLDC 5 star energy saving ceiling fan',priority:3,why:'Cuts fan power while preserving air movement.',steps:'Identify old fans with long daily runtimes and compare actual power ratings.'},
 {id:'leak-audit',name:'Water leak and usage survey',tag:'water',cost:2200,coverage:100000,kind:'service',priority:1,why:'Identifies wasted water before buying equipment.',steps:'Record meter readings, inspect fixtures and check obvious leaks.'},
 {id:'aerators',name:'Water-saving tap aerators and fixtures',tag:'water',cost:2600,coverage:400,kind:'product',query:'tap aerator water saving faucet fittings',priority:2,why:'Reduces flow at suitable sinks without changing the water supply.',steps:'Check tap thread sizes, fit compliant aerators and verify usable flow.'},
 {id:'water-meter',name:'Water usage meter / monitoring',tag:'water',cost:9500,coverage:1300,kind:'product',query:'digital water flow meter water consumption monitor',priority:3,why:'Makes abnormal consumption easier to detect.',steps:'Have a qualified plumber verify sizing and correct installation.'},
];
export function buildPlan({problem='heat',area=500,people=10,budget=100000,kind='shop'}){
 const relevant=options.filter(o=>problem==='balanced'?['heat','air','ventilation','energy','water'].includes(o.tag):problem===o.tag);
 const sorted=[...relevant].sort((a,b)=>a.priority-b.priority||a.cost-b.cost);
 const fullQty=o=>o.kind==='service'?1:Math.min(200,Math.max(1,Math.ceil(area/o.coverage),o.id==='hepa'?Math.ceil(people/45):1));
 const maxQty=new Map(sorted.map(o=>[o.id,fullQty(o)]));
 const selected=new Map();let remaining=budget;
 // First pass delivers a practical mix of starter actions; passes 2+ extend coverage.
 for(let pass=0;pass<200;pass++){
  let changed=false;
  for(const o of sorted){
   const current=selected.get(o.id)?.qty||0;
   if(current>=maxQty.get(o.id)||o.cost>remaining)continue;
   // At low budgets, keep a mix of cheap starter actions before expensive equipment.
   if(pass===0&&o.cost>budget*.85&&sorted.some(x=>x.id!==o.id&&x.cost<=remaining&&x.priority<o.priority))continue;
   selected.set(o.id,{...o,qty:current+1,spent:(current+1)*o.cost,fullQty:maxQty.get(o.id)});
   remaining-=o.cost;changed=true;
  }
  if(!changed)break;
 }
 // limit overly long mixed lists; don't silently pretend fixed pricing.
 const plan=[...selected.values()].sort((a,b)=>a.priority-b.priority||a.cost-b.cost);
 const spent=budget-remaining;
 const alternatives=sorted.filter(o=>!selected.has(o.id)).sort((a,b)=>a.cost-b.cost).slice(0,3);
 return{kind,problem,area,people,budget,spent,remaining,plan,alternatives};
}
