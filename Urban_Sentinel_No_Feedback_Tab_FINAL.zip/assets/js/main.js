import './pwa-install.js';
import {mountShell} from './shell.js';
mountShell();
const page=document.body.dataset.page||'index';
const file=({index:'overview',assessment:'assessment-page',projects:'projects',privacy:'about',temperature:'temperature','city-intelligence':'city-intelligence',aqi:'aqi',cooling:'cooling',insights:'insights',about:'about',school:'assessment-page',shop:'assessment-page',neighbourhood:'assessment-page',assistant:'assistant'})[page];
if(file){import(`./pages/${file}.js`).then(m=>m.init?.()).catch(err=>{console.error('Urban Sentinel page load failed:',err);const main=document.getElementById('main');const error=document.createElement('div');error.className='status warn';error.textContent='This page could not finish loading. Please refresh and try again. '+err.message;main.prepend(error)})}
