const KEY='urban-sentinel-projects-v1',MAX=80;
function read(){try{const v=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(v)?v:[]}catch{return[]}}
function save(arr){try{localStorage.setItem(KEY,JSON.stringify(arr));return true}catch{return false}}
export function listProjects(){return read().sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt))}
export function getProject(id){return read().find(x=>x.id===id)||null}
export function saveProject(assessment,extra={}){
 const all=read(),now=new Date().toISOString(),id=extra.id||globalThis.crypto?.randomUUID?.()||String(Date.now())+'-'+Math.random().toString(16).slice(2);
 const old=all.find(x=>x.id===id);
 const project={id,createdAt:old?.createdAt||now,updatedAt:now,assessment,completed:extra.completed||old?.completed||[],actualSpend:Number.isFinite(extra.actualSpend)?extra.actualSpend:old?.actualSpend||0,measurements:extra.measurements||old?.measurements||[]};
 const next=[project,...all.filter(x=>x.id!==id)].slice(0,MAX);
 if(!save(next))throw new Error('Browser storage unavailable; download your report instead.');
 return project;
}
export function deleteProject(id){save(read().filter(x=>x.id!==id))}
export function updateProject(id,patch){const old=getProject(id);if(!old)throw new Error('Project not found');return saveProject(old.assessment,{...old,...patch,id})}
export function exportProjects(){return JSON.stringify({schema:'urban-sentinel-projects-v1',exportedAt:new Date().toISOString(),projects:listProjects()},null,2)}
export function importProjects(text){const data=JSON.parse(text);if(data.schema!=='urban-sentinel-projects-v1'||!Array.isArray(data.projects)||data.projects.length>MAX)throw new Error('Invalid Urban Sentinel backup');
 const valid=data.projects.every(p=>typeof p.id==='string'&&typeof p.updatedAt==='string'&&p.assessment&&typeof p.assessment==='object'&&Array.isArray(p.assessment.steps));if(!valid)throw new Error('Backup format is not valid');
 const existing=read(),combined=[...data.projects,...existing.filter(x=>!data.projects.some(p=>p.id===x.id))].slice(0,MAX);if(!save(combined))throw new Error('Could not save backup');return combined.length;
}
