/** One authoritative city directory shared with the Temperature Map. */
import {statesPromise,locateCity} from './locations-india.js';
import {cities as majorCities} from './cities.js';
export const directoryPromise=statesPromise;
const knownStates={Pune:'Maharashtra',Mumbai:'Maharashtra',Nagpur:'Maharashtra',Delhi:'Delhi',Bengaluru:'Karnataka',Hyderabad:'Telangana',Chennai:'Tamil Nadu',Kolkata:'West Bengal',Ahmedabad:'Gujarat',Jaipur:'Rajasthan',Surat:'Gujarat',Lucknow:'Uttar Pradesh'};
export const knownCities=majorCities.filter(c=>knownStates[c.name]).map(c=>({name:c.name,state:knownStates[c.name],lat:c.lat,lon:c.lng}));
const lookupCache=new Map();
export const cityId=(state,city)=>`${state}\u0001${city}`;
export async function resolveCity(state,name){
 const key=cityId(state,name);
 if(!lookupCache.has(key)){
  const found=knownCities.find(c=>c.state===state&&c.name===name);
  if(found)lookupCache.set(key,Promise.resolve({...found}));
  else lookupCache.set(key,locateCity(state,name).then(c=>({state,name,lat:c.lat,lon:c.lng})).catch(err=>{lookupCache.delete(key);throw err}));
 }
 return lookupCache.get(key);
}
export async function allEntries(){const directory=await directoryPromise;return Object.entries(directory).flatMap(([state,names])=>names.map(name=>({state,name,id:cityId(state,name)})));}
export function populateStates(select,directory,value){select.replaceChildren(...Object.keys(directory).map(state=>new Option(state,state)));if(value&&directory[value])select.value=value;}
export function populateCities(select,directory,state,preferred){const names=directory[state]||[];select.replaceChildren(...names.map(name=>new Option(name,name)));if(preferred&&names.includes(preferred))select.value=preferred;}
export function cityCount(directory){return Object.values(directory).reduce((n,names)=>n+names.length,0)}
