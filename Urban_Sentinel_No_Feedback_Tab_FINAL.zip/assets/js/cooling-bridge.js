/** Cooling Planner → 3D Simulation bridge; no fabricated field measurements. */
import {getProfile} from './property-profile.js';
import {getHome,energyBreakdown,thermalEstimate} from './home-energy-model.js';
import {makeObject,floorSimulation} from './simulation-design.js';
export const COOLING_PLAN_KEY='us4.cooling.latest.v1';
const isFiniteNumber=v=>Number.isFinite(Number(v));
export function storeCoolingPlan(assessment,details){
 const entry={version:1,savedAt:new Date().toISOString(),details:{kind:details.kind,name:details.name,city:details.city,roof:details.roof,areaSqFt:Number(details.area),windowSide:details.windowSide,ventilation:details.ventilation,budget:Number(details.budget)},budget:Number(assessment.budget)||0,spent:Number(assessment.spent)||0,steps:(assessment.steps||[]).slice(0,30).map(s=>({id:s.id,title:s.title,cost:Math.max(0,Number(s.cost)||0)}))};
 try{localStorage.setItem(COOLING_PLAN_KEY,JSON.stringify(entry))}catch{}
 return entry;
}
export function getCoolingPlan(){try{const data=JSON.parse(localStorage.getItem(COOLING_PLAN_KEY)||'null');return data?.version===1&&Array.isArray(data.steps)?data:null}catch{return null}}
export function coolingPlanIssues(plan,profile=getProfile()){
 if(!plan)return ['No Cooling Plan has been submitted yet.'];
 const issues=[];
 if(plan.details.city&&profile.city&&plan.details.city.toLowerCase()!==profile.city.toLowerCase())issues.push('The Cooling Plan city differs from this property.');
 const area=Number(profile.length)*Number(profile.width)*10.7639;
 if(Number(plan.details.areaSqFt)>0&&area>0&&Math.abs(area-Number(plan.details.areaSqFt))/Number(plan.details.areaSqFt)>.20)issues.push('The Cooling Plan floor area differs from the current 3D dimensions.');
 return issues;
}
const improvementKinds=new Set(['shade','insulation','solar','curtain','tree']);
export function baselineDesign(design){return {...design,objects:(design.objects||[]).filter(o=>!improvementKinds.has(o.kind))}}
export function baselineHome(home=getHome()){return {...home,roofCoating:false,roofInsulation:false,shade:15,trees:0}}
export function compareScenarios(design,profile=getProfile(),home=getHome(),energy,plan=null){
 const beforeDesign=baselineDesign(design),beforeHome=baselineHome(home),count=Math.max(1,Math.min(6,Math.round(Number(profile.floors)||1)));
 const floorRows=Array.from({length:count},(_,floor)=>{const baseline=floorSimulation(beforeDesign,profile,beforeHome,floor),improved=floorSimulation(design,profile,home,floor);return {floor,baseline,improved,riskChange:baseline.heatScore-improved.heatScore,airflowChange:improved.airflowIndex-baseline.airflowIndex}});
 const allAvg=key=>floorRows.reduce((t,r)=>t+r[key].heatScore,0)/count;
 const originalRisk=Math.round(allAvg('baseline')),improvedRisk=Math.round(allAvg('improved'));
 const originalRoof=thermalEstimate({home:beforeHome,profile,energy}).roofAbsorbed,improvedRoof=thermalEstimate({home,profile,energy}).roofAbsorbed;
 const electricity=energy?energyBreakdown(energy).total:null;
 const activeMeasures=[...(home.roofCoating?['Reflective roof']:[]),...(home.roofInsulation?['Roof insulation']:[]),...(home.shade>15?['External shading']:[]),...(design.objects?.some(o=>o.kind==='shade')?['Awning']:[]),...(design.objects?.some(o=>o.kind==='tree')?['Trees']:[]),...(design.objects?.some(o=>o.kind==='exhaust')?['Exhaust']:[])];
 return {floorRows,originalRisk,improvedRisk,riskChange:originalRisk-improvedRisk,originalRoof,improvedRoof,roofReduction:originalRoof-improvedRoof,electricity,activeMeasures,planCost:plan?.spent??null,budget:plan?.budget??profile.budget,comparable:coolingPlanIssues(plan,profile).length===0};
}
/** Apply only physical interventions explicitly appearing in the planner's selected set. */
export function applyCoolingPlan(plan,design,profile=getProfile(),home=getHome()){
 if(!plan?.steps?.length)return {design,home,applied:[],advisory:[]};
 const ids=new Set(plan.steps.map(s=>s.id)),applied=[],advisory=[];
 const nextHome={...home};let nextObjects=[...design.objects];
 const floors=Math.max(1,Math.min(6,Math.round(Number(profile.floors)||1)));
 const has=id=>ids.has(id);
 if(has('roof-paint')){nextHome.roofCoating=true;applied.push('Reflective roof')}
 if(has('thermal-insulation')){nextHome.roofInsulation=true;applied.push('Roof insulation')}
 if(has('entrance-shade')||has('thermal-curtain')||has('solar-film')){nextHome.shade=Math.max(35,Number(home.shade)||15);applied.push('Window/exterior solar control');if(has('entrance-shade')&&!nextObjects.some(o=>o.kind==='shade'))nextObjects.push(makeObject('shade',0,0,-.87,'south'))}
 if(has('exhaust-fan')||has('fresh-air-unit')){for(let f=0;f<floors;f++)if(!nextObjects.some(o=>o.kind==='exhaust'&&o.floor===f))nextObjects.push(makeObject('exhaust',f,.86,.1,'east'));applied.push('Ventilation openings')}
 if(has('bldc-fan')||has('fan-energy')){if(!nextObjects.some(o=>o.kind==='fans'))nextObjects.push(makeObject('fans',0,-.2,0));applied.push('Fan placement (comfort, not room air cooling)')}
 if(has('inverter-ac')){if(!nextObjects.some(o=>o.kind==='ac'))nextObjects.push(makeObject('ac',0,-.55,.15));applied.push('AC placement (illustrative)')}
 if(has('heat-audit')||has('vent-audit'))advisory.push('Professional survey/audit steps cannot be simulated as installed hardware.');
 return {design:{...design,objects:nextObjects.slice(0,450)},home:nextHome,applied,advisory};
}
