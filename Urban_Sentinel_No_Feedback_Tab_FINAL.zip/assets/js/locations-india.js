// State-to-city directory: bundled names; coordinates are retrieved from geocoding on demand.
// Neither locality names nor coordinates are fabricated.
export const statesPromise=fetch(new URL('../data/india-states-cities.json',import.meta.url)).then(r=>{if(!r.ok)throw Error('Location directory unavailable');return r.json()});
const coordinateCache=new Map(),localityCache=new Map();
import {localities as puneLocalities} from './localities.js';
import {cities as majorCities} from './cities.js';
const knownCentres=new Map(majorCities.map(c=>[c.name.toLowerCase(),c]));
const sid=s=>String(s).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
export function cityKey(state,name){return `${sid(state)}-${sid(name)}`}
export async function locateCity(state,name){
 const key=cityKey(state,name);if(coordinateCache.has(key))return coordinateCache.get(key);
 const known=knownCentres.get(name.toLowerCase());
 if(known && ({Pune:'Maharashtra',Mumbai:'Maharashtra',Nagpur:'Maharashtra',Delhi:'Delhi',Bengaluru:'Karnataka',Hyderabad:'Telangana',Chennai:'Tamil Nadu',Kolkata:'West Bengal',Ahmedabad:'Gujarat',Jaipur:'Rajasthan',Surat:'Gujarat',Lucknow:'Uttar Pradesh'}[known.name]===state)){const point={id:key,name,state,lat:known.lat,lng:known.lng,zoom:12};coordinateCache.set(key,point);return point;}
 const u=new URL('https://geocoding-api.open-meteo.com/v1/search');u.searchParams.set('name',name);u.searchParams.set('count','15');u.searchParams.set('language','en');u.searchParams.set('format','json');u.searchParams.set('countryCode','IN');
 const r=await fetch(u);if(!r.ok)throw Error('City geocoding is temporarily unavailable');const body=await r.json();
 const candidates=(body.results||[]).filter(x=>Number.isFinite(x.latitude)&&Number.isFinite(x.longitude));
 const norm=s=>String(s||'').toLowerCase().replace(/[^a-z]/g,'');
 const match=candidates.find(c=>norm(c.admin1)===norm(state)&&norm(c.name)===norm(name))||candidates.find(c=>norm(c.admin1)===norm(state))||null;
 if(!match)throw Error(`${name} in ${state} could not be verified by geocoding. Try another city.`);
 const result={id:key,name,state,lat:match.latitude,lng:match.longitude,zoom:12};coordinateCache.set(key,result);return result;
}
export async function loadNeighbourhoods(city){
 if(localityCache.has(city.id))return localityCache.get(city.id);
 // Pune's verified directory is bundled so it works even if OSM's Overpass API is unavailable.
 if(city.name.toLowerCase()==='pune' && city.state==='Maharashtra'){
  const result=puneLocalities.slice(0,20).map(p=>({id:`${city.id}-pune-${p.id}`,name:p.name,lat:p.lat,lng:p.lng,cityId:city.id}));
  localityCache.set(city.id,result);return result;
 }
 const query=`[out:json][timeout:18];(node(around:16000,${city.lat},${city.lng})["place"~"^(suburb|neighbourhood|quarter)$"]["name"];way(around:16000,${city.lat},${city.lng})["place"~"^(suburb|neighbourhood|quarter)$"]["name"];);out center 90;`;
 const endpoints=['https://overpass.kumi.systems/api/interpreter','https://overpass-api.de/api/interpreter'];
 let lastError;
 for(const endpoint of endpoints){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),14000);
  try{
   const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({data:query}),signal:controller.signal});
   if(!r.ok)throw Error(`Neighbourhood service HTTP ${r.status}`);
   const body=await r.json(),seen=new Set(),rows=[];
   for(const item of body.elements||[]){const name=item.tags?.['name:en']||item.tags?.name,lat=item.lat??item.center?.lat,lng=item.lon??item.center?.lon;
    if(!name||!Number.isFinite(lat)||!Number.isFinite(lng))continue;
    const key=name.toLowerCase();if(seen.has(key))continue;seen.add(key);
    rows.push({id:`${city.id}-${sid(name)}`,name,lat,lng,cityId:city.id});
   }
   rows.sort((a,b)=>a.name.localeCompare(b.name));const result=rows.slice(0,20);
   if(result.length){localityCache.set(city.id,result);return result;}
   lastError=Error('No neighbourhood names returned by OpenStreetMap');
  }catch(error){lastError=error;}finally{clearTimeout(timer)}
 }
 throw lastError||Error('Neighbourhood data unavailable');
}
