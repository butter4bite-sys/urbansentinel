/** Transparent NOAA-style solar geometry. All times are local India Standard Time (UTC+05:30).
 * Latitude / longitude and day-of-year drive the result; no building shadows are inferred from imagery.
 */
export const rad = n => n * Math.PI / 180;
export const deg = n => n * 180 / Math.PI;
export function sunPosition({lat, lon, date, hour=12, minute=0}) {
  const latitude=Math.max(-89.9,Math.min(89.9,Number(lat)||0));
  const longitude=Math.max(-180,Math.min(180,Number(lon)||0));
  const day = new Date(`${date||'2026-05-15'}T12:00:00Z`);
  if (!Number.isFinite(day.getTime())) throw Error('Select a valid calendar date.');
  const yearStart=Date.UTC(day.getUTCFullYear(),0,0);
  const doy=Math.floor((day.getTime()-yearStart)/86400000);
  const fractionalYear=2*Math.PI/365*(doy-1+(Number(hour)-12)/24);
  const eqTime=229.18*(0.000075+0.001868*Math.cos(fractionalYear)-0.032077*Math.sin(fractionalYear)-0.014615*Math.cos(2*fractionalYear)-0.040849*Math.sin(2*fractionalYear));
  const decl=0.006918-0.399912*Math.cos(fractionalYear)+0.070257*Math.sin(fractionalYear)-0.006758*Math.cos(2*fractionalYear)+0.000907*Math.sin(2*fractionalYear)-0.002697*Math.cos(3*fractionalYear)+0.00148*Math.sin(3*fractionalYear);
  const solarMinutes=(Number(hour)*60+Number(minute)+eqTime+4*longitude-330+1440)%1440;
  const ha=rad(solarMinutes/4-180), phi=rad(latitude);
  const cosZenith=Math.max(-1,Math.min(1,Math.sin(phi)*Math.sin(decl)+Math.cos(phi)*Math.cos(decl)*Math.cos(ha)));
  const elevation=90-deg(Math.acos(cosZenith));
  const azimuth=(deg(Math.atan2(Math.sin(ha),Math.cos(ha)*Math.sin(phi)-Math.tan(decl)*Math.cos(phi)))+180+360)%360;
  return {elevation,azimuth,dayOfYear:doy,equationOfTime:eqTime,solarNoonMinutes:720-4*longitude-eqTime+330};
}
export function groundShadow(height,elevation){return elevation<=0?null:Math.max(0,Number(height))/Math.tan(rad(elevation));}
export function directionLabel(degValue) {return ['N','NE','E','SE','S','SW','W','NW'][Math.round(degValue/45)%8];}
export function todayIndia(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()).replace(/^(\d\d)\/(\d\d)\/(\d{4})$/, '$3-$1-$2');}
