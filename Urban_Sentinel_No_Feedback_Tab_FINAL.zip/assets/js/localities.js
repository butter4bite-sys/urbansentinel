// Curated Pune locality names and approximate centre coordinates. No synthetic heat scores.
export const localities=[
  {
    "id": 0,
    "name": "Magarpatta",
    "lat": 18.5148,
    "lng": 73.927
  },
  {
    "id": 1,
    "name": "Wagholi",
    "lat": 18.5793,
    "lng": 73.978
  },
  {
    "id": 2,
    "name": "Kharadi",
    "lat": 18.5515,
    "lng": 73.9348
  },
  {
    "id": 3,
    "name": "Baner",
    "lat": 18.559,
    "lng": 73.7868
  },
  {
    "id": 4,
    "name": "Keshavnagar",
    "lat": 18.5267,
    "lng": 73.941
  },
  {
    "id": 5,
    "name": "Shivajinagar",
    "lat": 18.5308,
    "lng": 73.8475
  },
  {
    "id": 6,
    "name": "Kothrud",
    "lat": 18.5074,
    "lng": 73.8077
  },
  {
    "id": 7,
    "name": "Hadapsar",
    "lat": 18.4967,
    "lng": 73.9417
  },
  {
    "id": 8,
    "name": "Viman Nagar",
    "lat": 18.5679,
    "lng": 73.9143
  },
  {
    "id": 9,
    "name": "Hinjewadi",
    "lat": 18.5912,
    "lng": 73.7389
  },
  {
    "id": 10,
    "name": "Pimpri Chinchwad",
    "lat": 18.6279,
    "lng": 73.8009
  },
  {
    "id": 11,
    "name": "Fursungi",
    "lat": 18.465,
    "lng": 73.972
  },
  {
    "id": 12,
    "name": "Mundhwa",
    "lat": 18.533,
    "lng": 73.93
  },
  {
    "id": 13,
    "name": "Amanora Park Town",
    "lat": 18.519,
    "lng": 73.94
  },
  {
    "id": 14,
    "name": "Manjari Budruk",
    "lat": 18.501,
    "lng": 73.982
  },
  {
    "id": 15,
    "name": "Manjari Khurd",
    "lat": 18.53,
    "lng": 73.99
  },
  {
    "id": 16,
    "name": "Shewalewadi",
    "lat": 18.482,
    "lng": 73.953
  },
  {
    "id": 17,
    "name": "Handewadi",
    "lat": 18.461,
    "lng": 73.938
  },
  {
    "id": 18,
    "name": "Sasane Nagar",
    "lat": 18.497,
    "lng": 73.933
  },
  {
    "id": 19,
    "name": "Gadital",
    "lat": 18.501,
    "lng": 73.946
  },
  {
    "id": 20,
    "name": "BT Kawade Road",
    "lat": 18.508,
    "lng": 73.902
  },
  {
    "id": 21,
    "name": "Ghorpadi",
    "lat": 18.521,
    "lng": 73.905
  },
  {
    "id": 22,
    "name": "Koregaon Park",
    "lat": 18.537,
    "lng": 73.894
  },
  {
    "id": 23,
    "name": "Kalyani Nagar",
    "lat": 18.546,
    "lng": 73.902
  },
  {
    "id": 24,
    "name": "Wadgaon Sheri",
    "lat": 18.553,
    "lng": 73.923
  },
  {
    "id": 25,
    "name": "Chandan Nagar",
    "lat": 18.558,
    "lng": 73.939
  },
  {
    "id": 26,
    "name": "Dhanori",
    "lat": 18.6,
    "lng": 73.884
  },
  {
    "id": 27,
    "name": "Vishrantwadi",
    "lat": 18.572,
    "lng": 73.878
  },
  {
    "id": 28,
    "name": "Tingre Nagar",
    "lat": 18.578,
    "lng": 73.895
  },
  {
    "id": 29,
    "name": "Aundh",
    "lat": 18.561,
    "lng": 73.809
  },
  {
    "id": 30,
    "name": "Balewadi",
    "lat": 18.573,
    "lng": 73.777
  },
  {
    "id": 31,
    "name": "Sus",
    "lat": 18.565,
    "lng": 73.748
  },
  {
    "id": 32,
    "name": "Mahalunge",
    "lat": 18.571,
    "lng": 73.765
  },
  {
    "id": 33,
    "name": "Pimple Saudagar",
    "lat": 18.598,
    "lng": 73.797
  },
  {
    "id": 34,
    "name": "Pimple Nilakh",
    "lat": 18.578,
    "lng": 73.791
  },
  {
    "id": 35,
    "name": "Wakad",
    "lat": 18.602,
    "lng": 73.764
  },
  {
    "id": 36,
    "name": "Tathawade",
    "lat": 18.621,
    "lng": 73.746
  },
  {
    "id": 37,
    "name": "Ravet",
    "lat": 18.651,
    "lng": 73.736
  },
  {
    "id": 38,
    "name": "Bibwewadi",
    "lat": 18.472,
    "lng": 73.864
  },
  {
    "id": 39,
    "name": "Katraj",
    "lat": 18.457,
    "lng": 73.867
  },
  {
    "id": 40,
    "name": "Ambegaon Budruk",
    "lat": 18.452,
    "lng": 73.841
  },
  {
    "id": 41,
    "name": "Narhe",
    "lat": 18.459,
    "lng": 73.82
  },
  {
    "id": 42,
    "name": "Karve Nagar",
    "lat": 18.4953,
    "lng": 73.8191
  },
  {
    "id": 43,
    "name": "Warje",
    "lat": 18.486,
    "lng": 73.802
  },
  {
    "id": 44,
    "name": "Bavdhan",
    "lat": 18.518,
    "lng": 73.777
  },
  {
    "id": 45,
    "name": "Pashan",
    "lat": 18.541,
    "lng": 73.795
  },
  {
    "id": 46,
    "name": "Dhayari",
    "lat": 18.448,
    "lng": 73.805
  },
  {
    "id": 47,
    "name": "Sinhagad Road",
    "lat": 18.474,
    "lng": 73.82
  },
  {
    "id": 48,
    "name": "Yerawada",
    "lat": 18.553,
    "lng": 73.882
  },
  {
    "id": 49,
    "name": "Lohegaon",
    "lat": 18.593,
    "lng": 73.926
  },
  {
    "id": 50,
    "name": "Kondhwa",
    "lat": 18.466,
    "lng": 73.898
  },
  {
    "id": 51,
    "name": "Undri",
    "lat": 18.453,
    "lng": 73.916
  },
  {
    "id": 52,
    "name": "NIBM Road",
    "lat": 18.478,
    "lng": 73.903
  },
  {
    "id": 53,
    "name": "Swargate",
    "lat": 18.501,
    "lng": 73.857
  }
];
