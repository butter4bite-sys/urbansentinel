/** Urban Sentinel Indoor — first-person walk-through with metric room bounds.
 * 1 world unit = 1 metre. Floor plan is a conceptual open room; user-entered
 * dimensions change actual travel distances and wall locations. No scan/CFD claims.
 */
import {thermalColor} from './home-energy-model.js';
const minmax=(v,a,b)=>Math.min(b,Math.max(a,v));
export const roomSize=p=>({length:minmax(Number(p?.length)||12,3,80),width:minmax(Number(p?.width)||9,3,80)});
export const walkBounds=(p,margin=.38)=>{const {length,width}=roomSize(p);return {xmin:-length/2+margin,xmax:length/2-margin,ymin:-width/2+margin,ymax:width/2-margin}};
export function walkStep(position,heading,forward,strafe,profile,dt=1){
 const bounds=walkBounds(profile),speed=Math.min(1,Math.max(0,dt));
 const dx=(Math.sin(heading)*forward+Math.cos(heading)*strafe)*speed;
 const dy=(Math.cos(heading)*forward-Math.sin(heading)*strafe)*speed;
 return {x:minmax(position.x+dx,bounds.xmin,bounds.xmax),y:minmax(position.y+dy,bounds.ymin,bounds.ymax)};
}
export function placementInFront(position,heading,profile,distance=1.7){
 return walkStep(position,heading,Math.max(.5,distance),0,profile,1);
}
function wallRay(ox,oy,dx,dy,length,width){
 const a=length/2,b=width/2;let hit=null;
 const hitTry=(d,side,uv)=>{if(d>0.015&&(!hit||d<hit.d))hit={d,side,uv};};
 if(Math.abs(dx)>1e-6){let d=(-a-ox)/dx,y=oy+d*dy;if(y>=-b&&y<=b)hitTry(d,'left',y);d=(a-ox)/dx;y=oy+d*dy;if(y>=-b&&y<=b)hitTry(d,'right',y)}
 if(Math.abs(dy)>1e-6){let d=(-b-oy)/dy,x=ox+d*dx;if(x>=-a&&x<=a)hitTry(d,'front',x);d=(b-oy)/dy;x=ox+d*dx;if(x>=-a&&x<=a)hitTry(d,'back',x)}
 return hit||{d:200,side:'back',uv:0};
}
export function rayDistance(position,heading,profile){const d=roomSize(profile);return wallRay(position.x,position.y,Math.sin(heading),Math.cos(heading),d.length,d.width).d;}
function rounded(ctx,x,y,w,h,r,color){if(w<=0||h<=0)return;ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(x,y,w,h,Math.min(r,w/2,h/2));ctx.fill()}
function text(ctx,value,x,y,font,color='#ebf9f6',align='left'){ctx.fillStyle=color;ctx.font=font;ctx.textAlign=align;ctx.fillText(String(value),x,y);ctx.textAlign='left'}
function drawDevice(ctx,type,x,y,size,active=false,frame=0,mode='realistic'){
 if(!Number.isFinite(size)||size<2)return;
 const sw=minmax(size,12,145),sh=type==='fridge'?sw*1.86:type==='ac'?sw*.47:type==='sofa'?sw*.75:type==='cabinet'?sw*1.5:type==='plant'?sw*1.4:type==='table'?sw*.55:type==='fans'?sw*.9:sw*.8;
 const left=x-sw/2,top=y-sh/2;
 ctx.save();
 if(type==='sofa'){
  rounded(ctx,left,top+sh*.28,sw,sh*.70,Math.max(3,sw*.1),'#8ea69c');rounded(ctx,left+sw*.05,top+sh*.07,sw*.9,sh*.46,Math.max(3,sw*.08),'#b0bfb3');
  for(let i=0;i<3;i++)rounded(ctx,left+sw*(.07+i*.3),top+sh*.52,sw*.27,sh*.25,Math.max(1,sw*.02),'#d1cdc0');
 }else if(type==='cabinet'){
  rounded(ctx,left,top,sw,sh,3,'#9e876d');rounded(ctx,left+sw*.1,top+sh*.05,sw*.80,sh*.9,2,'#b19c7e');
  ctx.strokeStyle='#6e5842';ctx.lineWidth=2;ctx.strokeRect(left+sw*.13,top+sh*.12,sw*.74,sh*.73);
  ctx.strokeStyle='#cbd9bd';ctx.beginPath();ctx.moveTo(x,top+sh*.18);ctx.lineTo(x,top+sh*.83);ctx.stroke();
 }else if(type==='plant'){
  rounded(ctx,x-sw*.16,top+sh*.58,sw*.32,sh*.4,2,'#b8835b');
  for(let i=0;i<7;i++){const theta=i*Math.PI*2/7;ctx.fillStyle=i%2?'#72ad72':'#518e68';ctx.beginPath();ctx.ellipse(x+Math.cos(theta)*sw*.2,top+sh*.40+Math.sin(theta)*sh*.12,sw*.14,sh*.19,theta,0,7);ctx.fill()}
 }else if(type==='table'){
  rounded(ctx,left,top+sh*.2,sw,sh*.35,Math.max(2,sw*.05),'#bd9e77');ctx.fillStyle='#77553a';ctx.fillRect(left+sw*.12,top+sh*.5,sw*.10,sh*.42);ctx.fillRect(left+sw*.78,top+sh*.5,sw*.10,sh*.42);
 }else if(type==='fridge'){
  rounded(ctx,left,top,sw,sh,Math.max(2,sw*.09),'#d7e7df');rounded(ctx,left+sw*.06,top+sh*.03,sw*.87,sh*.92,2,'#f0f5ee');
  ctx.strokeStyle='#91aaa4';ctx.lineWidth=1.8;ctx.beginPath();ctx.moveTo(left+1,top+sh*.40);ctx.lineTo(left+sw-1,top+sh*.40);ctx.stroke();
  rounded(ctx,left+sw*.76,top+sh*.15,Math.max(1,sw*.035),sh*.17,1,'#608f87');rounded(ctx,left+sw*.76,top+sh*.51,Math.max(1,sw*.035),sh*.16,1,'#608f87');
 }else if(type==='ac'){
  rounded(ctx,left,top,sw,sh,Math.max(2,sw*.12),'#e5f6f4');rounded(ctx,left+sw*.06,top+sh*.62,sw*.88,sh*.14,1,'#417b8a');
  ctx.fillStyle='#68cfe1';ctx.fillRect(left+sw*.77,top+sh*.27,sw*.08,Math.max(2,sh*.09));
  if(mode==='thermal'){ctx.strokeStyle='#57c5ff';ctx.lineWidth=2;for(let i=0;i<3;i++){ctx.beginPath();ctx.arc(x+(i-1)*sw*.22,top+sh*.87,sw*.1,0,Math.PI);ctx.stroke()}}
 }else if(type==='fans'){
  ctx.translate(x,y);ctx.fillStyle='#d7e7df';ctx.beginPath();ctx.arc(0,0,sw*.14,0,7);ctx.fill();
  for(let i=0;i<3;i++){ctx.save();ctx.rotate(i*Math.PI*2/3+frame*.075);rounded(ctx,sw*.1,-sw*.07,sw*.41,sw*.16,sw*.08,'#cadfe2');ctx.restore()}
  ctx.strokeStyle='#3c676d';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,sw*.13,0,7);ctx.stroke();
 }else if(type==='lights'){
  const rad=sw*.53;const glow=ctx.createRadialGradient(x,y,0,x,y,rad*2.8);glow.addColorStop(0,'#ffedaa66');glow.addColorStop(1,'#ffedaa00');ctx.fillStyle=glow;ctx.beginPath();ctx.arc(x,y,rad*2.8,0,7);ctx.fill();
  rounded(ctx,x-rad,y-rad*.42,rad*2,rad*.84,rad*.3,active?'#fff2ab':'#e0d7b3');
  ctx.fillStyle='#eacb6c';ctx.fillRect(x-rad*.7,y-rad*.19,rad*1.4,rad*.38);
 }
 ctx.restore();
}
/** Scene is a real-coordinate wall/floor perspective—not an engineering indoor scan. */
export function drawIndoor(ctx,w,h,{profile,position,heading,look=0,energy,positions,mode='realistic',home={},heatIndex=55,walking=false,frame=0,fov:inputFov=1.23}={}){
 const {length,width}=roomSize(profile);const fov=minmax(Number(inputFov)||1.23,.60,1.60);const focal=w/(2*Math.tan(fov/2));const camHeight=1.62,wallHeight=minmax(Number(profile?.ceilingHeight)||2.8,2.2,4.5);
 const bob=walking?Math.sin(frame*.19)*Math.min(4,h*.005):0;
 const horizon=h*.38+minmax(look,-.25,.25)*h*.48+bob;
 // Walls are rendered as individually depth-tested ray columns so the camera may walk inside the room.
 let gradient=ctx.createLinearGradient(0,0,0,h);gradient.addColorStop(0,'#1f353c');gradient.addColorStop(.49,'#536566');gradient.addColorStop(.50,'#957f67');gradient.addColorStop(1,'#665c4e');ctx.fillStyle=gradient;ctx.fillRect(0,0,w,h);
 const ceiling=ctx.createLinearGradient(0,0,0,Math.max(10,horizon));ceiling.addColorStop(0,'#ccdcd8');ceiling.addColorStop(1,'#879c94');ctx.fillStyle=ceiling;ctx.fillRect(0,0,w,Math.max(0,horizon));
 const floor=ctx.createLinearGradient(0,horizon,0,h);floor.addColorStop(0,'#86705c');floor.addColorStop(1,'#463d35');ctx.fillStyle=floor;ctx.fillRect(0,Math.max(0,horizon),w,h);
 const depthMap=new Float32Array(Math.ceil(w)+2);const column=2;
 // Perspective floor planks. World coordinates determine plank scale, rather than arbitrary screen spacing.
 ctx.lineWidth=1;
 for(let row=Math.ceil(horizon+2);row<h;row+=6){
  const d=camHeight*focal/(row-horizon);if(d>length*3+width*3)continue;
  const a=heading-Math.atan((w*.5)/focal),b=heading+Math.atan((w*.5)/focal);
  const x1=position.x+Math.sin(a)*d,y1=position.y+Math.cos(a)*d,x2=position.x+Math.sin(b)*d,y2=position.y+Math.cos(b)*d;
  const tone=(Math.floor((x1+x2)/2*.65)+Math.floor((y1+y2)/2*.65))%2===0?'rgba(245,226,188,.075)':'rgba(43,29,23,.06)';
  ctx.fillStyle=tone;ctx.fillRect(0,row,w,6);
 }
 // One-metre floor grid in correct perspective (metric, not an arbitrary texture scale).
 const floorProject=(x,y)=>{const vx=x-position.x,vy=y-position.y,d=vx*Math.sin(heading)+vy*Math.cos(heading),side=vx*Math.cos(heading)-vy*Math.sin(heading);return d>.20?[w/2+side*focal/d,horizon+camHeight*focal/d]:null};
 function floorLine(ax,ay,bx,by){ctx.beginPath();let drawing=false;
  for(let i=0;i<=45;i++){const t=i/45,pt=floorProject(ax+(bx-ax)*t,ay+(by-ay)*t);if(pt&&pt[0]>-1000&&pt[0]<w+1000&&pt[1]>horizon&&pt[1]<h+15){if(!drawing){ctx.moveTo(pt[0],pt[1]);drawing=true}else ctx.lineTo(pt[0],pt[1])}else drawing=false;}ctx.stroke();}
 ctx.lineWidth=.8;ctx.strokeStyle='rgba(239,218,175,.25)';
 for(let x=Math.ceil(-length/2);x<length/2;x+=1)floorLine(x,-width/2,x,width/2);
 for(let y=Math.ceil(-width/2);y<width/2;y+=1)floorLine(-length/2,y,length/2,y);
 // Ceiling light from the shared LED count; more lights brighten the ceiling.
 ctx.fillStyle=`rgba(249,236,187,${minmax((energy?.lightsCount||0)*.012,0,.22)})`;ctx.fillRect(0,0,w,Math.max(0,horizon));
 for(let sx=0;sx<w;sx+=column){
  const offset=Math.atan((sx-w/2)/focal),angle=heading+offset;
  const dx=Math.sin(angle),dy=Math.cos(angle),hit=wallRay(position.x,position.y,dx,dy,length,width),d=Math.max(.12,hit.d*Math.cos(offset));
  for(let j=sx;j<Math.min(w,sx+column);j++)depthMap[j]=d;
  const top=horizon-(wallHeight-camHeight)*focal/d,bot=horizon+camHeight*focal/d;
  const dark=hit.side==='left'||hit.side==='right';
  const tile=Math.floor(Math.abs(hit.uv)*2.1);const stripe=tile%5===0;
  const baseColor=dark?(stripe?'#8ca6a1':'#b1c0b5'):(stripe?'#abbeb3':'#d6d4c4');
  ctx.fillStyle=baseColor;ctx.fillRect(sx,Math.max(-10000,top),column+.6,Math.max(0,Math.min(h+5000,bot-top)));
  if(mode==='thermal'){ctx.globalAlpha=.22;ctx.fillStyle=thermalColor(minmax(heatIndex-(energy?.acCount||0)*2+(dark?7:2),0,100));ctx.fillRect(sx,Math.max(-10000,top),column+.6,Math.max(0,Math.min(h+5000,bot-top)));ctx.globalAlpha=1;}
  // Exterior windows on each wall, with glass heights defined in metres.
  const spacing=hit.side==='left'||hit.side==='right'?width:length;
  const nearestWindow=Math.min(Math.abs(hit.uv-spacing*.22),Math.abs(hit.uv+spacing*.22));
  if(nearestWindow<Math.min(.85,spacing*.10)||(hit.side==='back'&&Math.abs(hit.uv)<1.10)){
   const topWin=horizon-(2.20-camHeight)*focal/d,botWin=horizon-(.91-camHeight)*focal/d;
   ctx.fillStyle=mode==='thermal'?'#4db1ba':'#3b7580';ctx.fillRect(sx,topWin,column+.9,botWin-topWin);
   if(nearestWindow<.07){ctx.fillStyle='#dfebdb';ctx.fillRect(sx,topWin,column+.7,botWin-topWin)}
   ctx.fillStyle='#ceddd4';ctx.fillRect(sx,topWin+(botWin-topWin)*.51,column+.7,Math.max(1,2*focal/d));
  }
  // Entry door on front side.
  if(hit.side==='front'&&Math.abs(hit.uv)<.54){const t=horizon-(2.22-camHeight)*focal/d;ctx.fillStyle='#715c4b';ctx.fillRect(sx,t,column+.5,Math.max(0,bot-t));if(Math.abs(hit.uv-.42)<.04){ctx.fillStyle='#f1d099';ctx.fillRect(sx,horizon-20,column+1,5)}}
  if(top>=0&&top<h){ctx.fillStyle='rgba(58,65,55,.7)';ctx.fillRect(sx,top,column+.5,Math.max(1,3*focal/d))}
  if(bot>=0&&bot<h){ctx.fillStyle='rgba(45,35,26,.45)';ctx.fillRect(sx,bot-2,column+.5,2)}
 }
 // Furniture provides visual scale, but its layout is illustrative (only room envelope is dimension-driven).
 // Item sprites are drawn in distance order and are occluded by room walls.
 const equipment=[];
 const sceneFurniture=[['sofa',-Math.min(length*.11,1.25),width*.11,1.9,.65],['table',Math.min(length*.06,.75),width*.25,.8,.42],['plant',Math.min(length*.16,1.7),width/2-.55,.65,.90],['cabinet',-Math.min(length*.18,1.9),width/2-.60,.80,1.45]];
 function furnitureSprite(type,tx,ty,metres,z){const vx=tx-position.x,vy=ty-position.y,front=vx*Math.sin(heading)+vy*Math.cos(heading),side=vx*Math.cos(heading)-vy*Math.sin(heading);if(front<.25)return;
 const sx=w/2+side*focal/front,wall=depthMap[Math.floor(minmax(sx,0,w-1))]||100;if(front>wall+.07||sx<-180||sx>w+180)return;
 equipment.push({type,i:-1,sx,front,dist:Math.hypot(vx,vy),metres,z});}
 for(const entry of sceneFurniture)furnitureSprite(...entry);for(const type of ['ac','fans','lights','fridge']){
  const count=Math.max(0,Number(energy?.[type==='ac'?'acCount':type==='fans'?'fanCount':type==='lights'?'lightsCount':'fridgeCount'])||0);
  (positions?.[type]||[]).slice(0,count).forEach((p,i)=>{const tx=p[0]*(length/9),ty=p[1]*(width/6.6);const vx=tx-position.x,vy=ty-position.y,dist=Math.hypot(vx,vy);
   const front=vx*Math.sin(heading)+vy*Math.cos(heading),side=vx*Math.cos(heading)-vy*Math.sin(heading);
   if(front<.25||dist<.26)return;
   const sx=w/2+side*focal/front,wall=depthMap[Math.floor(minmax(sx,0,w-1))]||100;
   if(front>wall+.08||sx<-180||sx>w+180)return;
   equipment.push({type,i,sx,front,dist});
  });
 }
 equipment.sort((a,b)=>b.front-a.front);
 for(const it of equipment){const z=it.z??(it.type==='ac'?Math.min(wallHeight-.45,2.28):it.type==='fans'?wallHeight-.24:it.type==='lights'?wallHeight-.1:1.06);
  const yy=horizon-(z-camHeight)*focal/it.front;
  const size=minmax((it.metres??(it.type==='fridge'?.78:it.type==='fans'?.89:it.type==='lights'?.26:.84))*focal/it.front,7,160);
  drawDevice(ctx,it.type,it.sx,yy,size,true,frame,mode);
 }
 // Interior navigation HUD. This miniature plan is not a geographic/satellite map.
 const mw=minmax(w*.21,100,155),mh=Math.max(78,mw*width/length),mx=w-mw-15,my=h-mh-14;
 rounded(ctx,mx-6,my-20,mw+12,mh+26,9,'rgba(8,36,43,.87)');
 text(ctx,`${length.toFixed(1)} × ${width.toFixed(1)} m`,mx+mw/2,my-5,'700 10px system-ui','#c8f3df','center');
 ctx.strokeStyle='#a6c9bc';ctx.strokeRect(mx,my,mw,mh);
 const px=mx+(position.x/length+.5)*mw,py=my+(position.y/width+.5)*mh;
 for(const type of ['ac','fans','lights','fridge'])for(const p of (positions?.[type]||[]).slice(0,energy?.[type==='ac'?'acCount':type==='fans'?'fanCount':type==='lights'?'lightsCount':'fridgeCount']||0)){
  const x=mx+(p[0]/9+.5)*mw,y=my+(p[1]/6.6+.5)*mh;
  ctx.fillStyle=type==='ac'?'#5bb8ff':type==='fans'?'#89e5c2':type==='lights'?'#f9e19b':'#dfb98d';ctx.beginPath();ctx.arc(x,y,2.2,0,7);ctx.fill();
 }
 ctx.save();ctx.translate(px,py);ctx.rotate(-heading);ctx.fillStyle='#c9ff7d';ctx.beginPath();ctx.moveTo(0,7);ctx.lineTo(-5,-5);ctx.lineTo(5,-5);ctx.closePath();ctx.fill();ctx.restore();
 if(w>550){rounded(ctx,12,12,Math.min(w-24,230),54,9,'rgba(7,35,40,.82)');text(ctx,'INDOOR · FIRST PERSON',24,34,'800 12px system-ui','#c5ff8b');text(ctx,`${Math.round(position.x*10)/10} m E · ${Math.round(position.y*10)/10} m N`,24,52,'11px system-ui','#d0e6de');}
 // A metre-based reference: marker always represents 1 metre at the camera distance.
 const markerW=minmax(focal/Math.max(3,Math.min(8,rayDistance(position,heading,profile)))*1,20,130);
 ctx.fillStyle='#c4ff8c';ctx.fillRect(16,h-34,markerW,3);ctx.fillRect(16,h-38,2,10);ctx.fillRect(16+markerW-2,h-38,2,10);
 text(ctx,'1 m (at viewed distance)',16,h-43,'10px system-ui','#d7f1e5');
}
