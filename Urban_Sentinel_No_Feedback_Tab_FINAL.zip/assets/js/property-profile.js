export const PROFILE_KEY='us4.property';
export const DEFAULT_PROFILE={name:'My Property',city:'Pune',type:'bungalow',roof:'concrete',length:12,width:9,ceilingHeight:2.8,floors:1,orientation:'east',budget:50000};
export const n=(v,min,max,fallback)=>{let x=Number(v);return Number.isFinite(x)?Math.min(max,Math.max(min,x)):fallback};
export function getProfile(){try{return {...DEFAULT_PROFILE,...JSON.parse(localStorage.getItem(PROFILE_KEY)||'{}')}}catch{return {...DEFAULT_PROFILE}}}
export function saveProfile(obj){const v={...getProfile(),...obj};try{localStorage.setItem(PROFILE_KEY,JSON.stringify(v));window.dispatchEvent(new CustomEvent('urban-property-change',{detail:v}))}catch{}return v}
export function safe(v){return String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
export function rupees(n){return '₹'+Math.round(Math.max(0,n)).toLocaleString('en-IN')}
export function saveScenario(s){try{let items=JSON.parse(localStorage.getItem('us4.scenarios')||'[]');if(!Array.isArray(items))items=[];items.unshift({...s,id:Date.now(),savedAt:new Date().toISOString()});localStorage.setItem('us4.scenarios',JSON.stringify(items.slice(0,50)));return true}catch{return false}}
export function getScenarios(){try{const d=JSON.parse(localStorage.getItem('us4.scenarios')||'[]');return Array.isArray(d)?d:[]}catch{return []}}
