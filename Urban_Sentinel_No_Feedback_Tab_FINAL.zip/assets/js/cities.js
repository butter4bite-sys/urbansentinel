import {localities as puneAreas} from './localities.js';
// City-centre reference points and curated neighbourhood centres (approximate, not parcel-level geocodes).
const raw=[
 ['pune','Pune',18.5204,73.8567,13,['Pune (central)','Shivajinagar','Hadapsar','Kothrud','Baner','Hinjawadi','Kharadi','Wakad','Viman Nagar']],
 ['mumbai','Mumbai',19.0760,72.8777,12,['Andheri','Bandra','Dadar','Borivali','Colaba','Goregaon','Kurla','Malad','Powai','Worli']],
 ['delhi','Delhi',28.6139,77.2090,12,['Connaught Place','Karol Bagh','Dwarka','Rohini','Saket','Lajpat Nagar','Janakpuri','Vasant Kunj','Mayur Vihar']],
 ['bengaluru','Bengaluru',12.9716,77.5946,12,['Indiranagar','Koramangala','Whitefield','Jayanagar','HSR Layout','Electronic City','Marathahalli','Malleshwaram','Yelahanka']],
 ['hyderabad','Hyderabad',17.3850,78.4867,12,['Banjara Hills','Jubilee Hills','Gachibowli','Kondapur','Madhapur','Kukatpally','Begumpet','Secunderabad']],
 ['chennai','Chennai',13.0827,80.2707,12,['T Nagar','Adyar','Anna Nagar','Velachery','Tambaram','Mylapore','Porur','Guindy']],
 ['kolkata','Kolkata',22.5726,88.3639,12,['Salt Lake','New Town','Park Street','Ballygunge','Howrah','Behala','Dum Dum','Garia']],
 ['ahmedabad','Ahmedabad',23.0225,72.5714,12,['Navrangpura','Satellite','Bopal','Maninagar','Vastrapur','Thaltej','Chandkheda']],
 ['jaipur','Jaipur',26.9124,75.7873,12,['Malviya Nagar','Vaishali Nagar','Mansarovar','C Scheme','Jagatpura','Civil Lines']],
 ['surat','Surat',21.1702,72.8311,12,['Adajan','Vesu','Varachha','Piplod','Katargam','Udhna']],
 ['nagpur','Nagpur',21.1458,79.0882,12,['Dharampeth','Sitabuldi','Sadar','Manish Nagar','Pratap Nagar','Hingna']],
 ['lucknow','Lucknow',26.8467,80.9462,12,['Hazratganj','Gomti Nagar','Aliganj','Indira Nagar','Alambagh','Aminabad']]
];
const offsets=[[-.023,-.018],[.016,.019],[-.037,.03],[.03,-.021],[.017,-.035],[-.007,.045],[.042,.019],[-.035,-.045],[.05,-.006],[-.052,.009]];
export const cities=raw.map(([id,name,lat,lng,zoom,names])=>({id,name,lat,lng,zoom,localities:id==='pune'?puneAreas.map(a=>({id:`pune-${a.id}`,name:a.name,lat:a.lat,lng:a.lng,cityId:'pune'})):names.map((n,i)=>({id:`${id}-${i}`,name:n,lat:i===0&&id==='pune'?lat:lat+offsets[i%offsets.length][0],lng:i===0&&id==='pune'?lng:lng+offsets[i%offsets.length][1],cityId:id}))}));
export const cityById=id=>cities.find(c=>c.id===id);
