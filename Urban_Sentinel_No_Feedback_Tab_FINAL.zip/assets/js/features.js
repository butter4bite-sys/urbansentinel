// Focused, free, evidence-led Climate Lab. Retired experimental demos are not navigation entries.
export const FEATURES = [
 {id:'digital-twin',title:'Interactive Property Digital Twin',description:'Inspect a cinematic house reference, compare upgrades and view the actual satellite map for your location.'},
 {id:'before-after',title:'Before & After Studio',description:'Compare visible interventions, roof solar absorption and transparent cost assumptions.'},
 {id:'solar-shadow',title:'Solar & Shadow',description:'Use a real geolocation and calendar date for calculated solar angles and shadow lengths.'},
 {id:'xray-house',title:'X-Ray Your House',description:'Compare simplified roof, wall and glazing heat gain using your property inputs.'},
 {id:'cooling-optimizer',title:'Cooling Budget Optimizer',description:'Compare affordable improvements and their indicative costs.'},
 {id:'roof-intelligence',title:'Roof Intelligence',description:'Compare roof material choices, benefits and requirements.'},
 {id:'flood-lab',title:'Rainfall & Runoff Planning',description:'Explore a real satellite area and estimate storm runoff volumes; never predict flood depth.'}
];
export function escapeHTML(text){return String(text??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]||c))}
