/* Mobile install guidance: Android native prompt when supported, iOS manual steps.
 * An installable PWA uses HTTPS on real hosting. Browser UI, not a direct APK download.
 */
let installEvent=null;
const isMobile=()=>/Android|iPhone|iPad|iPod/i.test(navigator.userAgent||'');
const isIOS=()=>/iPhone|iPad|iPod/i.test(navigator.userAgent||'');
const standalone=()=>window.matchMedia?.('(display-mode: standalone)').matches||navigator.standalone===true;
const key='us.pwa.snooze';
function snoozed(){try{return Date.now()<Number(localStorage.getItem(key)||0)}catch{return false}}
function snooze(){try{localStorage.setItem(key,String(Date.now()+14*86400000))}catch{}}
const css=`
.us-pwa-install{position:fixed;bottom:16px;left:16px;right:16px;margin:auto;max-width:480px;z-index:99999;border:1px solid #397566;border-radius:18px;background:#0e3235;color:#effff5;padding:18px;box-shadow:0 14px 55px #0008;font:inherit}
.us-pwa-install .us-pwa-head{display:flex;align-items:center;gap:12px;margin-bottom:8px}
.us-pwa-install img{height:56px;width:56px;border-radius:13px}
.us-pwa-install strong{font-size:17px}
.us-pwa-install p{font-size:13px;color:#c7e3d8;line-height:1.55;margin:8px 0 12px}
.us-pwa-install .us-pwa-buttons{display:flex;gap:9px}
.us-pwa-install button{cursor:pointer;min-height:42px;border-radius:9px;padding:8px 12px;font-weight:700;border:1px solid #436b63;background:#194843;color:#f0ffed}
.us-pwa-install button.install{background:#bcf474;color:#10372b;border-color:#bcf474;flex:1}
.us-pwa-install a{color:#baf28b}
`;
let shown=false;
function show(){if(shown||!isMobile()||standalone()||snoozed()||!document.body)return;shown=true;
 const style=document.createElement('style');style.textContent=css;document.head.append(style);
 const popup=document.createElement('aside');popup.className='us-pwa-install';popup.setAttribute('role','dialog');popup.setAttribute('aria-label','Install Urban Sentinel');
 const instruction=isIOS()?'In Safari: tap Share, then Add to Home Screen.':'Add Urban Sentinel to your home screen from Chrome’s menu (Install app / Add to Home screen).';
 popup.innerHTML=`<div class="us-pwa-head"><img src="assets/icons/urban-sentinel-192.png" alt=""><strong>Install Urban Sentinel</strong></div><p>${installEvent?'Launch the website like an app, directly from your home screen.':instruction} No Play Store required. Requires HTTPS on a hosted website.</p><div class="us-pwa-buttons"><button type="button" class="install">${installEvent?'Install app':isIOS()?'Got it':'How to install'}</button><button type="button" class="later">Not now</button></div>`;
 document.body.append(popup);
 popup.querySelector('.later').addEventListener('click',()=>{snooze();popup.remove();shown=false});
 popup.querySelector('.install').addEventListener('click',async()=>{
  if(installEvent){const e=installEvent;installEvent=null;try{await e.prompt();await e.userChoice}catch{}popup.remove();shown=false;return;}
  if(isIOS()){popup.remove();shown=false;return;}
  popup.querySelector('p').textContent='In Chrome, open ⋮ (menu) → Install app / Add to Home screen. Install availability depends on the browser.';
 });
}
if(typeof window!=='undefined'){
 window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installEvent=e;if(isMobile()&&!snoozed())show()});
 window.addEventListener('appinstalled',()=>{document.querySelector('.us-pwa-install')?.remove();shown=false;installEvent=null});
 window.addEventListener('load',()=>{
  if('serviceWorker' in navigator&&['https:','http:'].includes(location.protocol))navigator.serviceWorker.register('./sw.js').catch(()=>{});
  if(isMobile()&&!standalone()&&!snoozed())setTimeout(show,4500);
 });
}
