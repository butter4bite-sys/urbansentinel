import {localities} from './localities.js';
import {esc} from './ui.js';
let promise;
function getLeaflet(){if(window.L)return Promise.resolve(window.L);if(promise)return promise;promise=new Promise((resolve,reject)=>{const css=document.createElement('link');css.rel='stylesheet';css.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';document.head.append(css);const js=document.createElement('script');js.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';js.async=true;js.onload=()=>window.L?resolve(window.L):reject(new Error('Leaflet unavailable'));js.onerror=()=>reject(new Error('Map library blocked'));document.head.append(js);setTimeout(()=>reject(new Error('Map library timeout')),8500)});return promise}
function nice(n){return Number.isFinite(n)?n.toFixed(1)+'°C':'—'}
function color(n){return !Number.isFinite(n)?'#647c81':n>=40?'#c24f36':n>=35?'#bd712a':n>=29?'#487c65':'#3980a0'}
export function createMap(host,{mode='apparent',getValue=()=>null,onSelect,statusId='mapStatus'}={}){
 const status=document.getElementById(statusId);let map=null,L=null,destroyed=false;const markers=new Map();
 const fallback=()=>{host.innerHTML=`<div class="city-fallback"><div><h3>Pune locality reference map</h3><p>Street map is unavailable. You can still browse areas below. Dashes mean no model value is available.</p></div><div class="fallback-buttons">${localities.map(a=>`<button type="button" data-id="${a.id}"><strong>${esc(a.name)}</strong><small>${nice(getValue(a))}</small></button>`).join('')}</div></div>`;host.querySelectorAll('[data-id]').forEach(btn=>btn.addEventListener('click',()=>{const a=localities[Number(btn.dataset.id)];onSelect?.(a)}))};
 fallback();
 const display=a=>`<b>${esc(a.name)}</b><br>Modelled apparent temperature: <b>${nice(getValue(a))}</b><br><small>Not a street sensor; approximate centre.</small>`;
 const icon=a=>L.divIcon({className:'temp-label',html:`<span class="temp-icon" style="background:${color(getValue(a))}">${nice(getValue(a))}</span>`,iconSize:[54,34],iconAnchor:[27,17]});
 getLeaflet().then(lib=>{if(destroyed)return;L=lib;const el=document.createElement('div');el.style.height='100%';host.replaceChildren(el);map=L.map(el,{scrollWheelZoom:false,preferCanvas:true}).fitBounds(localities.map(a=>[a.lat,a.lng]),{padding:[25,25]});L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors',maxZoom:19}).addTo(map);
  for(const a of localities){const m=L.marker([a.lat,a.lng],{icon:icon(a),title:a.name}).addTo(map).bindPopup(display(a));m.on('click',()=>onSelect?.(a));markers.set(a.id,m)}
  setTimeout(()=>map?.invalidateSize(),120);if(status)status.textContent='OpenStreetMap base layer · locality markers are approximate; temperatures are model estimates.';
 }).catch(()=>{if(status)status.textContent='Street tiles unavailable. Showing an interactive locality directory.';fallback()});
 return {fit:()=>map?.fitBounds(localities.map(a=>[a.lat,a.lng]),{padding:[25,25]}),focus:a=>{const obj=typeof a==='number'?localities.find(x=>x.id===a):a;if(obj&&map){map.flyTo([obj.lat,obj.lng],Math.max(12,map.getZoom()));markers.get(obj.id)?.openPopup()}},updateValues:()=>{if(!map){fallback();return}for(const a of localities){const m=markers.get(a.id);if(!m)continue;m.setIcon(icon(a));m.setPopupContent(display(a))}},destroy:()=>{destroyed=true;map?.remove()}}
}
