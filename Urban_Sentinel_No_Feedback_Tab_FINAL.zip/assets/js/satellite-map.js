/** Real satellite basemap, NOT a land surface temperature map.
 * EOX Sentinel-2 Cloudless 2016 (2016/17 data) CC BY 4.0 permits commercial reuse with credits.
 * The archival mosaic is not up-to-date construction, flood extent or thermal evidence.
 */
export const EOX_ATTRIBUTION='Satellite: <a href="https://cloudless.eox.at/" target="_blank" rel="noopener">EOX Cloudless 2016</a> (modified Copernicus Sentinel-2 2016/17), CC BY 4.0';
export const SATELLITE_URL='https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless_3857/default/GoogleMapsCompatible/{z}/{y}/{x}.jpg';
export const OSM_ATTRIBUTION='© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a>';
export function basemaps(L,map,{defaultView='satellite'}={}){
 const satellite=L.tileLayer(SATELLITE_URL,{attribution:EOX_ATTRIBUTION,maxZoom:19,maxNativeZoom:14,crossOrigin:true});
 const recentDate=new Date(Date.now()-2*86400000).toISOString().slice(0,10);
 const nasa=L.tileLayer(`https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_SNPP_CorrectedReflectance_TrueColor/default/${recentDate}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg`,{attribution:'NASA GIBS / VIIRS SNPP · true color observations; clouds and gaps possible',maxNativeZoom:8,maxZoom:19,opacity:1});
 const streets=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:OSM_ATTRIBUTION,maxZoom:19});
 const active=defaultView==='streets'?streets:satellite;active.addTo(map);
 L.control.layers({'Satellite · Sentinel-2 2016 (10m)':satellite,'NASA daily VIIRS · coarse (~300m)':nasa,'Streets · OpenStreetMap':streets},{},{position:'topright',collapsed:true}).addTo(map);
 let failures=0;
 satellite.on('tileerror',()=>{if(++failures===3&&map.hasLayer(satellite)){map.removeLayer(satellite);streets.addTo(map);map.fire('satelliteunavailable');}});
 return{satellite,nasa,streets};
}
let leafletPromise;
export function getLeaflet(){
 if(window.L)return Promise.resolve(window.L);
 if(leafletPromise)return leafletPromise;
 leafletPromise=new Promise((resolve,reject)=>{
  const css=document.createElement('link');css.rel='stylesheet';css.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';document.head.append(css);
  const script=document.createElement('script');script.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';script.onload=()=>window.L?resolve(window.L):reject(Error('Leaflet unavailable'));script.onerror=()=>reject(Error('Map library could not load'));document.head.append(script);
  setTimeout(()=>{if(!window.L)reject(Error('Map library timed out'))},14000);
 });return leafletPromise;
}
export async function createSiteMap(id,{lat=18.5204,lon=73.8567,zoom=14,onSelect}={}){
 const el=typeof id==='string'?document.getElementById(id):id;
 if(!el)return null;
 try{
  const L=await getLeaflet();el.innerHTML='';const map=L.map(el,{zoomControl:true,scrollWheelZoom:false,minZoom:3,maxZoom:19}).setView([lat,lon],zoom);
  basemaps(L,map);const marker=L.marker([lat,lon],{draggable:true,title:'Property location (drag to move)'}).addTo(map);
  const select=(ll)=>{marker.setLatLng(ll);onSelect?.({lat:Number(ll.lat.toFixed(5)),lon:Number(ll.lng.toFixed(5))})};
  marker.on('dragend',()=>select(marker.getLatLng()));map.on('click',e=>select(e.latlng));
  map.on('satelliteunavailable',()=>el.closest('.us-satellite-area')?.querySelector('.us-map-warning')?.removeAttribute('hidden'));
  requestAnimationFrame(()=>map.invalidateSize());setTimeout(()=>map.invalidateSize(),300);
  return{map,marker,update:(latitude,longitude,level=zoom)=>{map.setView([latitude,longitude],level);marker.setLatLng([latitude,longitude])}};
 }catch(e){el.innerHTML='<div class="us-map-fallback"><strong>Satellite tiles could not load.</strong><p>Location-based calculations still work with entered coordinates. Check the connection or open the satellite source externally.</p><a target="_blank" rel="noopener" href="https://browser.dataspace.copernicus.eu/">View Copernicus satellite browser ↗</a></div>';return null;}
}
export async function searchCity(query){
 const q=String(query||'').trim();if(q.length<2)throw Error('Enter a city name');
 const response=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=10&language=en&format=json`,{signal:AbortSignal.timeout?.(9000)});
 if(!response.ok)throw Error('Location service unavailable');
 const result=await response.json();const found=(result.results||[]).find(x=>x.country_code==='IN')||(result.results||[])[0];
 if(!found)throw Error('City not found. Enter coordinates manually.');return{lat:found.latitude,lon:found.longitude,label:`${found.name}, ${found.admin1||found.country||''}`};
}
/** Optional Open-Meteo modelled shortwave radiation for the chosen location/date. */
export async function shortwaveAt({lat,lon,date,hour}){
 const day=date||new Date().toISOString().slice(0,10);
 const url=`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=shortwave_radiation&timezone=Asia%2FKolkata&start_date=${day}&end_date=${day}`;
 const r=await fetch(url,{signal:AbortSignal.timeout?.(10000)});if(!r.ok)throw Error('Irradiance provider unavailable');
 const d=await r.json(),times=d.hourly?.time||[],radiation=d.hourly?.shortwave_radiation||[];
 const i=times.findIndex(t=>t.startsWith(day+'T'+String(hour).padStart(2,'0')));
 if(i<0||!Number.isFinite(radiation[i]))throw Error('No modelled irradiance for this date/time');
 return{watts:radiation[i],time:times[i],source:'Open-Meteo shortwave radiation · modelled',units:'W/m²'};
}
