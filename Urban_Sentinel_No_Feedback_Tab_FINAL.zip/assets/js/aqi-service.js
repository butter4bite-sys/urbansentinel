// Modelled US AQI from Open-Meteo / CAMS. Not the Indian CPCB National AQI.
const cache=new Map(),TTL=15*60*1000;
export function aqiCategory(value){
 if(!Number.isFinite(value))return{label:'Unavailable',color:'#70818b',advice:'No reliable AQI value is available. Check an official local air quality source before making outdoor plans.',short:'No data'};
 if(value<=50)return{label:'Good',color:'#32916a',advice:'Air quality is generally satisfactory for outdoor activities. People with unusual sensitivity should still monitor symptoms.',short:'Generally OK outdoors'};
 if(value<=100)return{label:'Moderate',color:'#b29a32',advice:'Outdoor activities are generally acceptable for most people. Unusually sensitive people may want to reduce prolonged or heavy exertion.',short:'Most can go out'};
 if(value<=150)return{label:'Unhealthy for sensitive groups',color:'#c77a38',advice:'People with heart or lung disease, older adults, children and other sensitive groups should reduce prolonged or heavy outdoor exertion. Others can usually go out with caution.',short:'Sensitive groups: limit exertion'};
 if(value<=200)return{label:'Unhealthy',color:'#c34f45',advice:'Everyone should reduce prolonged or heavy outdoor exertion. Sensitive groups should avoid prolonged outdoor exertion. Consider moving exercise indoors.',short:'Limit time and exertion outdoors'};
 if(value<=300)return{label:'Very unhealthy',color:'#944ba6',advice:'Avoid prolonged or heavy outdoor activity. Sensitive groups should avoid outdoor physical activity; consider staying indoors and following official alerts.',short:'Avoid outdoor exertion'};
 return{label:'Hazardous',color:'#803d54',advice:'Avoid outdoor physical activity and stay indoors when possible. Follow official public-health advisories and use appropriate indoor air filtration if available.',short:'Stay indoors if possible'};
}
export async function currentAQI(points,{force=false}={}){
 if(!Array.isArray(points)||!points.length)return{values:{},at:Date.now(),failed:0};
 const key=points.map(p=>`${p.id}:${p.lat}:${p.lng}`).join('|');const existing=cache.get(key);
 if(!force&&existing&&Date.now()-existing.at<TTL)return existing;
 const values={},errors=[];let failed=0,modelTime='';
 for(let j=0;j<points.length;j+=12){
  const batch=points.slice(j,j+12),url=new URL('https://air-quality-api.open-meteo.com/v1/air-quality');
  url.searchParams.set('latitude',batch.map(p=>p.lat).join(','));url.searchParams.set('longitude',batch.map(p=>p.lng).join(','));
  url.searchParams.set('current','us_aqi');url.searchParams.set('timezone','Asia/Kolkata');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),16000);
  try{
   const response=await fetch(url,{signal:controller.signal});if(!response.ok)throw Error(`Air quality API HTTP ${response.status}`);
   const data=await response.json(),rows=Array.isArray(data)?data:[data];
   if(rows.length!==batch.length)throw Error('Air quality API returned incomplete city data');
   rows.forEach((row,i)=>{const raw=row?.current?.us_aqi;if(Number.isFinite(raw)&&raw>=0){values[batch[i].id]={aqi:Math.round(raw),time:row.current.time||null};modelTime=row.current.time||modelTime;}else failed++;});
  }catch(error){errors.push(error.message);failed+=batch.length;}finally{clearTimeout(timer)}
 }
 if(!Object.keys(values).length)throw Error(errors[0]||'No AQI readings available');
 const result={values,at:Date.now(),modelTime,failed,source:'Open-Meteo CAMS model · US AQI'};cache.set(key,result);return result;
}
