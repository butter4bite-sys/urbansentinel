import base64, html, json, re
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];mod_dir=ROOT/'assets/js'
files=['house-climate-game','home-energy-model','property-profile','weather-service','weather-fallback','satellite-map','solar-science','indoor-walkthrough','immersive-room']
imports={}
for name in files:
 s=(mod_dir/(name+'.js')).read_text()
 s=re.sub(r"from ['\"]\./([^'\"]+)['\"]",lambda m:f"from 'usmod/{m.group(1)}'",s)
 imports['usmod/'+name+'.js']='data:text/javascript;base64,'+base64.b64encode(s.encode()).decode()
styles=''.join((ROOT/'assets/css'/f).read_text() for f in ['style.css','usx-enhancements.css','house-climate-game.css'])
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1280,'height':900},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 storage_script="""<script>const store=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>store.get(k)??null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k),clear:()=>store.clear()}});</script>"""
 document=f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>{styles}</style>{storage_script}<script type="importmap">{json.dumps({'imports':imports})}</script></head><body style="background:#091f23;color:white;font-family:system-ui;margin:0;padding:10px"><div id="climateGame"></div><script type="module">import 'usmod/house-climate-game.js';</script></body></html>'''
 page.set_content(document,wait_until='domcontentloaded')
 page.wait_for_timeout(2100)
 print('pageerrors',errors[:4]);print('indoor count',page.locator('#cg-indoor').count())
 assert page.locator('#cg-indoor').count()==1
 page.locator('#cg-length').fill('18');page.locator('#cg-length').press('Tab');page.locator('#cg-width').fill('6');page.locator('#cg-width').press('Tab')
 page.wait_for_timeout(500)
 print('length,width',page.locator('#cg-stage-house').inner_text())
 page.screenshot(path='/mnt/data/urban_indoor_exterior.png',full_page=False)
 page.locator('#cg-indoor').click()
 page.wait_for_timeout(800)
 print('indoor on?',page.locator('#cg-indoor').get_attribute('aria-pressed'),'pad',page.locator('#cg-indoor-pad').is_visible(),'err',errors[:4])
 page.screenshot(path='/mnt/data/urban_indoor_firstperson.png',full_page=False)
 page.locator('#cg-place-fridge').click();page.locator('#cg-drop').click();print('place fridge',page.locator('#cg-placement-feedback').inner_text())
 page.locator('#cg-place-lights').click();page.locator('#cg-drop').click();print('place led',page.locator('#cg-placement-feedback').inner_text())
 page.locator('#cg-canvas').focus();page.keyboard.down('w');page.wait_for_timeout(250);page.keyboard.up('w');page.wait_for_timeout(100)
 page.locator('#cg-exit-indoor').click();print('exited?',page.locator('#cg-indoor').get_attribute('aria-pressed'))
 # mobile
 mobile=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,has_touch=True,is_mobile=True)
 mobile_errors=[];mobile.on('pageerror',lambda e:mobile_errors.append(str(e)))
 mobile.set_content(document,wait_until='domcontentloaded');mobile.wait_for_timeout(900)
 mobile.locator('#cg-zoom-in').click();mobile.locator('#cg-indoor').click();mobile.wait_for_timeout(450)
 mobile.locator('#cg-mobile-movement [data-walk="forward"]').scroll_into_view_if_needed()
 btn=mobile.locator('#cg-mobile-movement [data-walk="forward"]'); bb=btn.bounding_box()
 if bb:
  mobile.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);mobile.mouse.down();mobile.wait_for_timeout(340);mobile.mouse.up();mobile.wait_for_timeout(100)
 print('mobile pad',mobile.locator('#cg-indoor-pad').is_visible(),'mobile move position',mobile.locator('#cg-indoor-location').inner_text(),'scrollWidth',mobile.evaluate('document.documentElement.scrollWidth'),'errors',mobile_errors[:2])
 mobile.screenshot(path='/mnt/data/urban_indoor_mobile.png',full_page=False)
 browser.close()
