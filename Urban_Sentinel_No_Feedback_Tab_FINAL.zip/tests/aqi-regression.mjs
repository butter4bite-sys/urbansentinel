import assert from 'node:assert/strict';
import fs from 'node:fs';
import {aqiCategory,currentAQI} from '../assets/js/aqi-service.js';
for(const [n,label] of [[0,'Good'],[50,'Good'],[51,'Moderate'],[100,'Moderate'],[101,'Unhealthy for sensitive groups'],[150,'Unhealthy for sensitive groups'],[151,'Unhealthy'],[200,'Unhealthy'],[201,'Very unhealthy'],[300,'Very unhealthy'],[301,'Hazardous']])assert.equal(aqiCategory(n).label,label);
assert.equal(aqiCategory(null).label,'Unavailable');
assert.match(aqiCategory(220).advice,/Avoid prolonged/);
const originalFetch=globalThis.fetch;
try{
 globalThis.fetch=async(url)=>{
  assert.match(String(url),/air-quality-api\.open-meteo\.com\/v1\/air-quality/);
  assert.equal(new URL(url).searchParams.get('current'),'us_aqi');
  return{ok:true,json:async()=>[{current:{us_aqi:84,time:'2026-11-01T12:00'}},{current:{us_aqi:173,time:'2026-11-01T12:00'}}]};
 };
 const pts=[{id:'pune',lat:18.52,lng:73.85},{id:'mumbai',lat:19.08,lng:72.88}];
 const out=await currentAQI(pts,{force:true});assert.equal(out.values.pune.aqi,84);assert.equal(out.values.mumbai.aqi,173);assert.equal(out.modelTime,'2026-11-01T12:00');
 const cached=await currentAQI(pts);assert.equal(cached.values.pune.aqi,84);
 globalThis.fetch=async()=>({ok:false,status:503});
 await assert.rejects(currentAQI([{id:'missing',lat:20,lng:80}],{force:true}),/HTTP 503/);
}finally{globalThis.fetch=originalFetch;}
const shell=fs.readFileSync('assets/js/shell.js','utf8');
assert(shell.includes("'city-intelligence.html'"),'city intelligence grouped in navigation');
assert(!shell.includes('demoPlanSelect'));
assert(fs.existsSync('temperature.html')&&fs.existsSync('aqi.html'),'city maps remain available');
const page=fs.readFileSync('aqi.html','utf8');assert(page.includes('id="aqiAdvice"'));assert(page.includes('id="aqiState"'));assert(page.includes('US Air Quality Index'));
const js=fs.readFileSync('assets/js/pages/aqi.js','utf8');assert(js.includes("map.on('zoomend'"));assert(js.includes('resolveStateCities'));
const css=fs.readFileSync('assets/css/style.css','utf8');assert(css.includes('min-height:clamp(245px,30vw,465px)'));assert(css.includes('max-width:760px'));
console.log('PASS: AQI category thresholds, live API parser, error handling, shared city directory, zoom guidance, responsive banners');
