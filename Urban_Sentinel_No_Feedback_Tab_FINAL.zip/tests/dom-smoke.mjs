import assert from 'node:assert/strict';
import {readFileSync,readdirSync,existsSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=join(dirname(fileURLToPath(import.meta.url)),'..');
const source=readFileSync(join(root,'assets/js/main.js'),'utf8');
for(const [page,module] of [...source.matchAll(/([\w-]+):'([\w-]+)'/g)].map(m=>[m[1],m[2]])){
 if(['overview','assessment-page','projects','account','heat-map','temperature','cooling','localities','insights','about','assistant'].includes(module))assert.ok(existsSync(join(root,'assets/js/pages',module+'.js')),`Missing ${page} module: ${module}`);
}
const scripts=['assets/js/cities.js','assets/js/assessment.js','assets/js/projects.js','assets/js/pdf.js','assets/js/weather-service.js'];
for(const file of scripts)await import('../'+file);
for(const page of ['assessment']){
 const html=readFileSync(join(root,page+'.html'),'utf8');assert.match(html,/id="assessment-root"/);
}
for(const [page,keys] of Object.entries({temperature:['tempMap','weatherMessage','tempRank','backToCities'],projects:['projectList','projectDetail'],assistant:['contextProject','chatLog']})){
 const html=readFileSync(join(root,page+'.html'),'utf8');for(const key of keys)assert.ok(html.includes(`id="${key}"`),`${page}: missing ${key}`)
}
const temperature=readFileSync(join(root,'temperature.html'),'utf8');
assert.ok(!/illustrative surface-temperature demo/i.test(temperature));
assert.ok(!readFileSync(join(root,'assets/js/shell.js'),'utf8').includes('Google Login / Account'));
console.log('PASS: module routing, page wiring, interactive element contracts, no demo temperature descriptions');
