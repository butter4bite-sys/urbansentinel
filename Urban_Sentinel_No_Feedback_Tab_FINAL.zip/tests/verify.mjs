import assert from 'node:assert/strict';
import {readFileSync,existsSync,readdirSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {localities} from '../assets/js/localities.js';
import {cities} from '../assets/js/cities.js';
import {buildPlan} from '../assets/js/recommendations.js';
import {cityPortfolio} from '../assets/js/city-engine.js';
import {assess,reportLines} from '../assets/js/assessment.js';
import {buildPdfBytes} from '../assets/js/pdf.js';
import {currentWeather} from '../assets/js/weather-service.js';
import {saveProject,updateProject,getProject,exportProjects,importProjects,deleteProject} from '../assets/js/projects.js';
import {esc} from '../assets/js/ui.js';
const root=join(dirname(fileURLToPath(import.meta.url)),'..');
const pages=['index','assessment','projects','feedback','thanks','privacy','assistant','temperature','insights','about']; const redirects=['school','shop','neighbourhood','cooling'];for(const id of redirects){const h=readFileSync(join(root,id+'.html'),'utf8');assert.ok(h.includes('assessment.html?type='))}
assert.equal(localities.length,54);assert.ok(localities.some(a=>a.name==='Mundhwa'));
assert.equal(cities.length,12);assert.equal(cities.find(c=>c.id==='pune').localities.length,54);
assert.ok(cities.every(c=>c.localities.length>5));
assert.ok(localities.every(x=>!('heat' in x)&&!('green' in x)&&!('people' in x)),'Removed synthetic heat scores');
for(const page of pages){const path=join(root,page+'.html');assert.ok(existsSync(path));const html=readFileSync(path,'utf8');
 assert.ok(html.includes(`data-page="${page}"`));assert.match(html,/<main\s/);assert.match(html,/<h1[^>]*>/);assert.match(html,/<script type="module" src="assets\/js\/main.js"/);
 for(const href of [...html.matchAll(/(?:src|href)="(assets\/[^"#?]+)"/g)].map(x=>x[1]))assert.ok(existsSync(join(root,href)),page+': missing '+href);
}
for(const kind of ['home','school','shop','neighbourhood'])for(const problem of ['heat','air','ventilation','energy','water','balanced'])for(const budget of [10000,20000,100000,1500000]){
 const p=buildPlan({kind,problem,area:900,people:35,budget});assert.ok(p.spent<=budget,`overspent ${kind} ${problem} ${budget}`);assert.ok(p.plan.length);assert.equal(p.spent+p.remaining,budget);
 const a=assess({kind,problem,area:900,people:35,budget,roof:'concrete',sun:'high',floor:'top',ventilation:'poor'});
 assert.ok(a.steps.length);assert.ok(a.flags.some(f=>f.title==='Roof heat gain'));assert.equal(a.steps.reduce((s,v)=>s+v.cost,0),a.spent);
}
for(const budget of [10000,100000,500000,1500000])for(const strategy of ['fair','impact']){
 const r=cityPortfolio({budget,strategy,selectedIds:[12,7]});assert.ok(r.spent<=budget);assert.ok(r.plan.length);assert.ok(r.plan.every(p=>[12,7].includes(p.areaId)));
}
const sample=assess({kind:'home',area:900,people:4,budget:50000,sun:'high',roof:'concrete',floor:'top'});
const pdf=buildPdfBytes(reportLines(sample));assert.ok(pdf.byteLength>1500);assert.equal(new TextDecoder().decode(pdf.slice(0,8)),'%PDF-1.4');assert.ok(new TextDecoder().decode(pdf).includes('xref'));
assert.equal(esc('<script>'),'&lt;script&gt;');
const saved=new Map();globalThis.localStorage={getItem:k=>saved.get(k)||null,setItem:(k,v)=>saved.set(k,v)};
const p=saveProject(sample);assert.equal(getProject(p.id).assessment.kind,'home');updateProject(p.id,{completed:[sample.steps[0].id],actualSpend:3500,measurements:[{date:'2026-11-01',temp:32.4,note:'sample'}]});
assert.equal(getProject(p.id).completed.length,1);const backup=exportProjects();assert.equal(importProjects(backup),1);deleteProject(p.id);assert.equal(getProject(p.id),null);
const cache=new Map();globalThis.sessionStorage={getItem:k=>cache.get(k)||null,setItem:(k,v)=>cache.set(k,v)};
let requests=0;
globalThis.fetch=async url=>{
 requests++;
 const n=new URL(url).searchParams.get('latitude').split(',').length;
 const item=()=>({current:{temperature_2m:32,relative_humidity_2m:65,apparent_temperature:36,time:'2026-11-01T13:00'}});
 return {ok:true,json:async()=>n===1?item():Array.from({length:n},item)};
};
const weather=await currentWeather(cities);assert.equal(Object.keys(weather.values).length,12);assert.equal(weather.values.pune.temp,32);assert.equal(weather.values.pune.feels,36);
await currentWeather(cities);assert.equal(requests,1,'Weather cache prevents repeat batch');
const local=await currentWeather(cities.find(c=>c.id==='pune').localities);assert.equal(Object.keys(local.values).length,54);assert.equal(requests,5,'Batched requests');
const states=JSON.parse(readFileSync(join(root,'assets/data/india-states-cities.json'),'utf8'));
assert.equal(Object.keys(states).length,36);
assert.ok(Object.values(states).reduce((n,c)=>n+c.length,0)>=550);
assert.ok(states.Telangana.includes('Hyderabad')&&!states.Telangana.includes('Pune'));
assert.ok(states.Maharashtra.includes('Pune')&&!states.Maharashtra.includes('Hyderabad'));
assert.ok(Object.values(states).every(c=>c.length>=1&&c.length<=20));
const shell=readFileSync(join(root,'assets/js/shell.js'),'utf8');assert.ok(!shell.includes('Google Login / Account'));assert.ok(shell.includes('access.html')&&!shell.includes('Account sign-in'));assert.ok(!shell.includes('demoPlanSelect'));assert.ok(shell.includes('3d-simulation.html'));assert.ok(shell.includes('marketplace.html')); 
const assessmentPage=readFileSync(join(root,'assets/js/pages/assessment-page.js'),'utf8');assert.ok(assessmentPage.includes('saveProject(')&&assessmentPage.includes('aState')&&assessmentPage.includes('aCity'));
const temperaturePage=readFileSync(join(root,'assets/js/pages/temperature.js'),'utf8');assert.ok(temperaturePage.includes('stateSelect')&&temperaturePage.includes('loadNeighbourhoods')&&temperaturePage.includes('resolveStateCities'));
assert.ok(!existsSync(join(root,'heat-map.html')));
assert.ok(!shell.includes('Pune Heat Explorer'));assert.ok(!shell.includes('localities.html'));assert.ok(!existsSync(join(root,'localities.html')));
assert.ok(existsSync(join(root,'access.html'))&&existsSync(join(root,'backend/api.php'))&&existsSync(join(root,'backend/setup.php')));
console.log(`PASS: ${pages.length} pages, ${Object.keys(states).length} states/UTs, state-specific city directory, local project storage, budgets, PDF & model weather`);
