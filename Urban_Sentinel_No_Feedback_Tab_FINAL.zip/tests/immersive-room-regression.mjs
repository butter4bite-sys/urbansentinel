import assert from 'node:assert/strict';
import {mountImmersiveRoom} from '../assets/js/immersive-room.js';
let frameQueue=[],lastBuffer=null,drawCalls=0;
globalThis.window={devicePixelRatio:1};
globalThis.requestAnimationFrame=fn=>{frameQueue.push(fn);return frameQueue.length};
globalThis.cancelAnimationFrame=()=>{};
const noop=()=>{};
let attribute=0;
const gl={VERTEX_SHADER:35633,FRAGMENT_SHADER:35632,COMPILE_STATUS:35713,LINK_STATUS:35714,DEPTH_TEST:2929,LEQUAL:515,CULL_FACE:2884,ARRAY_BUFFER:34962,DYNAMIC_DRAW:35048,FLOAT:5126,COLOR_BUFFER_BIT:16384,DEPTH_BUFFER_BIT:256,TRIANGLES:4,
 createShader:()=>({}),shaderSource:noop,compileShader:noop,getShaderParameter:()=>true,getShaderInfoLog:()=>'',createProgram:()=>({}),attachShader:noop,linkProgram:noop,getProgramParameter:()=>true,getProgramInfoLog:()=>'',useProgram:noop,createBuffer:()=>({}),enable:noop,disable:noop,depthFunc:noop,cullFace:noop,getAttribLocation:()=>attribute++,getUniformLocation:(_,s)=>s,
 bindBuffer:noop,bufferData:(_,v)=>{lastBuffer=v},enableVertexAttribArray:noop,vertexAttribPointer:noop,viewport:noop,clearColor:noop,clear:noop,uniformMatrix4fv:noop,uniform3fv:noop,uniform1f:noop,drawArrays:(_,__,n)=>{assert.ok(n>0);drawCalls++}};
function el(tag){return {tag,hidden:false,style:{},clientWidth:1000,clientHeight:550,isConnected:true,width:0,height:0,className:'',innerHTML:'',textContent:'',setAttribute:noop,addEventListener:noop,remove:noop,focus:noop,getContext:(kind)=>kind==='webgl'?gl:null}};
globalThis.document={createElement:el};
const parent={children:[],appendChild(child){this.children.push(child)}};
const renderer=mountImmersiveRoom(parent);
assert.equal(renderer.available,true);
renderer.refresh({profile:{length:12,width:9,ceilingHeight:2.8,type:'duplex'},energy:{acCount:1,fanCount:2,lightsCount:4,fridgeCount:1},positions:{ac:[[1,2]],fans:[[1,-1],[-2,2]],lights:[[0,0],[1,2],[-1,-1],[2,2]],fridge:[[2,2]]},position:{x:0,y:-2},heading:0,look:0,fov:1.2,heatIndex:65,mode:'realistic'});
renderer.show(true);frameQueue.shift()?.(1000);
assert.ok(lastBuffer instanceof Float32Array);assert.ok(lastBuffer.length>10000,'full 3D mesh generated');assert.ok(drawCalls>0);
const previous=lastBuffer;
renderer.refresh({profile:{length:20,width:7,ceilingHeight:3.1,type:'bungalow'}});frameQueue.shift()?.(1350);
assert.notDeepEqual(Array.from(lastBuffer.slice(0,240)),Array.from(previous.slice(0,240)),'scaled room geometry differs');
const priorVertexCount=lastBuffer.length;
renderer.refresh({energy:{acCount:3,fanCount:3,lightsCount:5,fridgeCount:2},positions:{ac:[[1,2],[2,1],[-1,1]],fans:[[1,-1],[-2,2],[1.5,1]],lights:[[0,0],[1,2],[-1,-1],[2,2],[-2,-2]],fridge:[[2,2],[-2,1]]}});frameQueue.shift()?.(1720);
assert.ok(lastBuffer.length>priorVertexCount,'more appliances contribute more 3D geometry');
renderer.show(false);
assert.equal(renderer.canvas.hidden,true);
console.log('PASS: real WebGL mesh, metric resizing, 3D appliances, camera rendering contract, show/hide');
