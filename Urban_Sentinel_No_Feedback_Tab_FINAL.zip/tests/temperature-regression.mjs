import assert from 'node:assert/strict';
import {locateCity,loadNeighbourhoods,statesPromise} from '../assets/js/locations-india.js';
statesPromise.catch(()=>{}); // Node tests have no browser-hosted JSON fetch; production uses HTTP(S).
import {currentWeather} from '../assets/js/weather-service.js';
import {readFileSync} from 'node:fs';
const pune=await locateCity('Maharashtra','Pune');
assert.equal(pune.name,'Pune');
// Pune is intentionally city-only in the temperature UI; neighbourhoods are not requested for Pune.
const mumbai=await locateCity('Maharashtra','Mumbai');
assert.ok(mumbai.lat>18&&mumbai.lat<20);
const weatherJs=readFileSync(new URL('../assets/js/pages/temperature.js',import.meta.url),'utf8');
assert.ok(weatherJs.includes('classicMarker(L,p,values[p.id]'),'Map must display numeric temperature labels on classic circle markers');
assert.ok(weatherJs.includes('const items=city?[city,...areas]'),'City temperature must appear in place list');
assert.ok(weatherJs.includes("state==='Maharashtra' && name==='Pune'"),'Pune must be city-only in the temperature map');
assert.ok(weatherJs.indexOf("state==='Maharashtra' && name==='Pune'") < weatherJs.indexOf('areas=await loadNeighbourhoods(city)'),'Pune bypasses neighbourhood loading');
const storage=new Map();globalThis.sessionStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)};
let n=0;globalThis.fetch=async url=>{n++;const count=new URL(url).searchParams.get('latitude').split(',').length;
 if(n===1)return{ok:false,status:503};
 const point=()=>({current:{temperature_2m:31.4,relative_humidity_2m:65,apparent_temperature:35,time:'2026-11-01T13:00'}});
 return {ok:true,json:async()=>count===1?point():Array.from({length:count},point)};
};
const testPoints=Array.from({length:20},(_,i)=>({id:'test-'+i,name:'Test '+i,lat:18.5+i*.01,lng:73.8+i*.01}));
const result=await currentWeather(testPoints);
assert.equal(Object.keys(result.values).length,5,'One failed batch should not erase the successful batch');
assert.equal(result.failed,15);
console.log('PASS: Pune city-only drilldown, major-city centres, visible compact temperature labels, partial weather recovery');
