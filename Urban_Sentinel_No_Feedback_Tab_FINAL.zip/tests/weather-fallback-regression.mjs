import assert from 'node:assert/strict';
import {loadWeather,parseMetNorway} from '../assets/js/weather-fallback.js';
import {currentWeather} from '../assets/js/weather-service.js';
const storage=new Map();
globalThis.localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)};
const session=new Map();globalThis.sessionStorage={getItem:k=>session.get(k)||null,setItem:(k,v)=>session.set(k,v)};
const time=new Date().toISOString();
const met=()=>({properties:{timeseries:[{time,data:{instant:{details:{air_temperature:30.2,relative_humidity:63,wind_speed:4}},next_1_hours:{details:{precipitation_amount:0.4}}}}]}});
const primary=()=>({current:{temperature_2m:28.3,relative_humidity_2m:59,apparent_temperature:30.2,wind_speed_10m:8,precipitation:0,time:'2026-11-02T12:00'}});
const json=(data,status=200)=>({ok:status<400,status,json:async()=>data});
let metRequests=0,primaryRequests=0,primaryDown=true,metDown=false;
globalThis.fetch=async url=>{
 const host=new URL(url).hostname;
 if(host==='api.open-meteo.com'){
  primaryRequests++;if(primaryDown)return json({},503);
  const n=new URL(url).searchParams.get('latitude').split(',').length;
  return json(n===1?primary():Array.from({length:n},primary));
 }
 if(host==='api.met.no'){metRequests++;return metDown?json({},503):json(met());}
 throw Error('Unexpected API '+url);
};
const point={lat:18.5204,lon:73.8567};
const a=await loadWeather(point);
assert.equal(a.source,'MET Norway');assert.equal(a.current.temperature_2m,30.2);
assert.equal(a.current.relative_humidity_2m,63);assert.equal(a.current.wind_speed_10m,14.4);
assert.equal(a.current.precipitation,0.4);assert.equal(a.current.apparent_temperature,null);
assert.equal(a.precipitationPeriod,'next 1 hour forecast');assert.equal(a.current.time.endsWith('T00:00'),false);
assert.ok(metRequests>=1);assert.ok(primaryRequests>=2,'Primary retries on 503');
const b=await loadWeather(point);assert.equal(b.cached,true);assert.equal(metRequests,1,'Cached MET Norway data prevents repeat calls');
primaryDown=false;
const c=await loadWeather({lat:19.076,lon:72.8777});assert.equal(c.source,'Open-Meteo');assert.equal(c.current.temperature_2m,28.3);
primaryDown=true;metDown=true;
const stale=await loadWeather(point,{force:true});assert.equal(stale.stale,true);assert.equal(stale.current.temperature_2m,30.2);
metDown=false;
const batch=await currentWeather([{id:'pune',lat:18.52,lng:73.85},{id:'mumbai',lat:19.07,lng:72.87}],{force:true});
assert.equal(batch.values.pune.temp,30.2);assert.equal(batch.values.mumbai.temp,30.2);assert.equal(batch.source,'MET Norway');
assert.equal(batch.failed,0);
const many=await currentWeather(Array.from({length:16},(_,i)=>({id:'city'+i,lat:11+i/100,lng:75+i/100})),{force:true});
assert.equal(Object.keys(many.values).length,12);assert.equal(many.failed,4);assert.equal(many.backupLimited,true);
assert.throws(()=>parseMetNorway({properties:{timeseries:[]}}),/no forecast/i);
console.log('PASS: 503 backup, air-temperature units, forecast precipitation, provider source, caching, partial city fallback');
