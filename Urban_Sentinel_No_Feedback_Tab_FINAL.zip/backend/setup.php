<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
header('Cache-Control: no-store');
function esc(string $v):string{return htmlspecialchars($v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
$error='';$installed=false;
try{$installed=us_installed();}catch(Throwable $e){$error=$e->getMessage();}
if(!$installed && $_SERVER['REQUEST_METHOD']==='POST'){
 try{
  us_check_csrf($_POST);
  $key=(string)($_POST['setup_key']??'');$hash=require __DIR__.'/setup-hash.php';
  if(!hash_equals((string)$hash,hash('sha256',$key)))throw new RuntimeException('Invalid one-time installation key.');
  $owner=(string)($_POST['owner_password']??'');$contractor=(string)($_POST['business_password']??'');
  if(strlen($owner)<10 || strlen($owner)>120 || strlen($contractor)<10 || strlen($contractor)>120)throw new RuntimeException('Each password must contain 10–120 characters.');
  if(!us_is_https())throw new RuntimeException('HTTPS is required for public installation. HTTP is allowed only on localhost.');
  $seed=us_seed_partners();foreach($seed as &$p){$p=['id'=>us_id(),...$p,'created_at'=>gmdate('c')];}unset($p);
  $businessPartner=$seed[0]['id'];foreach($seed as $entry)if(($entry['name']??'')==='Diligent Enterprises'){$businessPartner=$entry['id'];break;}
  $created=us_change('users',function(&$users)use($owner,$contractor,$businessPartner){if(count($users))return false;$users=[['id'=>us_id(),'username'=>'owner','passhash'=>password_hash($owner,PASSWORD_DEFAULT),'role'=>'owner','partner_id'=>null,'active'=>true,'created_at'=>gmdate('c')],['id'=>us_id(),'username'=>'business','passhash'=>password_hash($contractor,PASSWORD_DEFAULT),'role'=>'business','partner_id'=>$businessPartner,'active'=>true,'created_at'=>gmdate('c')]];return true;});
  if(!$created)throw new RuntimeException('Installation already completed.');
  us_change('partners',function(&$arr)use($seed){$arr=$seed;});
  header('Location: ../access.html?installed=1',true,303);exit;
 }catch(Throwable $e){$error=$e->getMessage();}
}
?><!doctype html><html lang="en" data-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>One-time Setup · Urban Sentinel</title><link rel="stylesheet" href="../assets/css/style.css"><link rel="stylesheet" href="../assets/css/urban-v4.css"><style>body{margin:0;background:#0b2021;color:#e4fbf4;font:16px/1.5 system-ui}main{max-width:610px;margin:7vh auto;padding:28px;background:#143536;border:1px solid #315e59;border-radius:18px}label{display:block;margin:14px 0}input{display:block;width:100%;padding:12px;background:#0c2626;color:white;border:1px solid #47726d;border-radius:8px;box-sizing:border-box}button{padding:13px 22px;background:#b7e86b;border:0;border-radius:8px;font-weight:800;cursor:pointer}.error{background:#6e2828;padding:12px;border-radius:8px}</style></head><body><main><h1>Urban Sentinel · One-time setup</h1><?php if($installed):?><p>Already configured. The installer is disabled.</p><a href="../access.html">Go to Partner Access</a><?php else:?><p>Set the private owner and contractor login passwords. Passwords are securely hashed and kept outside the website document root.</p><p>The default business account is linked to Diligent Enterprises for lead-tracking demonstration. Other providers require separate accounts.</p><?php if($error):?><p class="error" role="alert"><?=esc($error)?></p><?php endif;?><form method="post" autocomplete="off"><input type="hidden" name="csrf" value="<?=esc(us_token())?>"><label>Private installation key (provided separately)<input type="password" name="setup_key" required></label><label>Owner username<input value="owner" disabled></label><label>Owner password<input type="password" name="owner_password" minlength="10" required></label><label>Business username<input value="business" disabled></label><label>Business password<input type="password" name="business_password" minlength="10" required></label><button type="submit">Complete one-time setup</button></form><p>Never install with public or shared passwords on a live site. Change the sample passwords before production use.</p><?php endif;?></main></body></html>
