<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
// Reject cross-origin form submissions; all requests are same-origin.
$origin=$_SERVER['HTTP_ORIGIN']??'';
if($origin && parse_url($origin,PHP_URL_HOST)!==(explode(':',(string)($_SERVER['HTTP_HOST']??''))[0]))us_error(403,'Cross-origin submissions are not allowed.');
$action=(string)($_GET['action']??'');$method=$_SERVER['REQUEST_METHOD']??'GET';
try{
 if($method==='GET'){
  if($action==='bootstrap'){us_json(['ok'=>true,'installed'=>us_installed(),'csrf'=>us_token(),'user'=>us_user()]);}
  if($action==='providers'){$all=us_installed()?us_read('partners'):[];$active=array_values(array_filter($all,fn($p)=>empty($p['archived'])));us_json(['ok'=>true,'installed'=>us_installed(),'providers'=>array_map('us_provider_public',$active)]);}
  if($action==='leads'){$user=us_auth();$leads=us_read('leads');if($user['role']==='business')$leads=array_values(array_filter($leads,fn($l)=>$l['partner_id']===$user['partner_id']));us_json(['ok'=>true,'leads'=>array_reverse($leads)]);}
  if($action==='all_partners'){us_auth('owner');us_json(['ok'=>true,'partners'=>us_read('partners')]);}
  if($action==='users'){us_auth('owner');us_json(['ok'=>true,'users'=>array_map(fn($u)=>['username'=>$u['username'],'role'=>$u['role'],'partner_id'=>$u['partner_id']??null,'created_at'=>$u['created_at'],'active'=>$u['active']??true],us_read('users'))]);}
  us_error(404,'Unknown request.');
 }
 if($method!=='POST')us_error(405,'Method not allowed.');
 $data=us_body();us_check_csrf($data);
 if($action==='import_pune_candidates'){
  us_auth('owner');
  $candidates=array_slice(us_seed_partners(),0,9);
  // Earlier builds stored five generic location labels and two ambiguous solar contacts.
  // Match old candidates by their original position's name so saved lead IDs are retained.
  $oldAliases=['Satyam Enterprises','Conproof Waterproofing','Samarth Solar','Solar Systems Provider — Shivajinagar','Rainwater Harvesting Provider — Sinhgad Road','Shading Provider — Kothrud','Shading & Interiors Provider — Prabhat Road','Rainwater Harvesting Provider — Warje'];
  $result=us_change('partners',function(&$all)use($candidates,$oldAliases){
   $added=0;$updated=0;
   foreach($candidates as $i=>$candidate){
    $existingIndex=-1;
    foreach($all as $j=>$p)if(strcasecmp($p['name'],$candidate['name'])===0||strcasecmp($p['name'],$oldAliases[$i])===0){$existingIndex=$j;break;}
    if($existingIndex>=0){
     $old=$all[$existingIndex];
     // Never overwrite an owner's approved or explicitly confirmed partner details.
     if(empty($old['verified']) && empty($old['agreement_confirmed'])){
      $all[$existingIndex]=array_replace($old,$candidate,['id'=>$old['id'],'verified'=>true,'agreement_confirmed'=>true,'referral_enabled'=>true,'commission_percent'=>0]);$updated++;
     }
     continue;
    }
    $all[]=['id'=>us_id(),...$candidate,'created_at'=>gmdate('c')];$added++;
   }
   return ['added'=>$added,'updated'=>$updated];
  });
  us_json(['ok'=>true,...$result]);
 }
 if($action==='login'){
  us_rate('login',7,900);
  if(!us_installed())us_error(503,'Set up the contractor portal first.');
  $username=us_str($data['username']??'',80);$password=(string)($data['password']??'');
  $found=null;foreach(us_read('users') as $u){if(hash_equals($u['username'],$username))$found=$u;}
  if(!$found||($found['active']??true)===false||!password_verify($password,$found['passhash']))us_error(401,'Incorrect username or password.');if($found['role']==='business'){$available=false;foreach(us_read('partners') as $p)if($p['id']===($found['partner_id']??'')&&empty($p['archived']))$available=true;if(!$available)us_error(403,'This contractor account has been disabled.');}
  us_session();session_regenerate_id(true);$_SESSION['user_id']=$found['id'];us_json(['ok'=>true,'role'=>$found['role'],'next'=>'backend/portal.php']);
 }
 if($action==='logout'){us_session();$_SESSION=[];session_destroy();us_json(['ok'=>true]);}
 if($action==='submit_lead'){
  if(!us_installed())us_error(503,'Referral tracking is not configured.');
  us_rate('referrals',5,3600);
  if(trim((string)($data['website']??''))!=='')us_error(400,'Unable to submit request.');
  $partnerId=us_str($data['partner_id']??'',36);$partner=null;
  foreach(us_read('partners') as $p)if($p['id']===$partnerId && empty($p['archived']))$partner=$p;
  if(!$partner || empty($partner['referral_enabled']) || empty($partner['agreement_confirmed']) || empty($partner['verified']))us_error(400,'This business is not currently accepting tracked referrals.');
  $name=us_str($data['customer_name']??'',90);$phone=us_str($data['phone']??'',22);$email=us_str($data['email']??'',130);$city=us_str($data['city']??'',90);$service=us_str($data['service']??'',130);$notes=us_str($data['notes']??'',900);
  if(strlen($name)<2 || !preg_match('/^[+0-9() .\-]{10,22}$/',$phone)||strlen(preg_replace('/\D/','',$phone))<10 || !$service)us_error(422,'Enter your name, valid phone and service.');
  if($email && !filter_var($email,FILTER_VALIDATE_EMAIL))us_error(422,'Enter a valid email or leave it blank.');
  if(($data['consent']??false)!==true)us_error(422,'Consent is required before sharing an enquiry with the selected contractor.');
  $id=us_change('leads',function(&$arr)use($partner,$name,$phone,$email,$city,$service,$notes){do{$code='US-'.gmdate('Y').'-'.str_pad((string)random_int(0,99999999),8,'0',STR_PAD_LEFT);}while(in_array($code,array_column($arr,'referral_id'),true));$arr[]=['id'=>us_id(),'referral_id'=>$code,'partner_id'=>$partner['id'],'partner_name'=>$partner['name'],'customer_name'=>$name,'phone'=>$phone,'email'=>$email,'city'=>$city,'service'=>$service,'notes'=>$notes,'status'=>'New','created_at'=>gmdate('c'),'updated_at'=>gmdate('c'),'reported_value'=>null,'confirmed_amount'=>null,'completion_confirmed'=>false,'commission_rate'=>null,'commission_due'=>0,'consent_at'=>gmdate('c'),'history'=>[['at'=>gmdate('c'),'by'=>'customer','event'=>'Referral submitted']] ];return $code;});
  us_json(['ok'=>true,'referral_id'=>$id,'message'=>'Referral recorded. The selected business may view it in its assigned portal. This does not guarantee a callback or create a booking.'],201);
 }
 $user=us_auth();
 if($action==='change_status'){
  $id=us_str($data['id']??'',36);$status=us_str($data['status']??'',40);if(!in_array($status,['New','Contacted','Quotation Sent','Work Started','Completed','Cancelled'],true))us_error(422,'Invalid status.');
  $val=isset($data['reported_value']) && $data['reported_value']!==''?floatval($data['reported_value']):null;
  if($val!==null && ($val<0 || $val>1000000000))us_error(422,'Invalid project value.');
  $changed=us_change('leads',function(&$all)use($id,$status,$val,$user){foreach($all as &$l){if($l['id']!==$id)continue;if($user['role']==='business' && $l['partner_id']!==$user['partner_id'])return false;$prior=$l['status'];$l['status']=$status;$l['reported_value']=$val;$l['updated_at']=gmdate('c');$l['history'][]=['at'=>gmdate('c'),'by'=>$user['username'],'event'=>$prior.' → '.$status];if($status!=='Completed'){$l['completion_confirmed']=false;$l['confirmed_amount']=null;$l['commission_due']=0;}return true;}return false;});
  if(!$changed)us_error(404,'Referral not found or access denied.');us_json(['ok'=>true]);
 }
 if($action==='confirm_completion'){
  us_auth('owner');$id=us_str($data['id']??'',36);$amount=(float)($data['amount']??-1);if($amount<0 || $amount>1000000000)us_error(422,'Enter a valid agreed project amount.');
  $partners=us_read('partners');$done=us_change('leads',function(&$all)use($id,$amount,$partners){foreach($all as &$l){if($l['id']!==$id || $l['status']!=='Completed')continue;$rate=0;foreach($partners as $p)if($p['id']===$l['partner_id'])$rate=(float)($p['commission_percent']??0);$l['completion_confirmed']=true;$l['confirmed_amount']=$amount;$l['commission_rate']=$rate;$l['commission_due']=round($amount*$rate/100,2);$l['updated_at']=gmdate('c');$l['history'][]=['at'=>gmdate('c'),'by'=>'owner','event'=>'Completed project verified: ₹'.$amount];return true;}return false;});if(!$done)us_error(422,'Mark the referral Completed first.');us_json(['ok'=>true]);
 }
 if($action==='delete_lead'){us_auth('owner');$id=us_str($data['id']??'',36);us_change('leads',function(&$arr)use($id){$arr=array_values(array_filter($arr,fn($l)=>$l['id']!==$id));});us_json(['ok'=>true]);}
 if($action==='save_partner'){
  us_auth('owner');$id=us_str($data['id']??'',36);$name=us_str($data['name']??'',110);$category=us_str($data['category']??'',100);$region=us_str($data['region']??'',100);$phone=us_str($data['phone']??'',30);$address=us_str($data['address']??'',220);$service=us_str($data['service']??'',240);$email=us_str($data['email']??'',130);$website=us_str($data['website']??'',300);$source=us_str($data['source']??'',300);$description=us_str($data['description']??'',300);$verified=($data['verified']??false)===true;$agreed=($data['agreement_confirmed']??false)===true;$enabled=($data['referral_enabled']??false)===true;$archived=($data['archived']??false)===true;$percent=(float)($data['commission_percent']??0);
  if(strlen($name)<2 || !$category || !$region || $percent<0 || $percent>100)us_error(422,'Business name, category, region and valid commission percentage are required.');if($agreed && !$verified)us_error(422,'Verify the business identity before confirming partnership.');if($enabled && (!$verified || !$agreed))us_error(422,'A tracked referral requires identity verification and a confirmed partner agreement.');
  if($email && !filter_var($email,FILTER_VALIDATE_EMAIL))us_error(422,'Invalid email.');foreach([$website,$source] as $url)if($url && (!filter_var($url,FILTER_VALIDATE_URL)||parse_url($url,PHP_URL_SCHEME)!=='https'))us_error(422,'Use HTTPS links.');
  $obj=compact('name','category','region','phone','address','service','email','website','source','description','verified','archived');$obj['agreement_confirmed']=$agreed;$obj['referral_enabled']=$enabled;$obj['commission_percent']=$percent;
  $saved=us_change('partners',function(&$all)use($id,$obj){if($id){foreach($all as &$p)if($p['id']===$id){$p=array_replace($p,$obj);return $p['id'];}return false;}$new=['id'=>us_id(),...$obj,'created_at'=>gmdate('c')];$all[]=$new;return $new['id'];});if(!$saved)us_error(404,'Partner not found.');us_json(['ok'=>true,'id'=>$saved]);
 }
 if($action==='create_business_user'){
  us_auth('owner');$partner=us_str($data['partner_id']??'',36);$username=us_str($data['username']??'',55);$password=(string)($data['password']??'');
  if(!preg_match('/^[a-zA-Z0-9_.-]{3,55}$/',$username)||strlen($password)<10||strlen($password)>120)us_error(422,'Use a valid username and password with at least 10 characters.');
  if(!array_filter(us_read('partners'),fn($p)=>$p['id']===$partner && empty($p['archived'])))us_error(422,'Select an active contractor.');
  $created=us_change('users',function(&$all)use($username,$password,$partner){foreach($all as $u)if($u['username']===$username)return false;$all[]=['id'=>us_id(),'username'=>$username,'passhash'=>password_hash($password,PASSWORD_DEFAULT),'role'=>'business','partner_id'=>$partner,'active'=>true,'created_at'=>gmdate('c')];return true;});if(!$created)us_error(409,'Username already exists.');us_json(['ok'=>true]);
 }
 if($action==='manage_business_user'){
  us_auth('owner');$username=us_str($data['username']??'',55);$operation=us_str($data['operation']??'',24);$newPassword=(string)($data['new_password']??'');
  if(!in_array($operation,['disable','enable','reset_password'],true))us_error(422,'Unsupported user action.');
  if($operation==='reset_password' && (strlen($newPassword)<10 || strlen($newPassword)>120))us_error(422,'New contractor password must contain at least 10 characters.');
  $changed=us_change('users',function(&$all)use($username,$operation,$newPassword){foreach($all as &$u){if($u['username']!==$username||$u['role']!=='business')continue;if($operation==='disable')$u['active']=false;elseif($operation==='enable')$u['active']=true;else $u['passhash']=password_hash($newPassword,PASSWORD_DEFAULT);return true;}return false;});
  if(!$changed)us_error(404,'Business user not found.');us_json(['ok'=>true]);
 }
 if($action==='change_password'){
  $current=(string)($data['current_password']??'');$next=(string)($data['new_password']??'');if(strlen($next)<10||strlen($next)>120)us_error(422,'New password must contain at least 10 characters.');
  $updated=us_change('users',function(&$all)use($user,$current,$next){foreach($all as &$u){if($u['id']!==$user['id'])continue;if(!password_verify($current,$u['passhash']))return false;$u['passhash']=password_hash($next,PASSWORD_DEFAULT);return true;}return false;});if(!$updated)us_error(401,'Current password incorrect.');us_json(['ok'=>true]);
 }
 us_error(404,'Unknown action.');
}catch(Throwable $e){error_log('Urban Sentinel referral error: '.$e->getMessage());us_error(500,'Server storage error. Review setup and hosting permissions.');}
